# Free Apps Nepal

An Android marketplace for apps and games, with a separate administration app, both backed by the
same Firebase project. Users browse free and Pro listings; a single monthly Pro subscription
unlocks the direct Pro download link on every eligible listing. The catalogue never hosts the
download files. An administrator enters, for each listing, an external Free URL and an external Pro
URL, and the apps open exactly those URLs.

The repository contains three Gradle modules:

| Module | Kind | Purpose |
| --- | --- | --- |
| `core` | Android library | Models, Firestore mapping, repositories, domain rules, shared Compose UI |
| `app-user` | Android application | The public marketplace, `Free Apps Nepal` |
| `app-admin` | Android application | The administration console, `Free Apps Nepal Admin` |

The Firebase backend lives in `firebase/`: Firestore rules and indexes, Storage rules, and the
Cloud Functions that price orders, start Khalti and eSewa payments, verify them, and release Pro
links.

## The business model in one paragraph

Every listing is visible to every user. A listing can offer a free version, a Pro version, or both.
The Free download URL is configured by the administrator and is available to everyone, including
active Pro subscribers; it is never replaced by the Pro URL. The Pro download URL is locked until a
monthly Pro subscription is active, and unlocking it requires no advertisement and no per listing
payment. One active subscription unlocks the Pro link on every eligible listing at once. When the
subscription expires the Free links stay available and the Pro links lock again.

These rules have a single implementation in `core/src/main/java/np/freeappsnepal/core/domain/`
(`DownloadAccessResolver`, `PricingCalculator`, `SubscriptionEvaluator`) and are pinned by unit tests
in `core/src/test/`.

## What is trusted

| Value | Source of truth |
| --- | --- |
| Price and discount | The `plans/{planId}` document, recomputed by the backend per order |
| Payment outcome | The Khalti or eSewa API, queried by the backend |
| Subscription status | `subscriptions/` and `userSubscriptions/`, written only by the backend |
| Pro download URL | `secureLinks/{itemId}`, readable only by the backend |
| Administrator role | A Firebase custom claim, verified by functions and by Firestore rules |
| Current time for expiry | The server clock, stored alongside the subscription |

The Android clients never send a price, never declare a payment as successful, and never assert an
administrator role. Firestore rules deny client writes to listings, plans, subscriptions, orders and
`secureLinks`, so a modified client cannot change any of them either.

## External URLs are opened verbatim

`LinkOpener` hands the administrator's URL to the system with `ACTION_VIEW`. Nothing is rewritten,
shortened, proxied or replaced, and the marketplace never injects or bypasses an advertisement. When
the administrator configures a monetised download page, that page keeps control of its own
advertising.

A tap on a download button proves only that the URL was opened. The file is transferred by a third
party and cannot be observed from here, so the analytics record download clicks, not completed
downloads.

## Pro URL protection, stated honestly

The Pro URL is stored in `secureLinks`, which no client can read, and is returned only by the
`getProDownloadLink` callable after the backend has re-verified an active subscription against a
trusted clock. This prevents unauthorised access through the application. It does not make an
external URL permanently secret: once a legitimate subscriber has the URL, it can be copied. The
goal is application and backend access control, not impossible secrecy.

## Payments

Khalti and eSewa are integrated for real. `createProOrder` prices the order from the plan document
and calls the provider. `verifyKhaltiPayment` and `verifyEsewaPayment` query the provider, check the
paid amount against the stored order amount, and only then activate a subscription. There is no code
path in either app that can activate Pro without a verified payment.

Provider credentials are Cloud Functions secrets, set with the Firebase CLI. They are never bundled
into an Android app, and there is no client configuration point where a key could leak. Configure
them before deploying:

```
firebase functions:secrets:set KHALTI_SECRET_KEY
firebase functions:secrets:set KHALTI_BASE_URL
firebase functions:secrets:set ESEWA_SECRET_KEY
firebase functions:secrets:set ESEWA_PRODUCT_CODE
firebase functions:secrets:set ESEWA_BASE_URL
firebase functions:secrets:set ESEWA_STATUS_URL
```

## Repository layout

```
core/            models, mappers, repositories, domain rules, shared UI, DI
app-user/        marketplace: home, apps, games, categories, search, detail, profile, Pro, payment
app-admin/       console: dashboard, items, categories, plan, promotions, subscribers, moderation
firebase/
  firestore.rules       client read/write policy
  firestore.indexes.json composite indexes used by the catalogue queries
  storage.rules         admin-only artwork uploads, public image reads
  functions/src/        pricing, payment initiation and verification, Pro link release, aggregates
docs/            operator and developer documentation
```

## Building

Requirements: JDK 17 or newer, the Android SDK, and a Firebase project.

```
./gradlew :app-user:assembleDebug :app-admin:assembleDebug
./gradlew :core:testDebugUnitTest
./gradlew :core:lintDebug
```

Place `google-services.json` for each Android package in `app-user/` and `app-admin/`. Those files
are ignored by version control. See `docs/SETUP.md` for the full sequence, including the first
administrator account and deploying the backend.

## Documentation

- `docs/SETUP.md` — project setup, Firebase configuration and first deploy
- `docs/ADMIN_GUIDE.md` — how an operator runs the catalogue
- `docs/ARCHITECTURE.md` — module structure, data flow and security model
- `docs/DATA_MODEL.md` — every Firestore collection and field
- `docs/PAYMENTS.md` — Khalti and eSewa integration, verification and reconciliation
- `docs/SECURITY.md` — the security model and its explicit limits
