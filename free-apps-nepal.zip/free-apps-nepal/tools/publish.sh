#!/usr/bin/env bash
#
# Publishes this project to a GitHub repository from an Android phone using Termux.
#
# Why this exists: GitHub's web uploader cannot upload folders from Android, and an Android
# project is nothing but folders, so uploading it that way is impossible. Git from Termux
# copies the whole tree in one step.
#
# Usage, inside Termux after downloading and extracting the zip:
#   bash tools/publish.sh https://github.com/USERNAME/free-apps-nepal.git
#
# Git will ask for a username and a password. The password is your personal access token,
# not your account password. This script never writes a credential to disk itself.

set -u

REPO_URL="${1:-}"

if [ -z "$REPO_URL" ]; then
  echo ""
  echo "  Usage: bash tools/publish.sh https://github.com/USERNAME/free-apps-nepal.git"
  echo ""
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${TMPDIR:-/tmp}/fan-publish"
CLONE="$WORK/repo"
STAGE="$WORK/stage"

echo ""
echo "  Project : $ROOT"
echo "  Remote  : $REPO_URL"
echo ""

rm -rf "$WORK"
mkdir -p "$WORK"

echo "  Cloning the repository..."

if ! git clone "$REPO_URL" "$CLONE"; then
  echo ""
  echo "  Clone failed. Check that the repository exists and that the token has"
  echo "  Contents: Read and write permission on it."
  echo ""
  exit 1
fi

echo "  Preparing the files to publish..."

# The tree is staged in a separate directory so that the cloned repository's own .git is
# never touched. Copying the source .git over it would detach the clone from its remote.
mkdir -p "$STAGE"
cp -a "$ROOT"/. "$STAGE"/

# Build output and the source's own git history must not be published.
rm -rf "$STAGE/.git" "$STAGE/.gradle" "$STAGE/.kotlin"
find "$STAGE" -type d -name build -prune -exec rm -rf {} + 2>/dev/null
find "$STAGE" -type d -name node_modules -prune -exec rm -rf {} + 2>/dev/null

cp -a "$STAGE"/. "$CLONE"/

cd "$CLONE" || exit 1

# A brand new repository has no commits yet, so there is no branch to read. Naming it main
# matches the default GitHub creates.
if git rev-parse --verify HEAD >/dev/null 2>&1; then
  BRANCH="$(git symbolic-ref --short HEAD 2>/dev/null || echo main)"
else
  BRANCH="main"
  git symbolic-ref HEAD "refs/heads/$BRANCH"
fi

git add -A

if git diff --cached --quiet; then
  echo ""
  echo "  Nothing to publish. The repository is already up to date."
  echo ""
  exit 0
fi

COUNT="$(git diff --cached --name-only | wc -l | tr -d ' ')"

git -c user.name="${GIT_AUTHOR_NAME:-Free Apps Nepal}" \
    -c user.email="${GIT_AUTHOR_EMAIL:-dev@freeappsnepal.app}" \
    commit -q -m "Publish Free Apps Nepal project"

echo ""
echo "  Files staged : $COUNT"
echo "  Branch       : $BRANCH"
echo ""

echo "  Pushing..."
if git push -u origin "$BRANCH"; then
  echo ""
  echo "  Done. Open the repository and use the Actions tab to build the APKs."
  echo ""
else
  echo ""
  echo "  Push failed. If it asked for a password, give your personal access token, not"
  echo "  your account password."
  echo ""
  exit 1
fi
