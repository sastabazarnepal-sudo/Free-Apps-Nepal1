#!/usr/bin/env node
/**
 * Grants or revokes the `admin` custom claim on a Firebase Authentication account.
 *
 * This runs from your own computer with the Admin SDK, so it bypasses the client rules by
 * design. It exists because the claim must be minted server side: if the Android app could
 * set it, anyone could make themselves an administrator.
 *
 * It needs no Cloud Functions deployment and no billing account. The only requirement is a
 * service account key, which the Firebase console generates for you.
 *
 * Usage:
 *   GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json \
 *     node tools/grant-admin.js you@example.com
 *
 *   node tools/grant-admin.js you@example.com --revoke
 */

const fs = require("node:fs");
const path = require("node:path");

function fail(message) {
  console.error(`\n[error] ${message}\n`);
  process.exit(1);
}

const email = process.argv[2];
const revoke = process.argv.includes("--revoke");

if (!email || email.startsWith("-")) {
  fail(
    "Email address is required.\n" +
      "  node tools/grant-admin.js you@example.com\n" +
      "  node tools/grant-admin.js you@example.com --revoke"
  );
}

const credentialsPath = process.env.GOOGLE_APPLICATION_CREDENTIALS;
if (!credentialsPath) {
  fail(
    "GOOGLE_APPLICATION_CREDENTIALS is not set.\n\n" +
      "  1. Firebase console -> Project settings -> Service accounts\n" +
      "  2. Generate new private key, and save the .json somewhere safe\n" +
      "  3. Run:\n\n" +
      "     GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json node tools/grant-admin.js " +
      email +
      "\n"
  );
}

if (!fs.existsSync(credentialsPath)) {
  fail(`Service account key not found: ${credentialsPath}`);
}

let projectId;
try {
  projectId = JSON.parse(fs.readFileSync(credentialsPath, "utf8")).project_id;
} catch (error) {
  fail(`Could not read the service account key: ${error.message}`);
}

let admin;
try {
  admin = require(path.join(__dirname, "node_modules", "firebase-admin"));
} catch (error) {
  fail(
    "firebase-admin is not installed. Run:\n\n" +
      "  cd tools && npm install\n"
  );
}

admin.initializeApp({ credential: admin.credential.applicationDefault() });

async function main() {
  const user = await admin.auth().getUserByEmail(email);
  const existing = (user.customClaims || {});
  const next = { ...existing };

  if (revoke) {
    delete next.admin;
    if (next.role === "admin") delete next.role;
  } else {
    next.admin = true;
    next.role = "admin";
  }

  await admin.auth().setCustomUserClaims(user.uid, next);

  // The mirror document is what security rules and the dashboard read. The backend keeps it in
  // sync when the claim changes, so this script does the same thing.
  await admin.firestore().collection("users").doc(user.uid).set(
    { admin: !revoke, updatedAt: admin.firestore.FieldValue.serverTimestamp() },
    { merge: true }
  );

  console.log("");
  console.log(`  Project      : ${projectId}`);
  console.log(`  Email        : ${user.email}`);
  console.log(`  UID          : ${user.uid}`);
  console.log(`  admin claim  : ${revoke ? "removed" : "granted"}`);
  console.log("");
  console.log(
    revoke
      ? "  Sign out and back in to drop the claim from the cached token."
      : "  Sign out and back in inside the admin app so it receives a fresh token."
  );
  console.log("");
}

main().catch((error) => {
  if (error && error.code === "auth/user-not-found") {
    fail(
      `No account exists for ${email}.\n` +
        "Register that account in the app first, or create it in the Firebase console."
    );
  }
  fail(error && error.message ? error.message : String(error));
});
