buildscript {
    configurations.classpath {
        // The Hilt Gradle plugin 2.52 calls ClassName.canonicalName(), which only exists in
        // javapoet 1.13.0. An older javapoet can be pulled onto the plugin classpath transitively and
        // makes the dependency aggregation task fail at execution time.
        resolutionStrategy.force("com.squareup:javapoet:1.13.0")
    }
}

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
    alias(libs.plugins.google.services) apply false
    alias(libs.plugins.crashlytics) apply false
}
