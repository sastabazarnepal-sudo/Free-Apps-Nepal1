package np.freeappsnepal.core

import com.google.firebase.Timestamp
import np.freeappsnepal.core.domain.DownloadAccessResolver
import np.freeappsnepal.core.domain.DownloadTarget
import np.freeappsnepal.core.domain.PricingCalculator
import np.freeappsnepal.core.domain.SubscriptionEvaluator
import np.freeappsnepal.core.domain.ProState
import np.freeappsnepal.core.domain.primaryTarget
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.PaymentMethod
import np.freeappsnepal.core.model.Plan
import np.freeappsnepal.core.model.SubscriptionStatus
import np.freeappsnepal.core.model.UserSubscription
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The subscription model is the commercial core of the product, so the rules that cannot change
 * without changing the business are pinned here rather than left to manual testing.
 */
class BusinessRulesTest {

    private fun item(
        free: Boolean = false,
        pro: Boolean = false,
        freeUrl: String = "https://mediafire.example/free"
    ) = AppItem(
        itemId = "item_1",
        type = ItemType.APP,
        name = "Photo Editor Pro",
        freeEnabled = free,
        freeDownloadUrl = freeUrl,
        proEnabled = pro
    )

    @Test
    fun `free link targets the configured free url for a non subscriber`() {
        val listing = item(free = true, pro = true)
        assertEquals(DownloadTarget.FREE, DownloadAccessResolver.target(listing, hasActiveSubscription = false))
    }

    @Test
    fun `free link stays free for an active subscriber`() {
        val listing = item(free = true, pro = true)
        assertEquals(DownloadTarget.FREE, DownloadAccessResolver.target(listing, hasActiveSubscription = true))
    }

    @Test
    fun `pro download is locked without an active subscription`() {
        val listing = item(pro = true)
        val access = DownloadAccessResolver.resolve(listing, hasActiveSubscription = false)
        assertTrue(access.showProButton)
        assertFalse(access.proDownloadUnlocked)
        assertNotNull(access.proLockedReason)
        assertEquals(DownloadTarget.LOCKED, DownloadAccessResolver.target(listing, hasActiveSubscription = false))
    }

    @Test
    fun `pro download is unlocked with an active subscription and needs no extra purchase`() {
        val proOnly = item(pro = true)
        val access = DownloadAccessResolver.resolve(proOnly, hasActiveSubscription = true)
        assertTrue(access.showProButton)
        assertTrue(access.proDownloadUnlocked)
        assertNull(access.proLockedReason)
        assertEquals(DownloadTarget.PRO, DownloadAccessResolver.target(proOnly, hasActiveSubscription = true))

        // When a free version exists the primary action stays the free link even for a subscriber,
        // while the Pro button is independently unlocked. Pro does not replace the free link.
        val both = item(free = true, pro = true)
        val bothAccess = DownloadAccessResolver.resolve(both, hasActiveSubscription = true)
        assertTrue(bothAccess.proDownloadUnlocked)
        assertEquals(DownloadTarget.FREE, DownloadAccessResolver.target(both, hasActiveSubscription = true))
        // The free button stays the primary action; the unlocked Pro button is rendered alongside it.
        assertEquals(DownloadTarget.FREE, bothAccess.primaryTarget)
        assertTrue(bothAccess.showFreeButton)
        assertTrue(bothAccess.showProButton)
    }

    @Test
    fun `a pro only listing is visible but locked to a non subscriber`() {
        val listing = item(pro = true)
        val access = DownloadAccessResolver.resolve(listing, hasActiveSubscription = false)
        assertFalse(access.showFreeButton)
        assertTrue(access.showProButton)
        assertFalse(access.nothingConfigured)
    }

    @Test
    fun `an expired subscriber is told to renew rather than to subscribe`() {
        val listing = item(pro = true)
        val access = DownloadAccessResolver.resolve(
            listing,
            hasActiveSubscription = false,
            subscriptionEverActive = true
        )
        assertEquals(DownloadAccessResolver.PRO_LOCKED_EXPIRED, access.proLockedReason)
    }

    @Test
    fun `a free only listing shows no pro button`() {
        val listing = item(free = true)
        val access = DownloadAccessResolver.resolve(listing, hasActiveSubscription = true)
        assertTrue(access.showFreeButton)
        assertFalse(access.showProButton)
        assertFalse(access.proDownloadUnlocked)
    }

    @Test
    fun `a blank free url does not count as a free version`() {
        val listing = item(free = true, freeUrl = "   ")
        assertFalse(listing.hasFree)
        assertEquals(DownloadTarget.NOT_CONFIGURED, DownloadAccessResolver.target(listing, false))
    }

    @Test
    fun `discount applies only inside the configured window`() {
        val start = 1_000_000L
        val end = 2_000_000L
        val plan = Plan(
            pricePaisa = 9900L,
            discountEnabled = true,
            discountPercentage = 30.0,
            discountStartAt = Timestamp(start / 1000, 0),
            discountEndAt = Timestamp(end / 1000, 0)
        )

        assertEquals(9900L, PricingCalculator.quote(plan, start - 1).finalPaisa)
        assertEquals(6930L, PricingCalculator.quote(plan, start + 1).finalPaisa)
        assertEquals(6930L, PricingCalculator.quote(plan, end - 1).finalPaisa)
        assertEquals(9900L, PricingCalculator.quote(plan, end + 1).finalPaisa)
    }

    @Test
    fun `a disabled discount never reduces the price`() {
        val plan = Plan(pricePaisa = 9900L, discountEnabled = false, discountPercentage = 50.0)
        val quote = PricingCalculator.quote(plan, 5_000_000L)
        assertEquals(9900L, quote.finalPaisa)
        assertFalse(quote.hasDiscount)
    }

    @Test
    fun `subscription is active only while the server anchored expiry is in the future`() {
        val now = 10_000_000L
        val active = UserSubscription(
            status = SubscriptionStatus.ACTIVE,
            active = true,
            expiresAt = Timestamp((now + 60_000) / 1000, 0),
            startAt = Timestamp((now - 60_000) / 1000, 0),
            serverTimeMillis = now
        )
        assertTrue(active.isActiveWithClockSkew(now))
        assertFalse(active.isActiveWithClockSkew(now + 120_000))

        val expired = active.copy(expiresAt = Timestamp((now - 1) / 1000, 0))
        assertFalse(expired.isActiveWithClockSkew(now))
    }

    @Test
    fun `a pending order never reports an active subscription`() {
        val status = SubscriptionEvaluator.evaluate(
            UserSubscription(status = SubscriptionStatus.PENDING, active = false),
            deviceNowMillis = 1_000L
        )
        assertEquals(ProState.PENDING, status.state)
        assertFalse(status.isActive)
    }

    @Test
    fun `an expired subscription is reported as expired and renewable`() {
        val subscription = UserSubscription(
            status = SubscriptionStatus.EXPIRED,
            active = false,
            paymentMethod = PaymentMethod.ESEWA
        )
        val status = SubscriptionEvaluator.evaluate(subscription, deviceNowMillis = 1_000L)
        assertEquals(ProState.EXPIRED, status.state)
        assertFalse(status.isActive)
        assertTrue(SubscriptionEvaluator.everActive(status))
    }
}
