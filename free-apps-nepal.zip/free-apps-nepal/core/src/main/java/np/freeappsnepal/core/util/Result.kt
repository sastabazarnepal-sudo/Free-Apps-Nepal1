package np.freeappsnepal.core.util

/** Small result wrapper so repositories can return errors without throwing across layers. */
sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Failure(val error: AppError) : AppResult<Nothing>

    fun getOrNull(): T? = (this as? Success)?.data

    fun errorOrNull(): AppError? = (this as? Failure)?.error

    fun get(): T = when (this) {
        is Success -> data
        is Failure -> throw error.toException()
    }
}

object AppResultKt {
    fun <T> success(value: T): AppResult<T> = AppResult.Success(value)
    fun failure(error: AppError): AppResult<Nothing> = AppResult.Failure(error)
}

fun <T> AppResult<T>.getOrThrowCustom(): T = when (this) {
    is AppResult.Success -> data
    is AppResult.Failure -> throw error.toException()
}
