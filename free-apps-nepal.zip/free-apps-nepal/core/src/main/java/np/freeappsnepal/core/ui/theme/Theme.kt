package np.freeappsnepal.core.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightScheme = lightColorScheme(
    primary = FanColors.CoralRed,
    onPrimary = FanColors.Surface,
    primaryContainer = FanColors.RedContainer,
    onPrimaryContainer = FanColors.RedOnContainer,
    secondary = FanColors.DeepRed,
    onSecondary = FanColors.Surface,
    tertiary = FanColors.Gold,
    onTertiary = FanColors.GoldOn,
    background = FanColors.NeutralBackground,
    onBackground = FanColors.TextPrimary,
    surface = FanColors.Surface,
    onSurface = FanColors.TextPrimary,
    surfaceVariant = FanColors.SurfaceVariant,
    onSurfaceVariant = FanColors.TextSecondary,
    outline = FanColors.Outline,
    error = FanColors.Error,
    onError = FanColors.Surface
)

private val DarkScheme = darkColorScheme(
    primary = FanColors.CoralRed,
    onPrimary = FanColors.Surface,
    primaryContainer = FanColors.DeepRed,
    onPrimaryContainer = FanColors.Surface,
    secondary = FanColors.CoralRedDark,
    onSecondary = FanColors.Surface,
    tertiary = FanColors.GoldBright,
    onTertiary = FanColors.GoldOn,
    background = FanColors.TextPrimary,
    onBackground = FanColors.Surface,
    surface = FanColors.TextPrimary,
    onSurface = FanColors.Surface,
    surfaceVariant = FanColors.TextSecondary,
    onSurfaceVariant = FanColors.SurfaceVariant,
    outline = FanColors.TextSecondary,
    error = FanColors.Error,
    onError = FanColors.Surface
)

/**
 * Theme entry point shared by both applications.
 *
 * [proMode] switches the accent to the gold family on Pro surfaces. It is applied only to the
 * premium screens and cards so the rest of the app stays consistent and lightweight.
 */
@Composable
fun FanTheme(
    proMode: Boolean = false,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val base = if (darkTheme) DarkScheme else LightScheme
    val scheme = if (proMode) {
        base.copy(
            primary = FanColors.Gold,
            onPrimary = FanColors.GoldOn,
            primaryContainer = FanColors.GoldSurface,
            onPrimaryContainer = FanColors.GoldOn,
            tertiary = FanColors.GoldDeep
        )
    } else {
        base
    }

    MaterialTheme(
        colorScheme = scheme,
        typography = FanTypography,
        shapes = FanShapes,
        content = content
    )
}
