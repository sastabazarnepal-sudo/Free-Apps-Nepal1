package np.freeappsnepal.core.data

import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import np.freeappsnepal.core.model.FirestoreCollections
import np.freeappsnepal.core.model.ItemType

/**
 * The single place that knows Firestore document paths.
 *
 * Keeping paths here means a collection rename is a one file change and never leaks into the UI
 * layer.
 */
class FirestoreRefs(private val firestore: FirebaseFirestore) {

    fun items(type: ItemType): CollectionReference = firestore.collection(type.collection)

    fun item(type: ItemType, itemId: String): DocumentReference = items(type).document(itemId)

    fun categories(): CollectionReference = firestore.collection(FirestoreCollections.CATEGORIES)

    fun category(categoryId: String): DocumentReference = categories().document(categoryId)

    fun plans(): CollectionReference = firestore.collection(FirestoreCollections.PLANS)

    fun plan(planId: String): DocumentReference = plans().document(planId)

    fun subscriptions(): CollectionReference = firestore.collection(FirestoreCollections.SUBSCRIPTIONS)

    fun subscription(subscriptionId: String): DocumentReference =
        subscriptions().document(subscriptionId)

    fun userSubscriptions(): CollectionReference =
        firestore.collection(FirestoreCollections.USER_SUBSCRIPTIONS)

    fun userSubscription(userId: String): DocumentReference = userSubscriptions().document(userId)

    fun orders(): CollectionReference = firestore.collection(FirestoreCollections.ORDERS)

    fun order(orderId: String): DocumentReference = orders().document(orderId)

    fun users(): CollectionReference = firestore.collection(FirestoreCollections.USERS)

    fun user(userId: String): DocumentReference = users().document(userId)

    fun reviews(): CollectionReference = firestore.collection(FirestoreCollections.REVIEWS)

    /**
     * Collection group query over every `reviews` subcollection. Used by the admin moderation queue
     * so reviews live only in the listing subcollection and are never duplicated.
     */
    fun reviewsCollectionGroup(): Query = firestore.collectionGroup(FirestoreCollections.REVIEWS)

    fun itemReviews(itemType: ItemType, itemId: String): CollectionReference =
        item(itemType, itemId).collection(FirestoreCollections.REVIEWS)

    fun promotions(): CollectionReference = firestore.collection(FirestoreCollections.PROMOTIONS)

    fun promotion(promotionId: String): DocumentReference = promotions().document(promotionId)

    fun favorites(userId: String): CollectionReference =
        firestore.collection(FirestoreCollections.FAVORITES)
            .document(userId)
            .collection(FirestoreCollections.FAVORITE_ITEMS)

    fun statistics(): CollectionReference = firestore.collection(FirestoreCollections.STATISTICS)

    fun settings(): CollectionReference = firestore.collection(FirestoreCollections.SETTINGS)

    fun appSettings(): DocumentReference =
        settings().document(FirestoreCollections.SETTINGS_APP_DOC)

    fun counters(): DocumentReference =
        settings().document(FirestoreCollections.SETTINGS_COUNTERS_DOC)

    /**
     * `secureLinks` holds the administrator configured Pro download URL. Security rules deny this
     * collection to every client; only the backend and an administrator may read it.
     */
    fun secureLinks(): CollectionReference =
        firestore.collection(FirestoreCollections.SECURE_LINKS)

    fun secureLink(itemId: String): DocumentReference = secureLinks().document(itemId)

    fun publishedItemsQuery(type: ItemType): Query =
        items(type).whereEqualTo("published", true)

    fun activePromotionsQuery(): Query =
        promotions().whereEqualTo("enabled", true).orderBy("priority", Query.Direction.DESCENDING)
}
