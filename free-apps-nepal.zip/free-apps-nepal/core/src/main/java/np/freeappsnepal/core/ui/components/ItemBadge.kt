package np.freeappsnepal.core.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Badge kinds rendered on a listing card and on the detail screen. */
enum class BadgeKind {
    FREE, PRO, NEW, POPULAR, FEATURED
}

/**
 * A catalogue badge.
 *
 * Badges are rendered only when the corresponding administrator flag is enabled. Nothing here
 * invents a badge for a listing that does not own one.
 */
@Composable
fun ItemBadge(
    kind: BadgeKind,
    modifier: Modifier = Modifier
) {
    val background: Color
    val foreground: Color
    val label: String

    when (kind) {
        BadgeKind.FREE -> {
            background = MaterialTheme.colorScheme.primaryContainer
            foreground = MaterialTheme.colorScheme.onPrimaryContainer
            label = "FREE"
        }
        BadgeKind.PRO -> {
            background = np.freeappsnepal.core.ui.theme.FanColors.Gold
            foreground = np.freeappsnepal.core.ui.theme.FanColors.GoldOn
            label = "PRO"
        }
        BadgeKind.NEW -> {
            background = np.freeappsnepal.core.ui.theme.FanColors.Info
            foreground = Color.White
            label = "NEW"
        }
        BadgeKind.POPULAR -> {
            background = np.freeappsnepal.core.ui.theme.FanColors.Warning
            foreground = Color.White
            label = "POPULAR"
        }
        BadgeKind.FEATURED -> {
            background = np.freeappsnepal.core.ui.theme.FanColors.DeepRed
            foreground = Color.White
            label = "FEATURED"
        }
    }

    Box(
        modifier = modifier
            .clip(MaterialTheme.shapes.extraSmall)
            .background(background)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            color = foreground,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold
        )
    }
}
