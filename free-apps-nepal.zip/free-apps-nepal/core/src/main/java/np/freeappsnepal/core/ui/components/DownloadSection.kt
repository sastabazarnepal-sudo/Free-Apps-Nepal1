package np.freeappsnepal.core.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import np.freeappsnepal.core.domain.DownloadAccess
import np.freeappsnepal.core.ui.theme.FanColors

/**
 * The download section of a detail screen.
 *
 * Behaviour, in full:
 *  - the Free button appears whenever the administrator enabled a free version, and it opens the
 *    exact configured URL for every user, free or Pro. Being a Pro subscriber never converts the
 *    free link into the Pro link and never redirects to it.
 *  - the Pro button appears whenever the administrator enabled a Pro version, for every user, so a
 *    user without a subscription still sees that the Pro version exists.
 *  - the Pro button is enabled only for a user with an active subscription. While locked it is
 *    visibly disabled and shows the reason instead of performing any action.
 * No advertisement step and no in app purchase sits behind the Pro button.
 */
@Composable
fun DownloadSection(
    access: DownloadAccess,
    onFreeDownload: () -> Unit,
    onProDownload: () -> Unit,
    onSubscribe: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        if (access.showFreeButton) {
            Button(
                onClick = onFreeDownload,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("FREE DOWNLOAD", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.padding(top = 10.dp))
        }

        if (access.showProButton) {
            if (access.proDownloadUnlocked) {
                Button(
                    onClick = onProDownload,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FanColors.Gold,
                        contentColor = FanColors.GoldOn
                    )
                ) {
                    Icon(
                        Icons.Filled.WorkspacePremium,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("PRO DOWNLOAD", fontWeight = FontWeight.Bold)
                }
                Text(
                    text = "Included with your monthly Pro subscription. No extra ad, no extra payment.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
            } else {
                OutlinedButton(
                    onClick = {},
                    enabled = false,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("PRO DOWNLOAD", fontWeight = FontWeight.Bold)
                }
                Text(
                    text = access.proLockedReason.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
                TextButton(onClick = onSubscribe) {
                    Text("Get Pro", fontWeight = FontWeight.SemiBold, color = Color.Unspecified)
                }
            }
        }

        if (access.nothingConfigured) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "No download link has been configured for this listing yet.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
