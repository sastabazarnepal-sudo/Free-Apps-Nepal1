package np.freeappsnepal.core.data.repo

import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.data.FirestoreRefs
import np.freeappsnepal.core.data.Mappers
import np.freeappsnepal.core.model.Category
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.util.AppError
import np.freeappsnepal.core.util.AppResult
import np.freeappsnepal.core.util.AppResultKt
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CategoryRepository @Inject constructor(
    private val refs: FirestoreRefs
) {
    suspend fun enabledCategories(): AppResult<List<Category>> = runCatching {
        refs.categories()
            .whereEqualTo("enabled", true)
            .orderBy("order", Query.Direction.ASCENDING)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.category(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun categoriesFor(type: ItemType): AppResult<List<Category>> = runCatching {
        when (val result = enabledCategories()) {
            is AppResult.Success -> result.data.filter { it.appliesTo(type) }
            is AppResult.Failure -> throw result.error.toException()
        }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun allCategories(): AppResult<List<Category>> = runCatching {
        refs.categories()
            .orderBy("order", Query.Direction.ASCENDING)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.category(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })
}
