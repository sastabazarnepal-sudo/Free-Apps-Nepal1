package np.freeappsnepal.core.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Free Apps Nepal palette.
 *
 * Free users see the red family. Pro surfaces use the gold family. Both are original colours: no
 * Google Play branding, artwork or proprietary shape language is reproduced.
 */
object FanColors {
    val CoralRed = Color(0xFFE53935)
    val CoralRedDark = Color(0xFFC62828)
    val DeepRed = Color(0xFF8E1B1B)
    val RedContainer = Color(0xFFFFEBEE)
    val RedOnContainer = Color(0xFF5F1212)

    val Gold = Color(0xFFC9A227)
    val GoldBright = Color(0xFFF0C74B)
    val GoldDeep = Color(0xFF8A6D1B)
    val GoldSurface = Color(0xFFFFF8E1)
    val GoldOn = Color(0xFF3A2E05)

    val NeutralBackground = Color(0xFFF7F7F9)
    val Surface = Color(0xFFFFFFFF)
    val SurfaceVariant = Color(0xFFF0F0F4)
    val Outline = Color(0xFFE2E2E8)

    val TextPrimary = Color(0xFF17171C)
    val TextSecondary = Color(0xFF5C5C66)
    val TextDisabled = Color(0xFF9A9AA3)

    val Success = Color(0xFF1E7A3C)
    val Warning = Color(0xFFB26A00)
    val Error = Color(0xFFB3261E)
    val Info = Color(0xFF1A5FB4)

    val LockedOverlay = Color(0x14000000)
    val Scrim = Color(0x66000000)
}
