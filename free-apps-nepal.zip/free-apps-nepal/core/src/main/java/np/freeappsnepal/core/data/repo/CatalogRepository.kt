package np.freeappsnepal.core.data.repo

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.data.FirestoreRefs
import np.freeappsnepal.core.data.Mappers
import np.freeappsnepal.core.domain.SearchFilter
import np.freeappsnepal.core.domain.SearchRequest
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.util.AppError
import np.freeappsnepal.core.util.AppResult
import np.freeappsnepal.core.util.AppResultKt
import np.freeappsnepal.core.util.Constants
import javax.inject.Inject
import javax.inject.Singleton

/** Cursor based page of catalogue listings. */
data class ItemPage(
    val items: List<AppItem>,
    val lastDocument: DocumentSnapshot?,
    val hasMore: Boolean
) {
    companion object {
        val EMPTY = ItemPage(emptyList(), null, false)
    }
}

/**
 * Read only catalogue access.
 *
 * Every query requires `published == true`. Pro listings are never filtered out: a user without a
 * subscription still sees the listing, only the Pro download action is gated in the UI.
 */
@Singleton
class CatalogRepository @Inject constructor(
    private val refs: FirestoreRefs,
    private val firestore: FirebaseFirestore
) {

    suspend fun page(
        type: ItemType,
        sortField: String = FIELD_CREATED_AT,
        direction: Query.Direction = Query.Direction.DESCENDING,
        limit: Long = Constants.DEFAULT_PAGE_SIZE.toLong(),
        startAfter: DocumentSnapshot? = null
    ): AppResult<ItemPage> = runCatching {
        var query = refs.publishedItemsQuery(type)
            .orderBy(sortField, direction)
            .limit(limit)
        if (startAfter != null) query = query.startAfter(startAfter)
        toPage(query.get().await(), type, limit)
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun flagged(
        type: ItemType,
        field: String,
        limit: Long = Constants.DEFAULT_PAGE_SIZE.toLong()
    ): AppResult<List<AppItem>> = runCatching {
        refs.items(type)
            .whereEqualTo("published", true)
            .whereEqualTo(field, true)
            .orderBy(FIELD_CREATED_AT, Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.item(it, type) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun byOffering(
        type: ItemType,
        freeOnly: Boolean,
        limit: Long = Constants.DEFAULT_PAGE_SIZE.toLong(),
        startAfter: DocumentSnapshot? = null
    ): AppResult<ItemPage> = runCatching {
        val field = if (freeOnly) "freeEnabled" else "proEnabled"
        var query = refs.items(type)
            .whereEqualTo("published", true)
            .whereEqualTo(field, true)
            .orderBy(FIELD_CREATED_AT, Query.Direction.DESCENDING)
            .limit(limit)
        if (startAfter != null) query = query.startAfter(startAfter)
        toPage(query.get().await(), type, limit)
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun byCategory(
        type: ItemType,
        categoryId: String,
        limit: Long = Constants.DEFAULT_PAGE_SIZE.toLong(),
        startAfter: DocumentSnapshot? = null
    ): AppResult<ItemPage> = runCatching {
        var query = refs.items(type)
            .whereEqualTo("published", true)
            .whereEqualTo("categoryId", categoryId)
            .orderBy(FIELD_CREATED_AT, Query.Direction.DESCENDING)
            .limit(limit)
        if (startAfter != null) query = query.startAfter(startAfter)
        toPage(query.get().await(), type, limit)
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun detail(type: ItemType, itemId: String): AppResult<AppItem> = runCatching {
        val snapshot = refs.item(type, itemId).get().await()
        val item = Mappers.item(snapshot, type)
        if (item == null || !item.published) {
            throw AppError.NotFound.toException()
        }
        item
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    /**
     * Search performs at most two queries per item collection and merges them:
     *  - a prefix range query on `nameLower`
     *  - a keywords array-contains query, which also matches developer and category names
     * Both include Pro listings.
     */
    suspend fun search(request: SearchRequest): AppResult<ItemPage> = runCatching {
        if (request.isBlank) return@runCatching ItemPage.EMPTY
        val limit = request.pageSize.toLong()
        val merged = LinkedHashMap<String, AppItem>()

        val types = request.filter.itemType?.let { listOf(it) }
            ?: listOf(ItemType.APP, ItemType.GAME)
        types.forEach { itemType -> collectMatches(merged, itemType, request, limit) }

        val filtered = merged.values.filter { item ->
            val matchesFilter = when (request.filter) {
                SearchFilter.FREE -> item.hasFree
                SearchFilter.PRO -> item.hasPro
                else -> true
            }
            matchesFilter && (request.categoryId == null || item.categoryId == request.categoryId)
        }
        ItemPage(filtered.take(request.pageSize), null, false)
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    private suspend fun collectMatches(
        target: MutableMap<String, AppItem>,
        type: ItemType,
        request: SearchRequest,
        limit: Long
    ) {
        val term = request.normalizedQuery
        val prefix = runCatching {
            refs.items(type)
                .whereEqualTo("published", true)
                .whereGreaterThanOrEqualTo("nameLower", term)
                .whereLessThanOrEqualTo("nameLower", term + HIGH_CODEPOINT)
                .orderBy("nameLower", Query.Direction.ASCENDING)
                .limit(limit)
                .get()
                .await()
        }.getOrNull()

        if (prefix != null) {
            prefix.documents.mapNotNull { Mappers.item(it, type) }
                .forEach { target[it.itemId] = it }
        } else {
            // When the composite index for the range query is not deployed yet, fall back to a
            // limited scan filtered on the client so search degrades instead of failing outright.
            runCatching {
                refs.items(type).whereEqualTo("published", true).limit(limit).get().await()
            }.getOrNull()?.documents?.mapNotNull { Mappers.item(it, type) }
                ?.filter { it.nameLower.contains(term) }
                ?.forEach { target[it.itemId] = it }
        }

        val keywordMatch = runCatching {
            refs.items(type)
                .whereEqualTo("published", true)
                .whereArrayContains("searchKeywords", term)
                .limit(limit)
                .get()
                .await()
        }.getOrNull()

        keywordMatch?.documents?.mapNotNull { Mappers.item(it, type) }
            ?.forEach { target[it.itemId] = it }
    }

    /** Records a detail view. The counter is owned by the backend; the client only asks for it. */
    suspend fun requestViewIncrement(type: ItemType, itemId: String): Boolean =
        runCatching {
            firestore.runTransaction { transaction ->
                val reference = refs.item(type, itemId)
                val snapshot = transaction.get(reference)
                if (!snapshot.exists()) return@runTransaction false
                transaction.update(reference, "viewCount", (snapshot.getLong("viewCount") ?: 0L) + 1L)
                true
            }.await() ?: false
        }.getOrDefault(false)

    private fun toPage(snapshot: QuerySnapshot, type: ItemType, limit: Long): ItemPage {
        val items = snapshot.documents.mapNotNull { Mappers.item(it, type) }
        return ItemPage(
            items = items,
            lastDocument = snapshot.documents.lastOrNull(),
            hasMore = snapshot.documents.size.toLong() >= limit
        )
    }

    companion object {
        const val FIELD_CREATED_AT = "createdAt"
        const val FIELD_VIEW_COUNT = "viewCount"
        const val FIELD_POPULAR = "popular"
        const val FIELD_FEATURED = "featured"
        const val FIELD_NEW = "isNew"
        private const val HIGH_CODEPOINT = "\uf8ff"
    }
}
