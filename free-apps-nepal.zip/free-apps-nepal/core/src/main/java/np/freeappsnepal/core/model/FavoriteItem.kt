package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp

data class FavoriteItem(
    @DocumentId
    var itemId: String = "",
    var type: ItemType = ItemType.APP,
    var name: String = "",
    var developerName: String = "",
    var iconUrl: String = "",
    var freeEnabled: Boolean = false,
    var proEnabled: Boolean = false,
    @ServerTimestamp
    var addedAt: Timestamp? = null
)
