package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp

/**
 * The single monthly Pro plan.
 *
 * Prices are held in paisa (1 NPR = 100 paisa) so no monetary value is ever stored in a floating
 * point type. The values here are used for display and for the admin editor; the amount actually
 * charged is recomputed by the backend from this document and never taken from a client.
 */
data class Plan(
    @DocumentId
    var planId: String = DEFAULT_PLAN_ID,
    var name: String = "Free Apps Nepal Pro",
    var description: String = "",
    var currency: String = "NPR",
    var pricePaisa: Long = 9900L,
    var durationDays: Int = 30,
    var enabled: Boolean = true,
    var benefits: List<String> = emptyList(),
    var discountEnabled: Boolean = false,
    var discountPercentage: Double = 0.0,
    var discountStartAt: Timestamp? = null,
    var discountEndAt: Timestamp? = null,
    var updatedBy: String = "",
    @ServerTimestamp
    var createdAt: Timestamp? = null,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
) {
    /** Effective price for a server supplied time. */
    fun effectivePricePaisa(nowMillis: Long): Long {
        val percent = effectiveDiscountPercentage(nowMillis)
        if (percent <= 0.0) return pricePaisa
        val discounted = pricePaisa - (pricePaisa * (percent / 100.0))
        return discounted.toLong().coerceIn(0L, pricePaisa)
    }

    /**
     * Discount is applied only when it is enabled, has a positive percentage, and the supplied time
     * falls inside the configured window. Unbounded sides of the window are treated as open ended.
     */
    fun effectiveDiscountPercentage(nowMillis: Long): Double {
        if (!enabled || !discountEnabled) return 0.0
        if (discountPercentage <= 0.0) return 0.0
        val start = discountStartAt?.toDate()?.time
        val end = discountEndAt?.toDate()?.time
        if (start != null && nowMillis < start) return 0.0
        if (end != null && nowMillis > end) return 0.0
        return discountPercentage.coerceIn(0.0, 100.0)
    }

    companion object {
        const val DEFAULT_PLAN_ID = "pro_monthly"
    }
}
