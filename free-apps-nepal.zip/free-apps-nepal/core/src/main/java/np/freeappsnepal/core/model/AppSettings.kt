package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp

/** Public safe application settings, editable only by an administrator. */
data class AppSettings(
    @DocumentId
    var settingsId: String = FirestoreCollections.SETTINGS_APP_DOC,
    var appName: String = "Free Apps Nepal",
    var supportEmail: String = "",
    var supportPhone: String = "",
    var aboutText: String = "",
    var privacyPolicyUrl: String = "",
    var termsUrl: String = "",
    var maintenanceMode: Boolean = false,
    var maintenanceMessage: String = "",
    var forceUpdate: Boolean = false,
    var minimumVersionCode: Long = 1L,
    var updateUrl: String = "",
    var proPlanEnabled: Boolean = true,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
)

/**
 * Aggregate counters maintained exclusively by the backend. The admin dashboard renders these
 * values as they are stored: nothing is estimated or extrapolated on the client.
 */
data class Counters(
    @DocumentId
    var counterId: String = FirestoreCollections.SETTINGS_COUNTERS_DOC,
    var totalApps: Long = 0L,
    var totalGames: Long = 0L,
    var totalUsers: Long = 0L,
    var pageViews: Long = 0L,
    var freeDownloadClicks: Long = 0L,
    var proDownloadClicks: Long = 0L,
    var activeProSubscribers: Long = 0L,
    var subscriptionPurchases: Long = 0L,
    var pendingPayments: Long = 0L,
    var revenuePaisa: Long = 0L,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
)

/** Daily rollup at statistics/{yyyy-MM-dd}. Only events the system can actually observe. */
data class DailyStatistics(
    @DocumentId
    var date: String = "",
    var pageViews: Long = 0L,
    var freeDownloadClicks: Long = 0L,
    var proDownloadClicks: Long = 0L,
    var newUsers: Long = 0L,
    var subscriptionPurchases: Long = 0L,
    var revenuePaisa: Long = 0L,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
)

/**
 * One observable download intent.
 *
 * A tap on a download button proves only that the external URL was opened. The file transfer is
 * handled by a third party and cannot be observed from here, so only the tap is recorded.
 */
data class DownloadEvent(
    @DocumentId
    var eventId: String = "",
    var itemId: String = "",
    var itemType: ItemType = ItemType.APP,
    var userId: String = "",
    var kind: String = KIND_FREE,
    @ServerTimestamp
    var createdAt: Timestamp? = null
) {
    companion object {
        const val KIND_FREE = "FREE"
        const val KIND_PRO = "PRO"
    }
}
