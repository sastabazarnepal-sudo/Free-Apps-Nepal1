package np.freeappsnepal.core.model

enum class ItemType {
    APP,
    GAME;

    val collection: String
        get() = if (this == APP) FirestoreCollections.APPS else FirestoreCollections.GAMES

    val label: String
        get() = if (this == APP) "App" else "Game"

    companion object {
        fun fromName(value: String?, fallback: ItemType = APP): ItemType =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: fallback
    }
}
