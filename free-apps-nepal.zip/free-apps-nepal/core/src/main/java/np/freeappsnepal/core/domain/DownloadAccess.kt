package np.freeappsnepal.core.domain

import np.freeappsnepal.core.model.AppItem

/**
 * What the download section of a detail screen must render.
 *
 * All Pro listings stay visible to every user. Only [proDownloadUnlocked] changes when the
 * subscription is active, and it never changes what is displayed, only whether the Pro action can
 * be performed.
 */
data class DownloadAccess(
    val showFreeButton: Boolean,
    val freeUrl: String,
    val showProButton: Boolean,
    val proDownloadUnlocked: Boolean,
    val proLockedReason: String?
) {
    val nothingConfigured: Boolean get() = !showFreeButton && !showProButton

    companion object {
        fun hidden(): DownloadAccess = DownloadAccess(
            showFreeButton = false,
            freeUrl = "",
            showProButton = false,
            proDownloadUnlocked = false,
            proLockedReason = null
        )

        fun forItem(item: AppItem, hasActiveSubscription: Boolean, everActive: Boolean = false) =
            DownloadAccessResolver.resolve(item, hasActiveSubscription, everActive)
    }
}

/** Which configured link a tap resolves to. Free stays free even for an active Pro subscriber. */
enum class DownloadTarget {
    FREE, PRO, LOCKED, NOT_CONFIGURED
}

object DownloadAccessResolver {

    const val PRO_LOCKED_NO_SUBSCRIPTION = "Subscribe to Pro to unlock direct download."
    const val PRO_LOCKED_EXPIRED = "Your Pro subscription has expired. Renew Pro to unlock direct download."

    fun resolve(
        item: AppItem,
        hasActiveSubscription: Boolean,
        subscriptionEverActive: Boolean = false
    ): DownloadAccess {
        val showFree = item.hasFree
        val showPro = item.hasPro

        val reason = when {
            hasActiveSubscription -> null
            subscriptionEverActive -> PRO_LOCKED_EXPIRED
            else -> PRO_LOCKED_NO_SUBSCRIPTION
        }

        return DownloadAccess(
            showFreeButton = showFree,
            freeUrl = item.freeDownloadUrl.trim(),
            showProButton = showPro,
            proDownloadUnlocked = showPro && hasActiveSubscription,
            proLockedReason = if (showPro && !hasActiveSubscription) reason else null
        )
    }

    /**
     * The action a tap resolves to. Kept here so the rule "free stays free for everyone" has exactly
     * one definition and can be asserted by a unit test.
     */
    fun target(item: AppItem, hasActiveSubscription: Boolean): DownloadTarget = when {
        item.hasFree -> DownloadTarget.FREE
        item.hasPro && hasActiveSubscription -> DownloadTarget.PRO
        item.hasPro -> DownloadTarget.LOCKED
        else -> DownloadTarget.NOT_CONFIGURED
    }
}

/** Convenience for callers that hold a [DownloadAccess] rather than a listing. */
val DownloadAccess.primaryTarget: DownloadTarget
    get() = when {
        showFreeButton -> DownloadTarget.FREE
        showProButton && proDownloadUnlocked -> DownloadTarget.PRO
        showProButton -> DownloadTarget.LOCKED
        else -> DownloadTarget.NOT_CONFIGURED
    }
