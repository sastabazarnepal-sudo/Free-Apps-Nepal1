package np.freeappsnepal.core.data.repo

import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.data.FirestoreRefs
import np.freeappsnepal.core.data.Mappers
import np.freeappsnepal.core.model.AppSettings
import np.freeappsnepal.core.model.Category
import np.freeappsnepal.core.model.Counters
import np.freeappsnepal.core.model.FavoriteItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.Promotion
import np.freeappsnepal.core.model.Review
import np.freeappsnepal.core.util.AppError
import np.freeappsnepal.core.util.AppResult
import np.freeappsnepal.core.util.AppResultKt
import np.freeappsnepal.core.util.Constants
import javax.inject.Inject
import javax.inject.Singleton

/** Admin controlled promotion banner. Hidden entirely when disabled or outside its date window. */
@Singleton
class PromotionRepository @Inject constructor(
    private val refs: FirestoreRefs
) {
    suspend fun activePromotion(serverNowMillis: Long): AppResult<Promotion?> = runCatching {
        val snapshot = refs.activePromotionsQuery().limit(10).get().await()
        snapshot.documents
            .mapNotNull { Mappers.promotion(it) }
            .firstOrNull { it.isVisibleAt(serverNowMillis) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun allPromotions(): AppResult<List<Promotion>> = runCatching {
        refs.promotions()
            .orderBy("priority", Query.Direction.DESCENDING)
            .limit(50)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.promotion(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })
}

/** Public settings and the backend maintained counters. */
@Singleton
class SettingsRepository @Inject constructor(
    private val refs: FirestoreRefs
) {
    suspend fun appSettings(): AppResult<AppSettings> = runCatching {
        Mappers.appSettings(refs.appSettings().get().await())
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun counters(): AppResult<Counters> = runCatching {
        Mappers.counters(refs.counters().get().await())
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })
}

/**
 * Favourites live under `favorites/{userId}/items/{itemId}`, so a user can only ever read and write
 * their own subtree. The stored snapshot avoids a second read when rendering the favourites list.
 */
@Singleton
class FavoritesRepository @Inject constructor(
    private val refs: FirestoreRefs
) {
    suspend fun isFavorite(userId: String, itemId: String): AppResult<Boolean> = runCatching {
        refs.favorites(userId).document(itemId).get().await().exists()
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun toggle(
        userId: String,
        itemId: String,
        itemType: ItemType,
        name: String,
        developerName: String,
        iconUrl: String,
        freeEnabled: Boolean,
        proEnabled: Boolean
    ): AppResult<Boolean> = runCatching {
        val reference = refs.favorites(userId).document(itemId)
        val exists = reference.get().await().exists()
        val batch = com.google.firebase.firestore.FirebaseFirestore.getInstance().batch()
        if (exists) {
            batch.delete(reference)
            batch.set(
                refs.user(userId),
                mapOf("favoriteCount" to FieldValue.increment(-1)),
                SetOptions.merge()
            )
        } else {
            batch.set(
                reference,
                mapOf(
                    "itemId" to itemId,
                    "type" to itemType.name,
                    "name" to name,
                    "developerName" to developerName,
                    "iconUrl" to iconUrl,
                    "freeEnabled" to freeEnabled,
                    "proEnabled" to proEnabled,
                    "addedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                refs.user(userId),
                mapOf("favoriteCount" to FieldValue.increment(1)),
                SetOptions.merge()
            )
        }
        batch.commit().await()
        !exists
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun favorites(userId: String): AppResult<List<FavoriteItem>> = runCatching {
        refs.favorites(userId)
            .orderBy("addedAt", Query.Direction.DESCENDING)
            .limit(200)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.favorite(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })
}

/**
 * Reviews.
 *
 * A user may create at most one review per listing and may modify or delete only their own review.
 * The rules file enforces the same constraints server side; this class simply never attempts an
 * operation the rules would reject, so the user gets a clean message instead of a permission error.
 */
@Singleton
class ReviewRepository @Inject constructor(
    private val refs: FirestoreRefs
) {
    suspend fun forItem(itemType: ItemType, itemId: String): AppResult<List<Review>> = runCatching {
        refs.itemReviews(itemType, itemId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.review(it) }
            .filter { !it.hidden }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun myReview(itemType: ItemType, itemId: String, userId: String): AppResult<Review?> =
        runCatching {
            refs.itemReviews(itemType, itemId)
                .whereEqualTo("userId", userId)
                .limit(1)
                .get()
                .await()
                .documents
                .firstOrNull()
                ?.let { Mappers.review(it) }
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun submit(
        itemType: ItemType,
        itemId: String,
        itemName: String,
        userId: String,
        userName: String,
        userPhotoUrl: String,
        rating: Int,
        text: String,
        existingReviewId: String?
    ): AppResult<String> = runCatching {
        val safeRating = rating.coerceIn(1, 5)
        val safeText = text.trim().take(Constants.MAX_REVIEW_LENGTH)
        val collection = refs.itemReviews(itemType, itemId)
        val reference = existingReviewId?.let { collection.document(it) } ?: collection.document()
        reference.set(
            mapOf(
                "reviewId" to reference.id,
                "itemId" to itemId,
                "itemType" to itemType.name,
                "itemName" to itemName,
                "userId" to userId,
                "userName" to userName,
                "userPhotoUrl" to userPhotoUrl,
                "rating" to safeRating,
                "text" to safeText,
                "hidden" to false,
                "updatedAt" to FieldValue.serverTimestamp(),
                "createdAt" to (if (existingReviewId == null) FieldValue.serverTimestamp() else null)
            ).filterValues { it != null },
            SetOptions.merge()
        ).await()
        reference.id
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun delete(itemType: ItemType, itemId: String, reviewId: String): AppResult<Unit> =
        runCatching {
            refs.itemReviews(itemType, itemId).document(reviewId).delete().await()
        }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    /**
     * Admin moderation. Reviews live in a per listing subcollection owned by their author, so the
     * rule that permits this is scoped to the single `hidden` field for an administrator.
     */
    suspend fun setHidden(
        itemType: ItemType,
        itemId: String,
        reviewId: String,
        hidden: Boolean
    ): AppResult<Unit> = runCatching {
        refs.itemReviews(itemType, itemId).document(reviewId)
            .set(
                mapOf("hidden" to hidden, "updatedAt" to FieldValue.serverTimestamp()),
                SetOptions.merge()
            )
            .await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    /**
     * Every review across every listing, for the moderation queue. This is a collection group query
     * so no copy of a review has to be maintained anywhere else.
     */
    suspend fun allReviews(limit: Long = 100L): AppResult<List<Review>> = runCatching {
        refs.reviewsCollectionGroup()
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.review(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    /** Admin only: manages the catalogue and with it the derived search fields. */
    suspend fun categories(): AppResult<List<Category>> = runCatching {
        refs.categories().get().await().documents.mapNotNull { Mappers.category(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })
}
