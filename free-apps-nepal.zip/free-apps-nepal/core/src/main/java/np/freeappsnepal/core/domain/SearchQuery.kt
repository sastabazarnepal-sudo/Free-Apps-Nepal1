package np.freeappsnepal.core.domain

import np.freeappsnepal.core.model.ItemType

/**
 * Search supports two modes:
 *  - name prefix search over the normalised name field, which Firestore can serve with an index
 *  - keyword array-contains search over [np.freeappsnepal.core.model.AppItem.searchKeywords]
 *
 * Results always include Pro listings, regardless of subscription state, because filtering by
 * subscription is a UI concern for the download button only.
 */
data class SearchRequest(
    val query: String,
    val filter: SearchFilter = SearchFilter.ALL,
    val categoryId: String? = null,
    val pageSize: Int = 20
) {
    val normalizedQuery: String get() = query.trim().lowercase()
    val isBlank: Boolean get() = normalizedQuery.isBlank()
}

enum class SearchFilter(val label: String) {
    ALL("All"),
    APPS("Apps"),
    GAMES("Games"),
    FREE("Free"),
    PRO("Pro");

    val itemType: ItemType?
        get() = when (this) {
            APPS -> ItemType.APP
            GAMES -> ItemType.GAME
            else -> null
        }
}

/**
 * Offering filter for the catalogue list screens.
 *
 * Every value shows Pro listings. The filter selects which version a listing offers, not which
 * users are allowed to see it.
 */
enum class ListFilter(val label: String) {
    ALL("All"),
    FREE("Free"),
    PRO("Pro")
}

object SearchNormalizer {
    /** Fields used for prefix matching. Kept in sync by the admin app and by the backend triggers. */
    fun keywords(name: String, developer: String, category: String): List<String> {
        val tokens = HashSet<String>()
        fun add(value: String) {
            val normalised = value.trim().lowercase()
            if (normalised.isEmpty()) return
            tokens.add(normalised)
            normalised.split(' ').filter { it.length >= 2 }.forEach { tokens.add(it) }
            if (normalised.length >= 2) {
                for (i in 2..minOf(normalised.length, 12)) {
                    tokens.add(normalised.substring(0, i))
                }
            }
        }
        add(name)
        add(developer)
        add(category)
        return tokens.take(120)
    }
}
