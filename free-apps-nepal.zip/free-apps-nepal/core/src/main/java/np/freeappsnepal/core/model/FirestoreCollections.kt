package np.freeappsnepal.core.model

object FirestoreCollections {
    const val USERS = "users"
    const val APPS = "apps"
    const val GAMES = "games"
    const val CATEGORIES = "categories"
    const val PLANS = "plans"
    const val SUBSCRIPTIONS = "subscriptions"
    const val USER_SUBSCRIPTIONS = "userSubscriptions"
    const val ORDERS = "orders"
    const val REVIEWS = "reviews"
    const val PROMOTIONS = "promotions"
    const val SETTINGS = "settings"
    const val STATISTICS = "statistics"
    const val FAVORITES = "favorites"
    const val FAVORITE_ITEMS = "items"
    const val DOWNLOAD_EVENTS = "downloadEvents"
    const val SECURE_LINKS = "secureLinks"
    const val ADMIN_TASKS = "adminTasks"

    const val SETTINGS_APP_DOC = "app"
    const val SETTINGS_COUNTERS_DOC = "counters"
    const val SETTINGS_SERVER_TIME_DOC = "serverTime"
    const val SETTINGS_PLATFORM_DOC = "platform"

    fun items(type: ItemType): String = type.collection
}
