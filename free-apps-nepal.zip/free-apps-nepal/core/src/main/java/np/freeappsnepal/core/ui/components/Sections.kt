package np.freeappsnepal.core.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import np.freeappsnepal.core.model.AppItem

/**
 * A titled horizontally scrolling section.
 *
 * Rows are used instead of grids for the discovery sections because they cost one layout pass and
 * keep scrolling smooth on low end devices. When [items] is empty the section is skipped entirely,
 * so an empty Home never shows a heading with nothing under it.
 */
@Composable
fun ItemRowSection(
    title: String,
    items: List<AppItem>,
    onOpenItem: (AppItem) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onSeeAll: (() -> Unit)? = null
) {
    if (items.isEmpty()) return

    Column(modifier = modifier.padding(top = 16.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.titleLarge)
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (onSeeAll != null) {
                TextButton(onClick = onSeeAll) { Text("See all") }
            }
        }

        Spacer(Modifier.height(8.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items = items, key = { it.itemId + it.type.name }) { item ->
                ItemCard(item = item, onClick = { onOpenItem(item) })
            }
        }
    }
}

/** Grid section used for the "latest" listings, with a single column list on narrow screens. */
@Composable
fun ItemListSection(
    title: String,
    items: List<AppItem>,
    onOpenItem: (AppItem) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onSeeAll: (() -> Unit)? = null
) {
    if (items.isEmpty()) return

    Column(modifier = modifier.padding(top = 16.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.titleLarge)
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (onSeeAll != null) {
                TextButton(onClick = onSeeAll) { Text("See all") }
            }
        }
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            items.forEach { item ->
                ItemListRow(item = item, onClick = { onOpenItem(item) })
            }
        }
    }
}

/** Skeleton row shown while a section is still loading. Avoids a layout jump when data arrives. */
@Composable
fun SectionSkeleton(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
    )
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(text = title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun HorizontalGap(width: Int = 10) {
    Spacer(Modifier.width(width.dp))
}
