package np.freeappsnepal.core.util

object Constants {
    const val DEFAULT_PAGE_SIZE = 12
    const val SEARCH_PAGE_SIZE = 20
    const val MAX_SCREENSHOTS = 8
    const val MIN_REVIEW_LENGTH = 1
    const val MAX_REVIEW_LENGTH = 1000
    const val CACHE_TTL_MILLIS = 5 * 60 * 1000L

    const val BUNDLE_ITEM_ID = "itemId"
    const val BUNDLE_ITEM_TYPE = "itemType"

    const val REQUEST_TIMEOUT_MILLIS = 20_000L
    const val PAYMENT_POST_TIMEOUT_MILLIS = 15_000L
}
