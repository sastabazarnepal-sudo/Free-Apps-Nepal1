package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

/**
 * A marketplace listing. Stored in [FirestoreCollections.APPS] or [FirestoreCollections.GAMES].
 *
 * [freeDownloadUrl] and [proDownloadUrl] are entered by an administrator and are opened exactly as
 * configured. The catalogue never rewrites, shortens, proxies or bypasses them.
 *
 * All Pro listings are readable by every signed in user, including users without a Pro
 * subscription. Only the Pro download action is gated, not the visibility of the listing.
 */
data class AppItem(
    @DocumentId
    var itemId: String = "",
    var type: ItemType = ItemType.APP,
    var name: String = "",
    var nameLower: String = "",
    var developerName: String = "",
    var developerNameLower: String = "",
    var iconUrl: String = "",
    var screenshots: List<String> = emptyList(),
    var description: String = "",
    var categoryId: String = "",
    var categoryName: String = "",
    var version: String = "",
    var fileSize: String = "",
    var minAndroidVersion: String = "",
    var whatsNew: String = "",
    @ServerTimestamp
    var lastUpdated: Timestamp? = null,
    var freeEnabled: Boolean = false,
    var freeDownloadUrl: String = "",
    var proEnabled: Boolean = false,
    var featured: Boolean = false,
    var popular: Boolean = false,
    @get:PropertyName("isNew")
    @set:PropertyName("isNew")
    var new: Boolean = false,
    var published: Boolean = false,
    var viewCount: Long = 0L,
    var freeDownloadClickCount: Long = 0L,
    var proDownloadClickCount: Long = 0L,
    var ratingSum: Long = 0L,
    var ratingCount: Long = 0L,
    var reviewCount: Long = 0L,
    var searchKeywords: List<String> = emptyList(),
    @ServerTimestamp
    var createdAt: Timestamp? = null,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
) {
    /** True when the admin configured a usable free version. */
    val hasFree: Boolean get() = freeEnabled && freeDownloadUrl.isNotBlank()

    /**
     * True when the admin enabled a Pro version.
     *
     * The Pro URL itself is deliberately absent from this public document. It is stored in
     * `secureLinks/{itemId}`, which only an administrator and the trusted backend may read, and is
     * released to a user only by the backend callable that has verified an active subscription.
     */
    val hasPro: Boolean get() = proEnabled

    val averageRating: Double
        get() = if (ratingCount <= 0) 0.0 else ratingSum.toDouble() / ratingCount.toDouble()

    val isNew: Boolean get() = new

    fun firstScreenshot(): String? = screenshots.firstOrNull { it.isNotBlank() }
}
