package np.freeappsnepal.core.data

import com.google.firebase.firestore.DocumentSnapshot
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.AppSettings
import np.freeappsnepal.core.model.Category
import np.freeappsnepal.core.model.Counters
import np.freeappsnepal.core.model.FavoriteItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.Order
import np.freeappsnepal.core.model.PaymentMethod
import np.freeappsnepal.core.model.Plan
import np.freeappsnepal.core.model.Promotion
import np.freeappsnepal.core.model.Review
import np.freeappsnepal.core.model.Subscription
import np.freeappsnepal.core.model.SubscriptionStatus
import np.freeappsnepal.core.model.UserProfile
import np.freeappsnepal.core.model.UserSubscription

/**
 * Explicit document mapping.
 *
 * Reading fields one by one instead of using automatic deserialisation keeps the app tolerant of
 * documents written by another version of the admin app: a missing or differently typed field
 * falls back to a safe default rather than throwing inside a snapshot listener.
 */
object Mappers {

    /**
     * Firestore may return a heterogeneous list. Filtering to strings keeps one malformed element
     * from crashing a whole snapshot listener.
     */
    private fun DocumentSnapshot.stringList(field: String): List<String> =
        (get(field) as? List<*>)?.filterIsInstance<String>().orEmpty()


    fun item(snapshot: DocumentSnapshot, type: ItemType): AppItem? {
        if (!snapshot.exists()) return null
        val name = snapshot.getString("name").orEmpty()
        return AppItem(
            itemId = snapshot.id,
            type = type,
            name = name,
            nameLower = snapshot.getString("nameLower") ?: name.lowercase(),
            developerName = snapshot.getString("developerName").orEmpty(),
            developerNameLower = snapshot.getString("developerName").orEmpty().lowercase(),
            iconUrl = snapshot.getString("iconUrl").orEmpty(),
            screenshots = snapshot.stringList("screenshots"),
            description = snapshot.getString("description").orEmpty(),
            categoryId = snapshot.getString("categoryId").orEmpty(),
            categoryName = snapshot.getString("categoryName").orEmpty(),
            version = snapshot.getString("version").orEmpty(),
            fileSize = snapshot.getString("fileSize").orEmpty(),
            minAndroidVersion = snapshot.getString("minAndroidVersion").orEmpty(),
            whatsNew = snapshot.getString("whatsNew").orEmpty(),
            lastUpdated = snapshot.getTimestamp("lastUpdated"),
            freeEnabled = snapshot.getBoolean("freeEnabled") ?: false,
            freeDownloadUrl = snapshot.getString("freeDownloadUrl").orEmpty(),
            // The Pro URL is intentionally absent from this document. It lives in secureLinks and
            // is released only by the backend after it has verified an active subscription.
            proEnabled = snapshot.getBoolean("proEnabled") ?: false,
            featured = snapshot.getBoolean("featured") ?: false,
            popular = snapshot.getBoolean("popular") ?: false,
            new = snapshot.getBoolean("isNew") ?: false,
            published = snapshot.getBoolean("published") ?: false,
            viewCount = snapshot.getLong("viewCount") ?: 0L,
            freeDownloadClickCount = snapshot.getLong("freeDownloadClickCount") ?: 0L,
            proDownloadClickCount = snapshot.getLong("proDownloadClickCount") ?: 0L,
            ratingSum = snapshot.getLong("ratingSum") ?: 0L,
            ratingCount = snapshot.getLong("ratingCount") ?: 0L,
            reviewCount = snapshot.getLong("reviewCount") ?: 0L,
            searchKeywords = snapshot.stringList("searchKeywords"),
            createdAt = snapshot.getTimestamp("createdAt"),
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun category(snapshot: DocumentSnapshot): Category? {
        if (!snapshot.exists()) return null
        val rawType = snapshot.getString("type")
        return Category(
            categoryId = snapshot.id,
            name = snapshot.getString("name").orEmpty(),
            nameNe = snapshot.getString("nameNe").orEmpty(),
            description = snapshot.getString("description").orEmpty(),
            iconUrl = snapshot.getString("iconUrl").orEmpty(),
            type = rawType?.takeIf { it.isNotBlank() }?.let { ItemType.fromName(it) },
            order = (snapshot.getLong("order") ?: 0L).toInt(),
            enabled = snapshot.getBoolean("enabled") ?: true,
            createdAt = snapshot.getTimestamp("createdAt"),
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun plan(snapshot: DocumentSnapshot): Plan? {
        if (!snapshot.exists()) return null
        return Plan(
            planId = snapshot.id,
            name = snapshot.getString("name") ?: "Free Apps Nepal Pro",
            description = snapshot.getString("description").orEmpty(),
            currency = snapshot.getString("currency") ?: "NPR",
            pricePaisa = snapshot.getLong("pricePaisa") ?: 9900L,
            durationDays = (snapshot.getLong("durationDays") ?: 30L).toInt(),
            enabled = snapshot.getBoolean("enabled") ?: true,
            benefits = snapshot.stringList("benefits"),
            discountEnabled = snapshot.getBoolean("discountEnabled") ?: false,
            discountPercentage = snapshot.getDouble("discountPercentage") ?: 0.0,
            discountStartAt = snapshot.getTimestamp("discountStartAt"),
            discountEndAt = snapshot.getTimestamp("discountEndAt"),
            updatedBy = snapshot.getString("updatedBy").orEmpty(),
            createdAt = snapshot.getTimestamp("createdAt"),
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun promotion(snapshot: DocumentSnapshot): Promotion? {
        if (!snapshot.exists()) return null
        return Promotion(
            promotionId = snapshot.id,
            title = snapshot.getString("title").orEmpty(),
            shortDescription = snapshot.getString("shortDescription").orEmpty(),
            imageUrl = snapshot.getString("imageUrl").orEmpty(),
            buttonText = snapshot.getString("buttonText").orEmpty(),
            buttonUrl = snapshot.getString("buttonUrl").orEmpty(),
            enabled = snapshot.getBoolean("enabled") ?: false,
            priority = (snapshot.getLong("priority") ?: 0L).toInt(),
            startAt = snapshot.getTimestamp("startAt"),
            endAt = snapshot.getTimestamp("endAt"),
            updatedBy = snapshot.getString("updatedBy").orEmpty(),
            createdAt = snapshot.getTimestamp("createdAt"),
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun subscription(snapshot: DocumentSnapshot): Subscription? {
        if (!snapshot.exists()) return null
        return Subscription(
            subscriptionId = snapshot.id,
            userId = snapshot.getString("userId").orEmpty(),
            planId = snapshot.getString("planId") ?: Plan.DEFAULT_PLAN_ID,
            planName = snapshot.getString("planName").orEmpty(),
            originalPricePaisa = snapshot.getLong("originalPricePaisa") ?: 0L,
            discountPercentage = snapshot.getDouble("discountPercentage") ?: 0.0,
            finalPricePaidPaisa = snapshot.getLong("finalPricePaidPaisa") ?: 0L,
            currency = snapshot.getString("currency") ?: "NPR",
            paymentMethod = PaymentMethod.fromName(snapshot.getString("paymentMethod")),
            transactionId = snapshot.getString("transactionId").orEmpty(),
            orderId = snapshot.getString("orderId").orEmpty(),
            status = SubscriptionStatus.fromName(snapshot.getString("status")),
            startAt = snapshot.getTimestamp("startAt"),
            expiresAt = snapshot.getTimestamp("expiresAt"),
            cancelledAt = snapshot.getTimestamp("cancelledAt"),
            refundedAt = snapshot.getTimestamp("refundedAt"),
            verifiedBy = snapshot.getString("verifiedBy").orEmpty(),
            createdAt = snapshot.getTimestamp("createdAt"),
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun userSubscription(snapshot: DocumentSnapshot): UserSubscription? {
        if (!snapshot.exists()) return null
        val rawMethod = snapshot.getString("paymentMethod")
        return UserSubscription(
            userId = snapshot.id,
            subscriptionId = snapshot.getString("subscriptionId").orEmpty(),
            planId = snapshot.getString("planId") ?: Plan.DEFAULT_PLAN_ID,
            status = SubscriptionStatus.fromName(snapshot.getString("status")),
            active = snapshot.getBoolean("active") ?: false,
            paymentMethod = rawMethod?.takeIf { it.isNotBlank() }?.let { PaymentMethod.fromName(it) },
            startAt = snapshot.getTimestamp("startAt"),
            expiresAt = snapshot.getTimestamp("expiresAt"),
            serverTimeMillis = snapshot.getLong("serverTimeMillis") ?: 0L,
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun order(snapshot: DocumentSnapshot): Order? {
        if (!snapshot.exists()) return null
        return Order(
            orderId = snapshot.id,
            userId = snapshot.getString("userId").orEmpty(),
            planId = snapshot.getString("planId") ?: Plan.DEFAULT_PLAN_ID,
            paymentMethod = PaymentMethod.fromName(snapshot.getString("paymentMethod")),
            originalPricePaisa = snapshot.getLong("originalPricePaisa") ?: 0L,
            discountPercentage = snapshot.getDouble("discountPercentage") ?: 0.0,
            amountPaisa = snapshot.getLong("amountPaisa") ?: 0L,
            currency = snapshot.getString("currency") ?: "NPR",
            status = SubscriptionStatus.fromName(snapshot.getString("status")),
            providerToken = snapshot.getString("providerToken").orEmpty(),
            providerTransactionId = snapshot.getString("providerTransactionId").orEmpty(),
            providerReferenceId = snapshot.getString("providerReferenceId").orEmpty(),
            failureReason = snapshot.getString("failureReason").orEmpty(),
            subscriptionId = snapshot.getString("subscriptionId").orEmpty(),
            createdAt = snapshot.getTimestamp("createdAt"),
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun userProfile(snapshot: DocumentSnapshot): UserProfile? {
        if (!snapshot.exists()) return null
        return UserProfile(
            userId = snapshot.id,
            displayName = snapshot.getString("displayName").orEmpty(),
            email = snapshot.getString("email").orEmpty(),
            phone = snapshot.getString("phone").orEmpty(),
            photoUrl = snapshot.getString("photoUrl").orEmpty(),
            blocked = snapshot.getBoolean("blocked") ?: false,
            fcmTokens = snapshot.stringList("fcmTokens"),
            favoriteCount = snapshot.getLong("favoriteCount") ?: 0L,
            lastLoginAt = snapshot.getTimestamp("lastLoginAt"),
            createdAt = snapshot.getTimestamp("createdAt"),
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun review(snapshot: DocumentSnapshot): Review? {
        if (!snapshot.exists()) return null
        return Review(
            reviewId = snapshot.id,
            itemId = snapshot.getString("itemId").orEmpty(),
            itemType = ItemType.fromName(snapshot.getString("itemType")),
            itemName = snapshot.getString("itemName").orEmpty(),
            userId = snapshot.getString("userId").orEmpty(),
            userName = snapshot.getString("userName").orEmpty(),
            userPhotoUrl = snapshot.getString("userPhotoUrl").orEmpty(),
            rating = (snapshot.getLong("rating") ?: 0L).toInt(),
            text = snapshot.getString("text").orEmpty(),
            hidden = snapshot.getBoolean("hidden") ?: false,
            reportCount = snapshot.getLong("reportCount") ?: 0L,
            createdAt = snapshot.getTimestamp("createdAt"),
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun favorite(snapshot: DocumentSnapshot): FavoriteItem? {
        if (!snapshot.exists()) return null
        return FavoriteItem(
            itemId = snapshot.id,
            type = ItemType.fromName(snapshot.getString("type")),
            name = snapshot.getString("name").orEmpty(),
            developerName = snapshot.getString("developerName").orEmpty(),
            iconUrl = snapshot.getString("iconUrl").orEmpty(),
            freeEnabled = snapshot.getBoolean("freeEnabled") ?: false,
            proEnabled = snapshot.getBoolean("proEnabled") ?: false,
            addedAt = snapshot.getTimestamp("addedAt")
        )
    }

    fun appSettings(snapshot: DocumentSnapshot): AppSettings {
        return AppSettings(
            settingsId = snapshot.id,
            appName = snapshot.getString("appName") ?: "Free Apps Nepal",
            supportEmail = snapshot.getString("supportEmail").orEmpty(),
            supportPhone = snapshot.getString("supportPhone").orEmpty(),
            aboutText = snapshot.getString("aboutText").orEmpty(),
            privacyPolicyUrl = snapshot.getString("privacyPolicyUrl").orEmpty(),
            termsUrl = snapshot.getString("termsUrl").orEmpty(),
            maintenanceMode = snapshot.getBoolean("maintenanceMode") ?: false,
            maintenanceMessage = snapshot.getString("maintenanceMessage").orEmpty(),
            forceUpdate = snapshot.getBoolean("forceUpdate") ?: false,
            minimumVersionCode = snapshot.getLong("minimumVersionCode") ?: 1L,
            updateUrl = snapshot.getString("updateUrl").orEmpty(),
            proPlanEnabled = snapshot.getBoolean("proPlanEnabled") ?: true,
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }

    fun counters(snapshot: DocumentSnapshot): Counters {
        return Counters(
            counterId = snapshot.id,
            totalApps = snapshot.getLong("totalApps") ?: 0L,
            totalGames = snapshot.getLong("totalGames") ?: 0L,
            totalUsers = snapshot.getLong("totalUsers") ?: 0L,
            pageViews = snapshot.getLong("pageViews") ?: 0L,
            freeDownloadClicks = snapshot.getLong("freeDownloadClicks") ?: 0L,
            proDownloadClicks = snapshot.getLong("proDownloadClicks") ?: 0L,
            activeProSubscribers = snapshot.getLong("activeProSubscribers") ?: 0L,
            subscriptionPurchases = snapshot.getLong("subscriptionPurchases") ?: 0L,
            pendingPayments = snapshot.getLong("pendingPayments") ?: 0L,
            revenuePaisa = snapshot.getLong("revenuePaisa") ?: 0L,
            updatedAt = snapshot.getTimestamp("updatedAt")
        )
    }
}
