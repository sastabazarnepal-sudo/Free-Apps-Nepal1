package np.freeappsnepal.core.data.repo

import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.data.FirestoreRefs
import np.freeappsnepal.core.data.Mappers
import np.freeappsnepal.core.domain.PriceQuote
import np.freeappsnepal.core.domain.PricingCalculator
import np.freeappsnepal.core.domain.ProStatus
import np.freeappsnepal.core.domain.SubscriptionEvaluator
import np.freeappsnepal.core.model.FirestoreCollections
import np.freeappsnepal.core.model.Order
import np.freeappsnepal.core.model.Plan
import np.freeappsnepal.core.model.Subscription
import np.freeappsnepal.core.model.SubscriptionStatus
import np.freeappsnepal.core.model.UserSubscription
import np.freeappsnepal.core.util.AppError
import np.freeappsnepal.core.util.AppResult
import np.freeappsnepal.core.util.AppResultKt
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Plan display and subscription history.
 *
 * Nothing in this class can activate Pro. Pro becomes active only after the backend verifies a
 * provider payment and writes the subscription document, which security rules permit only for the
 * trusted backend. The admin methods here are additionally guarded by security rules.
 */
@Singleton
class SubscriptionRepository @Inject constructor(
    private val refs: FirestoreRefs,
    private val firestore: FirebaseFirestore
) {

    suspend fun plan(planId: String = Plan.DEFAULT_PLAN_ID): AppResult<Plan> = runCatching {
        val snapshot = refs.plan(planId).get().await()
        Mappers.plan(snapshot) ?: throw AppError.NotFound.toException()
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun quote(
        planId: String = Plan.DEFAULT_PLAN_ID,
        serverNowMillis: Long
    ): AppResult<PriceQuote> = runCatching {
        when (val result = plan(planId)) {
            is AppResult.Success -> PricingCalculator.quote(result.data, serverNowMillis)
            is AppResult.Failure -> throw result.error.toException()
        }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun userSubscription(userId: String): AppResult<UserSubscription?> = runCatching {
        Mappers.userSubscription(refs.userSubscription(userId).get().await())
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun proStatus(userId: String, deviceNowMillis: Long): AppResult<ProStatus> = runCatching {
        when (val result = userSubscription(userId)) {
            is AppResult.Success -> SubscriptionEvaluator.evaluate(result.data, deviceNowMillis)
            is AppResult.Failure -> throw result.error.toException()
        }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun history(userId: String, limit: Long = 50L): AppResult<List<Subscription>> =
        runCatching {
            refs.subscriptions()
                .whereEqualTo("userId", userId)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(limit)
                .get()
                .await()
                .documents
                .mapNotNull { Mappers.subscription(it) }
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun paymentHistory(userId: String, limit: Long = 50L): AppResult<List<Order>> =
        runCatching {
            refs.orders()
                .whereEqualTo("userId", userId)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(limit)
                .get()
                .await()
                .documents
                .mapNotNull { Mappers.order(it) }
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun allSubscriptions(limit: Long = 100L): AppResult<List<Subscription>> = runCatching {
        refs.subscriptions()
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.subscription(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun pendingSubscriptions(limit: Long = 100L): AppResult<List<Subscription>> =
        runCatching {
            refs.subscriptions()
                .whereEqualTo("status", SubscriptionStatus.PENDING.name)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(limit)
                .get()
                .await()
                .documents
                .mapNotNull { Mappers.subscription(it) }
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    /** Admin only. Recomputes the plan document that drives the price shown to every user. */
    suspend fun upsertPlan(
        planId: String,
        values: Map<String, Any?>,
        adminUid: String
    ): AppResult<Unit> = runCatching {
        val payload = values.toMutableMap()
        payload["updatedBy"] = adminUid
        payload["updatedAt"] = FieldValue.serverTimestamp()
        refs.plan(planId).set(payload, SetOptions.merge()).await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun serverTimeMillis(): Long = runCatching {
        val snapshot = firestore.collection(FirestoreCollections.SETTINGS)
            .document(ServerClockRepository.SERVER_TIME_DOCUMENT)
            .get()
            .await()
        snapshot.getTimestamp("serverTime")?.toDate()?.time ?: System.currentTimeMillis()
    }.getOrDefault(System.currentTimeMillis())
}
