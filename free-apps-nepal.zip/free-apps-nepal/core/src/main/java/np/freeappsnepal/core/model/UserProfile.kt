package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp

data class UserProfile(
    @DocumentId
    var userId: String = "",
    var displayName: String = "",
    var email: String = "",
    var phone: String = "",
    var photoUrl: String = "",
    var blocked: Boolean = false,
    var fcmTokens: List<String> = emptyList(),
    var favoriteCount: Long = 0L,
    @ServerTimestamp
    var lastLoginAt: Timestamp? = null,
    @ServerTimestamp
    var createdAt: Timestamp? = null,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
)
