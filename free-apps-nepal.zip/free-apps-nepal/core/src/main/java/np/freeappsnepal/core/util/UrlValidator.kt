package np.freeappsnepal.core.util

import android.net.Uri

/** Validates admin configured download links before the app attempts to open them. */
object UrlValidator {
    private val allowedSchemes = setOf("http", "https")

    fun isOpenable(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val trimmed = url.trim()
        val uri = runCatching { Uri.parse(trimmed) }.getOrNull() ?: return false
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme !in allowedSchemes) return false
        return !uri.host.isNullOrBlank()
    }

    fun normalize(url: String?): String? =
        url?.trim()?.takeIf { isOpenable(it) }
}
