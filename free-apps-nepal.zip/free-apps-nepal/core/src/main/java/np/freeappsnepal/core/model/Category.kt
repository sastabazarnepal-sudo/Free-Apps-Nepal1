package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp

data class Category(
    @DocumentId
    var categoryId: String = "",
    var name: String = "",
    var nameNe: String = "",
    var description: String = "",
    var iconUrl: String = "",
    var type: ItemType? = null,
    var order: Int = 0,
    var enabled: Boolean = true,
    @ServerTimestamp
    var createdAt: Timestamp? = null,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
) {
    val displayName: String get() = name

    /** A category with no type applies to both Apps and Games. */
    fun appliesTo(type: ItemType): Boolean = this.type == null || this.type == type
}
