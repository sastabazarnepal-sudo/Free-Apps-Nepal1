package np.freeappsnepal.core.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Opens an administrator configured URL in whatever handler the device provides.
 *
 * The URL is passed through unchanged. Nothing is rewritten, shortened, proxied or replaced, so the
 * external service keeps control of its own page and, where the administrator configured a
 * monetised download page, of its own advertising.
 */
object LinkOpener {

    sealed interface Outcome {
        data object Opened : Outcome
        data object NoHandler : Outcome
        data object InvalidUrl : Outcome
    }

    fun open(context: Context, url: String?): Outcome {
        val normalized = UrlValidator.normalize(url) ?: return Outcome.InvalidUrl
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Outcome.Opened
        } catch (_: ActivityNotFoundException) {
            Outcome.NoHandler
        } catch (_: SecurityException) {
            Outcome.NoHandler
        }
    }
}
