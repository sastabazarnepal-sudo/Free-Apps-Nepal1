package np.freeappsnepal.core.data.repo

import android.content.Context
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.util.AppResultKt
import np.freeappsnepal.core.model.FirestoreCollections
import np.freeappsnepal.core.util.AppError
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Email/password and Google sign in.
 *
 * The admin role is never inferred here. It arrives as a Firebase custom claim set by a trusted
 * backend and is only ever read from the ID token.
 */
@Singleton
class AuthRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) {
    private val _currentUser = MutableStateFlow(auth.currentUser)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    init {
        auth.addAuthStateListener { _currentUser.value = it.currentUser }
    }

    val uid: String? get() = auth.currentUser?.uid

    fun isSignedIn(): Boolean = auth.currentUser != null

    suspend fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String
    ): AppResult<FirebaseUser> = runCatching {
        val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
        val user = result.user ?: throw IllegalStateException("Sign up did not return a user")
        user.updateProfile(
            UserProfileChangeRequest.Builder().setDisplayName(displayName.trim()).build()
        ).await()
        ensureUserDocument(user, displayName.trim(), email.trim())
        user
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun signInWithEmail(email: String, password: String): AppResult<FirebaseUser> =
        runCatching {
            val result = auth.signInWithEmailAndPassword(email.trim(), password).await()
            val user = result.user ?: throw IllegalStateException("Sign in did not return a user")
            touchLogin(user.uid)
            user
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun signInWithGoogle(idToken: String): AppResult<FirebaseUser> = runCatching {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        val result = auth.signInWithCredential(credential).await()
        val user = result.user ?: throw IllegalStateException("Google sign in returned no user")
        ensureUserDocument(user, user.displayName.orEmpty(), user.email.orEmpty())
        user
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun sendPasswordReset(email: String): AppResult<Unit> = runCatching {
        auth.sendPasswordResetEmail(email.trim()).await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    fun signOut() {
        auth.signOut()
        runCatching { googleClient().signOut() }
    }

    fun googleSignInClient(): GoogleSignInClient = googleClient()

    /**
     * The OAuth web client id is injected at build time (`-Pfan.googleWebClientId=...`). It is a
     * public identifier, not a secret, but keeping it out of source avoids pinning the repository to
     * one Firebase project. Google sign in reports a clear message when it has not been configured
     * rather than failing obscurely.
     */
    private fun requireWebClientId(): String =
        np.freeappsnepal.core.BuildConfig.GOOGLE_WEB_CLIENT_ID.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Google sign in is not configured for this build.")

    private fun googleClient(): GoogleSignInClient {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(requireWebClientId())
            .requestEmail()
            .build()
        return GoogleSignIn.getClient(context, options)
    }

    suspend fun updateDisplayName(displayName: String): AppResult<Unit> = runCatching {
        val user = auth.currentUser ?: throw IllegalStateException("Not signed in")
        user.updateProfile(
            UserProfileChangeRequest.Builder().setDisplayName(displayName.trim()).build()
        ).await()
        firestore.collection(FirestoreCollections.USERS).document(user.uid)
            .set(mapOf("displayName" to displayName.trim()), SetOptions.merge())
            .await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun registerFcmToken(token: String): AppResult<Unit> = runCatching {
        val user = auth.currentUser ?: return@runCatching
        firestore.collection(FirestoreCollections.USERS).document(user.uid)
            .set(mapOf("fcmTokens" to FieldValue.arrayUnion(token)), SetOptions.merge())
            .await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun unregisterFcmToken(token: String): AppResult<Unit> = runCatching {
        val user = auth.currentUser ?: return@runCatching
        firestore.collection(FirestoreCollections.USERS).document(user.uid)
            .set(mapOf("fcmTokens" to FieldValue.arrayRemove(token)), SetOptions.merge())
            .await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    /** True only when the signed in user holds the admin custom claim issued by the backend. */
    suspend fun hasAdminClaim(forceRefresh: Boolean = false): Boolean {
        val user = auth.currentUser ?: return false
        val result = runCatching { user.getIdToken(forceRefresh).await() }.getOrNull() ?: return false
        val claims = result.claims ?: return false
        return claims["admin"] == true || claims["role"] == "admin"
    }

    suspend fun refreshToken() {
        runCatching { auth.currentUser?.getIdToken(true)?.await() }
    }

    private suspend fun ensureUserDocument(user: FirebaseUser, displayName: String, email: String) {
        val reference = firestore.collection(FirestoreCollections.USERS).document(user.uid)
        val existing = runCatching { reference.get().await() }.getOrNull()
        val payload = mutableMapOf<String, Any>(
            "userId" to user.uid,
            "email" to (email.ifBlank { user.email.orEmpty() }),
            "lastLoginAt" to FieldValue.serverTimestamp()
        )
        val resolvedName = displayName.ifBlank { user.displayName.orEmpty() }
        if (resolvedName.isNotBlank()) payload["displayName"] = resolvedName
        if (existing == null || !existing.exists()) {
            payload["createdAt"] = FieldValue.serverTimestamp()
            payload["favoriteCount"] = 0L
            payload["blocked"] = false
        }
        reference.set(payload, SetOptions.merge()).await()
    }

    private suspend fun touchLogin(uid: String) {
        runCatching {
            firestore.collection(FirestoreCollections.USERS).document(uid)
                .set(mapOf("lastLoginAt" to FieldValue.serverTimestamp()), SetOptions.merge())
                .await()
        }
    }
}
