package np.freeappsnepal.core.domain

import np.freeappsnepal.core.model.Plan

/**
 * Display side pricing. The Android client renders whatever this returns but never transmits the
 * amount to be charged: the backend recomputes the price from the plan document before a payment
 * is created and verifies the provider amount against that recomputation.
 */
data class PriceQuote(
    val originalPaisa: Long,
    val discountPercentage: Double,
    val finalPaisa: Long,
    val discountActive: Boolean,
    val currency: String
) {
    val discountAmountPaisa: Long get() = originalPaisa - finalPaisa
    val hasDiscount: Boolean get() = discountActive && finalPaisa < originalPaisa
}

object PricingCalculator {

    fun quote(plan: Plan, serverNowMillis: Long): PriceQuote {
        val percent = plan.effectiveDiscountPercentage(serverNowMillis)
        return PriceQuote(
            originalPaisa = plan.pricePaisa,
            discountPercentage = percent,
            finalPaisa = plan.effectivePricePaisa(serverNowMillis),
            discountActive = percent > 0.0,
            currency = plan.currency
        )
    }
}
