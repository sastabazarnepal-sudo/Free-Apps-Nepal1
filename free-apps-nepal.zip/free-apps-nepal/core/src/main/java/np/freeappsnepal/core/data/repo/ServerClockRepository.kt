package np.freeappsnepal.core.data.repo

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.model.ServerClock
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The server timestamp endpoint is a Firestore document holding a Cloud Functions generated
 * `serverTime`. Subscription and discount decisions are made against this value, never against the
 * device clock alone.
 */
@Singleton
class ServerClockRepository @Inject constructor(
    private val firestore: FirebaseFirestore
) {
    @Volatile
    private var cached: ServerClock? = null

    suspend fun serverClock(forceRefresh: Boolean = false): ServerClock {
        val existing = cached
        val age = existing?.let { System.currentTimeMillis() - it.receivedAtMillis }
        if (!forceRefresh && existing != null && age != null && age < CLOCK_TTL_MILLIS) {
            return existing
        }
        val fetched = runCatching { fetch() }.getOrNull() ?: existing ?: fallback()
        cached = fetched
        return fetched
    }

    private suspend fun fetch(): ServerClock {
        val snapshot = firestore.collection(SERVER_TIME_COLLECTION)
            .document(SERVER_TIME_DOCUMENT)
            .get()
            .await()
        val millis = snapshot.getTimestamp("serverTime")?.toDate()?.time
            ?: snapshot.getLong("serverTimeMillis")
            ?: System.currentTimeMillis()
        return ServerClock(millis, System.currentTimeMillis())
    }

    private fun fallback(): ServerClock {
        val now = System.currentTimeMillis()
        return ServerClock(now, now)
    }

    companion object {
        const val SERVER_TIME_COLLECTION = "settings"
        const val SERVER_TIME_DOCUMENT = "serverTime"
        private const val CLOCK_TTL_MILLIS = 3 * 60 * 1000L
    }
}
