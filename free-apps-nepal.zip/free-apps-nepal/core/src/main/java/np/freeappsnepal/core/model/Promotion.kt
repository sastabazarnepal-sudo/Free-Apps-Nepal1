package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp

/**
 * An admin managed promotion banner. It is rendered only while [enabled] is true and the current
 * server time falls inside the optional [startAt] / [endAt] window.
 */
data class Promotion(
    @DocumentId
    var promotionId: String = "",
    var title: String = "",
    var shortDescription: String = "",
    var imageUrl: String = "",
    var buttonText: String = "",
    var buttonUrl: String = "",
    var enabled: Boolean = true,
    var priority: Int = 0,
    var startAt: Timestamp? = null,
    var endAt: Timestamp? = null,
    var updatedBy: String = "",
    @ServerTimestamp
    var createdAt: Timestamp? = null,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
) {
    fun isVisibleAt(nowMillis: Long): Boolean {
        if (!enabled) return false
        val start = startAt?.toDate()?.time
        val end = endAt?.toDate()?.time
        if (start != null && nowMillis < start) return false
        if (end != null && nowMillis > end) return false
        return true
    }
}
