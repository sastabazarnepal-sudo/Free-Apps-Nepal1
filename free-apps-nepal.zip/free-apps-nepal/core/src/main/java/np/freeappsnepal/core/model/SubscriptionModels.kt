package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp

enum class SubscriptionStatus {
    PENDING,
    ACTIVE,
    EXPIRED,
    FAILED,
    CANCELLED,
    REFUNDED;

    companion object {
        fun fromName(value: String?, fallback: SubscriptionStatus = PENDING): SubscriptionStatus =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: fallback
    }
}

enum class PaymentMethod {
    KHALTI,
    ESEWA;

    val label: String get() = if (this == KHALTI) "Khalti" else "eSewa"

    companion object {
        fun fromName(value: String?, fallback: PaymentMethod = KHALTI): PaymentMethod =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: fallback
    }
}

/** Immutable record of one monthly Pro purchase. Written and verified by the backend only. */
data class Subscription(
    @DocumentId
    var subscriptionId: String = "",
    var userId: String = "",
    var planId: String = Plan.DEFAULT_PLAN_ID,
    var planName: String = "",
    var originalPricePaisa: Long = 0L,
    var discountPercentage: Double = 0.0,
    var finalPricePaidPaisa: Long = 0L,
    var currency: String = "NPR",
    var paymentMethod: PaymentMethod = PaymentMethod.KHALTI,
    var transactionId: String = "",
    var orderId: String = "",
    var status: SubscriptionStatus = SubscriptionStatus.PENDING,
    var startAt: Timestamp? = null,
    var expiresAt: Timestamp? = null,
    var cancelledAt: Timestamp? = null,
    var refundedAt: Timestamp? = null,
    var verifiedBy: String = "",
    @ServerTimestamp
    var createdAt: Timestamp? = null,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
) {
    fun isActiveAt(nowMillis: Long): Boolean {
        if (status != SubscriptionStatus.ACTIVE) return false
        val expiry = expiresAt?.toDate()?.time ?: return false
        return expiry > nowMillis
    }
}

/**
 * Denormalised per user Pro snapshot, written by the backend and read by both apps.
 *
 * [serverTimeMillis] is stored together with the document so the client can apply the offset
 * between the server clock and the device clock. Comparing only against the device clock would let
 * a user extend Pro access by moving the phone date forward or backward.
 */
data class UserSubscription(
    @DocumentId
    var userId: String = "",
    var subscriptionId: String = "",
    var planId: String = Plan.DEFAULT_PLAN_ID,
    var status: SubscriptionStatus = SubscriptionStatus.EXPIRED,
    var active: Boolean = false,
    var paymentMethod: PaymentMethod? = null,
    var startAt: Timestamp? = null,
    var expiresAt: Timestamp? = null,
    var serverTimeMillis: Long = 0L,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
) {
    fun isActiveWithClockSkew(deviceNowMillis: Long): Boolean {
        if (!active || status != SubscriptionStatus.ACTIVE) return false
        val expiry = expiresAt?.toDate()?.time ?: return false
        val writtenAt = updatedAt?.toDate()?.time ?: serverTimeMillis
        val elapsedSinceWrite = (deviceNowMillis - writtenAt).coerceAtLeast(0L)
        val trustedNow = serverTimeMillis + elapsedSinceWrite
        return expiry > trustedNow
    }

    val remainingMillis: Long
        get() = (expiresAt?.toDate()?.time ?: 0L) - serverTimeMillis
}

/** One payment attempt. Created by the backend before contacting a provider. */
data class Order(
    @DocumentId
    var orderId: String = "",
    var userId: String = "",
    var planId: String = Plan.DEFAULT_PLAN_ID,
    var paymentMethod: PaymentMethod = PaymentMethod.KHALTI,
    var originalPricePaisa: Long = 0L,
    var discountPercentage: Double = 0.0,
    var amountPaisa: Long = 0L,
    var currency: String = "NPR",
    var status: SubscriptionStatus = SubscriptionStatus.PENDING,
    var providerToken: String = "",
    var providerTransactionId: String = "",
    var providerReferenceId: String = "",
    var failureReason: String = "",
    var subscriptionId: String = "",
    @ServerTimestamp
    var createdAt: Timestamp? = null,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
)
