package np.freeappsnepal.core.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object Formatters {
    private val currencyFormats = HashMap<String, NumberFormat>()

    /** Formats paisa as a currency string, e.g. 9900 -> "NPR 99". */
    fun moneyFromPaisa(paisa: Long, currency: String = "NPR"): String {
        val major = paisa / 100.0
        return "$currency ${formatAmount(major)}"
    }

    fun amountFromPaisa(paisa: Long): String = formatAmount(paisa / 100.0)

    private fun formatAmount(value: Double): String {
        return if (abs(value - value.toLong()) < 0.005) {
            value.toLong().toString()
        } else {
            String.format(Locale.US, "%.2f", value)
        }
    }

    fun discountPercent(percent: Double): String =
        "${String.format(Locale.US, "%.2f", percent).trimEnd('0').trimEnd('.')}% OFF"

    /** A short remaining time, e.g. "12 days" or "5 hours". Used for the Pro countdown. */
    fun duration(millis: Long): String {
        if (millis <= 0L) return "Expired"
        val minutes = millis / 60_000L
        val hours = minutes / 60L
        val days = hours / 24L
        return when {
            days >= 1 -> "$days day" + if (days == 1L) "" else "s"
            hours >= 1 -> "$hours hour" + if (hours == 1L) "" else "s"
            else -> "$minutes minute" + if (minutes == 1L) "" else "s"
        }
    }

    fun date(millis: Long?): String {
        if (millis == null || millis <= 0L) return "-"
        return SimpleDateFormat("d MMM yyyy", Locale.US).format(Date(millis))
    }

    fun dateTime(millis: Long?): String {
        if (millis == null || millis <= 0L) return "-"
        return SimpleDateFormat("d MMM yyyy, h:mm a", Locale.US).format(Date(millis))
    }

    fun count(value: Long): String = when {
        value >= 1_000_000 -> String.format(Locale.US, "%.1fM", value / 1_000_000.0)
        value >= 1_000 -> String.format(Locale.US, "%.1fK", value / 1_000.0)
        else -> value.toString()
    }

    /** Human readable remaining duration, used on the subscription screen. */
    fun remaining(millis: Long): String {
        if (millis <= 0L) return "Expired"
        val days = millis / 86_400_000L
        val hours = (millis % 86_400_000L) / 3_600_000L
        return when {
            days > 0 -> "$days day${if (days == 1L) "" else "s"} $hours hr remaining"
            hours > 0 -> "$hours hr remaining"
            else -> "Less than an hour remaining"
        }
    }
}
