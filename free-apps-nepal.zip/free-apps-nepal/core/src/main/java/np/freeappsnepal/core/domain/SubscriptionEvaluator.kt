package np.freeappsnepal.core.domain

import np.freeappsnepal.core.model.SubscriptionStatus
import np.freeappsnepal.core.model.UserSubscription

enum class ProState {
    /** No subscription record at all, or the user never completed a purchase. */
    INACTIVE,
    PENDING,
    ACTIVE,
    EXPIRED,
    CANCELLED,
    REFUNDED,
    FAILED
}

data class ProStatus(
    val state: ProState,
    val isActive: Boolean,
    val expiryMillis: Long?,
    val startMillis: Long?,
    val remainingMillis: Long,
    val planId: String?
) {
    companion object {
        val INACTIVE = ProStatus(ProState.INACTIVE, false, null, null, 0L, null)
    }
}

object SubscriptionEvaluator {

    fun evaluate(subscription: UserSubscription?, deviceNowMillis: Long): ProStatus {
        if (subscription == null) return ProStatus.INACTIVE

        val expiry = subscription.expiresAt?.toDate()?.time
        val start = subscription.startAt?.toDate()?.time

        val state = when (subscription.status) {
            SubscriptionStatus.ACTIVE ->
                if (expiry != null && expiry > deviceNowMillis) ProState.ACTIVE else ProState.EXPIRED
            SubscriptionStatus.PENDING -> ProState.PENDING
            SubscriptionStatus.EXPIRED -> ProState.EXPIRED
            SubscriptionStatus.CANCELLED -> ProState.CANCELLED
            SubscriptionStatus.REFUNDED -> ProState.REFUNDED
            SubscriptionStatus.FAILED -> ProState.FAILED
        }

        return ProStatus(
            state = state,
            isActive = state == ProState.ACTIVE && subscription.isActiveWithClockSkew(deviceNowMillis),
            expiryMillis = expiry,
            startMillis = start,
            remainingMillis = ((expiry ?: 0L) - deviceNowMillis).coerceAtLeast(0L),
            planId = subscription.planId
        )
    }

    /** True when a subscription existed before, so the UI can say "renew" instead of "get Pro". */
    fun everActive(status: ProStatus): Boolean = when (status.state) {
        ProState.EXPIRED, ProState.CANCELLED, ProState.REFUNDED -> true
        ProState.ACTIVE -> true
        else -> false
    }
}
