package np.freeappsnepal.core.util

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.functions.FirebaseFunctionsException
import kotlinx.coroutines.TimeoutCancellationException

/**
 * Every failure surfaced to the UI is one of these. Each carries a message that is safe to show to
 * a user: no stack traces, no provider payloads, no secrets.
 */
sealed class AppError(val userMessage: String, open val technicalMessage: String? = null) {
    data object NoInternet : AppError(
        userMessage = "No internet connection. Please check your network and try again."
    )

    data object Timeout : AppError(
        userMessage = "The request took too long. Please try again."
    )

    data object PermissionDenied : AppError(
        userMessage = "You do not have permission to do that."
    )

    data object Unauthenticated : AppError(
        userMessage = "Please sign in to continue."
    )

    data object NotFound : AppError(
        userMessage = "This item is no longer available."
    )

    data object EmptySearch : AppError(
        userMessage = "No results found. Try a different keyword."
    )

    data object InvalidUrl : AppError(
        userMessage = "The download link configured for this item is invalid."
    )

    data object ProRequired : AppError(
        userMessage = "Subscribe to Pro to unlock direct download."
    )

    data object ProExpired : AppError(
        userMessage = "Your Pro subscription has expired. Renew it to unlock direct downloads."
    )

    data object PaymentPending : AppError(
        userMessage = "Your payment is still pending verification. We will activate Pro once it is confirmed."
    )

    data object PaymentFailed : AppError(
        userMessage = "The payment could not be completed. You have not been charged for a Pro subscription."
    )

    data object PaymentVerificationFailed : AppError(
        userMessage = "We could not verify this payment. If money was deducted, contact support with your transaction ID."
    )

    data object Maintenance : AppError(
        userMessage = "The service is temporarily under maintenance. Please try again later."
    )

    data object ServerError : AppError(
        userMessage = "Something went wrong on our side. Please try again."
    )

    data class Unknown(override val technicalMessage: String?) : AppError(
        userMessage = "Something went wrong. Please try again.",
        technicalMessage = technicalMessage
    )

    fun toException(): Exception = AppException(this)

    companion object {
        fun from(throwable: Throwable): AppError = when (throwable) {
            is AppException -> throwable.error
            is FirebaseNetworkException -> NoInternet
            is TimeoutCancellationException -> Timeout
            is FirebaseFunctionsException -> when (throwable.code) {
                FirebaseFunctionsException.Code.UNAUTHENTICATED -> Unauthenticated
                FirebaseFunctionsException.Code.PERMISSION_DENIED -> PermissionDenied
                FirebaseFunctionsException.Code.NOT_FOUND -> NotFound
                FirebaseFunctionsException.Code.FAILED_PRECONDITION -> ProExpired
                FirebaseFunctionsException.Code.INVALID_ARGUMENT -> PaymentVerificationFailed
                FirebaseFunctionsException.Code.DEADLINE_EXCEEDED -> Timeout
                FirebaseFunctionsException.Code.UNAVAILABLE -> ServerError
                else -> Unknown(throwable.message)
            }
            is FirebaseFirestoreException -> when (throwable.code) {
                FirebaseFirestoreException.Code.PERMISSION_DENIED -> PermissionDenied
                FirebaseFirestoreException.Code.UNAUTHENTICATED -> Unauthenticated
                FirebaseFirestoreException.Code.NOT_FOUND -> NotFound
                FirebaseFirestoreException.Code.UNAVAILABLE -> NoInternet
                else -> Unknown(throwable.message)
            }
            else -> Unknown(throwable.message)
        }
    }
}

class AppException(val error: AppError) : Exception(error.userMessage, null)
