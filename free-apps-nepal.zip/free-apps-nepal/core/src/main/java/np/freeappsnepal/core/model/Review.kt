package np.freeappsnepal.core.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp

data class Review(
    @DocumentId
    var reviewId: String = "",
    var itemId: String = "",
    var itemType: ItemType = ItemType.APP,
    var itemName: String = "",
    var userId: String = "",
    var userName: String = "",
    var userPhotoUrl: String = "",
    var rating: Int = 0,
    var text: String = "",
    var hidden: Boolean = false,
    var reportCount: Long = 0L,
    @ServerTimestamp
    var createdAt: Timestamp? = null,
    @ServerTimestamp
    var updatedAt: Timestamp? = null
)
