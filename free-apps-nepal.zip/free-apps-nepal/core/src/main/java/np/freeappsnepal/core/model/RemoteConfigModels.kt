package np.freeappsnepal.core.model

import com.google.firebase.Timestamp

/** Server time plus the moment it was received, used to detect a manipulated device clock. */
data class ServerClock(
    val serverTimeMillis: Long = 0L,
    val receivedAtMillis: Long = 0L
) {
    /** Server time projected forward onto the device clock. */
    fun now(deviceNowMillis: Long): Long {
        val elapsed = (deviceNowMillis - receivedAtMillis).coerceAtLeast(0L)
        return serverTimeMillis + elapsed
    }

    companion object {
        fun fromTimestamp(timestamp: Timestamp?): ServerClock {
            val millis = timestamp?.toDate()?.time ?: System.currentTimeMillis()
            return ServerClock(millis, System.currentTimeMillis())
        }
    }
}

/** Result of a Pro link request from the backend callable. */
data class ProLinkResult(
    val itemId: String = "",
    val itemType: ItemType = ItemType.APP,
    val url: String = "",
    val expiresAtMillis: Long = 0L,
    val token: String = ""
)
