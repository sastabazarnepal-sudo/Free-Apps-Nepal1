package np.freeappsnepal.core.data.repo

import androidx.annotation.VisibleForTesting
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.PaymentMethod
import np.freeappsnepal.core.model.Plan
import np.freeappsnepal.core.util.AppError
import np.freeappsnepal.core.util.AppResult
import np.freeappsnepal.core.util.AppResultKt
import javax.inject.Inject
import javax.inject.Singleton

/** What the backend returned when a payment was started. */
data class PaymentInitiation(
    val orderId: String,
    val paymentMethod: PaymentMethod,
    val amountPaisa: Long,
    val paymentUrl: String,
    val pidx: String?,
    /** eSewa v2 is a signed form post, so the fields are returned instead of a ready made URL. */
    val formFields: Map<String, String> = emptyMap()
)

/** Outcome of a verification attempt. A pending result is not a failure. */
data class VerificationOutcome(
    val status: String,
    val verified: Boolean,
    val subscriptionId: String?,
    val expiresAtMillis: Long?
) {
    val isPending: Boolean get() = status == "PENDING"
    val isActive: Boolean get() = verified && status == "ACTIVE"
}

/**
 * The only class in either application that talks to the payment backend.
 *
 * It sends no price. The order is priced by the backend from the plan document, and the outcome of
 * a payment is decided by the backend after it has queried the provider. There is no code path here
 * that can mark a payment as successful on its own, which is deliberate: a client that can declare
 * success is a client that can forge a subscription.
 */
@Singleton
class PaymentRepository @Inject constructor(
    private val functions: FirebaseFunctions
) {

    suspend fun createProOrder(
        planId: String = Plan.DEFAULT_PLAN_ID,
        method: PaymentMethod,
        returnUrl: String? = null,
        websiteUrl: String? = null
    ): AppResult<PaymentInitiation> = runCatching {
        val payload = mutableMapOf<String, Any>(
            "planId" to planId,
            "paymentMethod" to method.name
        )
        if (!returnUrl.isNullOrBlank()) payload["returnUrl"] = returnUrl
        if (!websiteUrl.isNullOrBlank()) payload["websiteUrl"] = websiteUrl

        val result = functions.getHttpsCallable("createProOrder").call(payload).await()
        val data = result.data as? Map<*, *> ?: throw IllegalStateException("Empty order response")
        @Suppress("UNCHECKED_CAST")
        val rawFields = data["formFields"] as? Map<*, *>
        PaymentInitiation(
            orderId = data["orderId"]?.toString().orEmpty(),
            paymentMethod = method,
            amountPaisa = (data["amountPaisa"] as? Number)?.toLong() ?: 0L,
            paymentUrl = data["paymentUrl"]?.toString().orEmpty(),
            pidx = data["pidx"]?.toString(),
            formFields = rawFields?.entries
                ?.associate { it.key.toString() to it.value.toString() }
                .orEmpty()
        )
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun verifyKhalti(orderId: String): AppResult<VerificationOutcome> = runCatching {
        val result = functions.getHttpsCallable("verifyKhaltiPayment")
            .call(mapOf("orderId" to orderId))
            .await()
        parseOutcome(result.data)
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun verifyEsewa(orderId: String, encodedResponse: String?): AppResult<VerificationOutcome> =
        runCatching {
            val payload = mutableMapOf<String, Any>("orderId" to orderId)
            if (!encodedResponse.isNullOrBlank()) payload["encodedResponse"] = encodedResponse
            val result = functions.getHttpsCallable("verifyEsewaPayment").call(payload).await()
            parseOutcome(result.data)
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun getProDownloadLink(itemType: ItemType, itemId: String): AppResult<String> =
        runCatching {
            val result = functions.getHttpsCallable("getProDownloadLink")
                .call(mapOf("itemId" to itemId, "itemType" to itemType.name))
                .await()
            val data = result.data as? Map<*, *> ?: throw IllegalStateException("Empty link response")
            data["url"]?.toString()?.takeIf { it.isNotBlank() }
                ?: throw AppError.NotFound.toException()
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    /**
     * Asks the backend to record the free download click and to return the configured free URL.
     * The returned string is opened verbatim by the caller.
     */
    suspend fun trackFreeDownload(itemType: ItemType, itemId: String): AppResult<String> =
        runCatching {
            val result = functions.getHttpsCallable("trackFreeDownload")
                .call(mapOf("itemId" to itemId, "itemType" to itemType.name))
                .await()
            val data = result.data as? Map<*, *> ?: throw IllegalStateException("Empty link response")
            data["url"]?.toString()?.takeIf { it.isNotBlank() }
                ?: throw AppError.InvalidUrl.toException()
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun serverTime(): AppResult<Long> = runCatching {
        val result = functions.getHttpsCallable("getServerTime").call(emptyMap<String, Any>()).await()
        val data = result.data as? Map<*, *> ?: return@runCatching System.currentTimeMillis()
        (data["serverTimeMillis"] as? Number)?.toLong() ?: System.currentTimeMillis()
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    @VisibleForTesting
    internal fun parseOutcome(raw: Any?): VerificationOutcome {
        val data = raw as? Map<*, *> ?: return VerificationOutcome("FAILED", false, null, null)
        return VerificationOutcome(
            status = data["status"]?.toString().orEmpty().ifBlank { "FAILED" },
            verified = data["verified"] == true,
            subscriptionId = data["subscriptionId"]?.toString(),
            expiresAtMillis = (data["expiresAt"] as? Number)?.toLong()
        )
    }
}
