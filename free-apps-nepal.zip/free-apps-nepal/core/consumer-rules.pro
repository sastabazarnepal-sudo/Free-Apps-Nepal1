# Keep model classes that are (de)serialized from Firestore documents via reflection.
-keepclassmembers class np.freeappsnepal.core.model.** {
    <init>();
    <fields>;
}
-keepnames class np.freeappsnepal.core.model.**
-keepattributes Signature,*Annotation*,InnerClasses,EnclosingMethod
