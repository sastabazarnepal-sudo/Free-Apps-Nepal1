# Free Apps Nepal release shrinking rules.
#
# Firestore deserialises into data classes reflectively, so field and class names used by the
# Firebase SDK must survive shrinking. Application entry points are kept so the launcher and
# Hilt generated components remain reachable.
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod

# Firestore models bound by reflection.
-keepclassmembers class np.freeappsnepal.** {
    <fields>;
    <init>(...);
}

-keep class np.freeappsnepal.**$$serializer { *; }
-keep class np.freeappsnepal.**$Companion { *; }

# Kotlin serialization.
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Firebase and Google Play services rely on reflection for callbacks.
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**

# Hilt and Dagger generated code.
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper

# Coroutines.
-dontwarn kotlinx.coroutines.**

# Keep line numbers for readable Crashlytics reports, hide the source file name.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
