package np.freeappsnepal.admin.ui.screens.categories

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import np.freeappsnepal.admin.data.AdminDataRepository
import np.freeappsnepal.admin.data.CategoryDraft
import np.freeappsnepal.core.model.Category
import javax.inject.Inject

@HiltViewModel
class CategoriesViewModel @Inject constructor(
    private val dataRepository: AdminDataRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val categories: List<Category> = emptyList(),
        val draft: CategoryDraft? = null,
        val saving: Boolean = false,
        val message: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val result = dataRepository.categories()
            _state.update {
                it.copy(loading = false, categories = result.getOrNull().orEmpty(), message = result.errorOrNull()?.userMessage)
            }
        }
    }

    fun beginNew() = _state.update { it.copy(draft = CategoryDraft()) }

    fun beginEdit(category: Category) = _state.update { it.copy(draft = CategoryDraft.from(category)) }

    fun cancelEdit() = _state.update { it.copy(draft = null) }

    fun updateDraft(transform: (CategoryDraft) -> CategoryDraft) = _state.update { current ->
        current.draft?.let { current.copy(draft = transform(it)) } ?: current
    }

    fun save() {
        val draft = _state.value.draft ?: return
        if (draft.name.isBlank()) {
            _state.update { it.copy(message = "A category name is required.") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(saving = true, message = null) }
            val result = dataRepository.saveCategory(draft)
            _state.update {
                it.copy(
                    saving = false,
                    draft = if (result.getOrNull() != null) null else it.draft,
                    message = result.errorOrNull()?.userMessage ?: "Category saved."
                )
            }
            load()
        }
    }

    fun delete(category: Category) {
        viewModelScope.launch {
            val result = dataRepository.deleteCategory(category.categoryId)
            _state.update { it.copy(message = result.errorOrNull()?.userMessage ?: "Category deleted.") }
            load()
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }
}
