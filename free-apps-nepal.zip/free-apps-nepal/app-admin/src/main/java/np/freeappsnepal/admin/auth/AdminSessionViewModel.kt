package np.freeappsnepal.admin.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.functions.FirebaseFunctions
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.BuildConfig
import np.freeappsnepal.core.data.repo.AuthRepository
import np.freeappsnepal.core.util.AppError
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject

/**
 * Whether this account may operate the admin application.
 *
 * This is a convenience gate for the UI only. It is never the security boundary. Every write the
 * admin application performs goes through a callable that checks the admin custom claim on the
 * server, and the Firestore rules refuse catalogue, plan and subscription writes from any client,
 * including this one. An unprivileged account that somehow reaches these screens still cannot
 * change anything.
 */
@HiltViewModel
class AdminSessionViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    sealed interface AdminState {
        data object Loading : AdminState
        data object SignedOut : AdminState
        data class NotAdmin(val email: String) : AdminState
        data class Ready(val uid: String, val email: String) : AdminState
    }

    private val _state = MutableStateFlow<AdminState>(AdminState.Loading)
    val state: StateFlow<AdminState> = _state.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        evaluate(refresh = false)
    }

    fun evaluate(refresh: Boolean) {
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            val user = authRepository.currentUser.value
            if (user == null) {
                _state.value = AdminState.SignedOut
                _busy.value = false
                return@launch
            }
            if (refresh) {
                authRepository.refreshToken()
            }
            val isAdmin = authRepository.hasAdminClaim(forceRefresh = refresh)
            _state.value = if (isAdmin) {
                AdminState.Ready(user.uid, user.email.orEmpty())
            } else {
                AdminState.NotAdmin(user.email.orEmpty())
            }
            _busy.value = false
        }
    }

    fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _error.value = "Enter your email and password."
            return
        }
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            when (val result = authRepository.signInWithEmail(email, password)) {
                is AppResult.Success -> {
                    _busy.value = false
                    evaluate(refresh = true)
                }
                is AppResult.Failure -> {
                    _busy.value = false
                    _error.value = result.error.userMessage
                }
            }
        }
    }

    /**
     * Claims the first administrator on a fresh project. The backend only honours this while no
     * administrator exists; afterwards it requires an existing administrator.
     */
    fun claimFirstAdmin() {
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            val result = runCatching {
                FirebaseFunctions.getInstance(BuildConfig.FUNCTIONS_REGION)
                    .getHttpsCallable("setAdminClaim")
                    .call(mapOf("grant" to true))
                    .await()
            }
            _busy.value = false
            result.fold(
                onSuccess = { evaluate(refresh = true) },
                onFailure = { _error.value = AppError.from(it).userMessage }
            )
        }
    }

    fun signOut() {
        authRepository.signOut()
        _state.value = AdminState.SignedOut
    }
}
