package np.freeappsnepal.admin.ui.screens.items

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.components.ItemBadge
import np.freeappsnepal.core.ui.components.RemoteIcon
import np.freeappsnepal.core.ui.components.BadgeKind
import np.freeappsnepal.core.ui.theme.FanColors

/**
 * The catalogue list for one item type. Publish, unpublish and delete all round trip through the
 * backend, so the row shows the state the server confirmed rather than an optimistic local edit.
 */
@Composable
fun ItemsScreen(
    itemType: ItemType,
    onOpenEditor: (ItemType, String?) -> Unit,
    viewModel: ItemsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(itemType) { viewModel.start(itemType) }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onOpenEditor(itemType, null) },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("New ${itemType.label.lowercase()}") }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = !state.publishedOnly,
                    onClick = { viewModel.load(publishedOnly = false) },
                    label = { Text("All") }
                )
                FilterChip(
                    selected = state.publishedOnly,
                    onClick = { viewModel.load(publishedOnly = true) },
                    label = { Text("Published") }
                )
            }

            when {
                state.loading -> LoadingState(label = "Loading ${itemType.label.lowercase()}s…")
                state.items.isEmpty() -> EmptyState(
                    title = "No ${itemType.label.lowercase()}s yet",
                    subtitle = "Use the button below to add the first one."
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(state.items, key = { it.itemId }) { item ->
                        ItemAdminRow(
                            item = item,
                            onEdit = { onOpenEditor(itemType, item.itemId) },
                            onTogglePublished = { viewModel.setPublished(item, !item.published) },
                            onDelete = { viewModel.delete(item) }
                        )
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }
}

@Composable
private fun ItemAdminRow(
    item: np.freeappsnepal.core.model.AppItem,
    onEdit: () -> Unit,
    onTogglePublished: () -> Unit,
    onDelete: () -> Unit
) {
    Card(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RemoteIcon(url = item.iconUrl, name = item.name, size = 46.dp)
            Spacer(Modifier.padding(horizontal = 6.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.developerName.ifBlank { item.categoryName },
                    style = MaterialTheme.typography.bodySmall,
                    color = FanColors.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    if (item.hasFree) ItemBadge(BadgeKind.FREE)
                    if (item.proEnabled) ItemBadge(BadgeKind.PRO)
                }
                Text(
                    text = if (item.published) "Published" else "Unpublished",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (item.published) FanColors.Success else FanColors.Warning,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            IconButton(onClick = onTogglePublished) {
                Icon(
                    Icons.Filled.Add,
                    contentDescription = if (item.published) "Unpublish" else "Publish",
                    tint = if (item.published) FanColors.Warning else FanColors.Success
                )
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "Delete",
                    tint = FanColors.Error
                )
            }
        }
    }
}
