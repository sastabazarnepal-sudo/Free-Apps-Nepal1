package np.freeappsnepal.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.AndroidEntryPoint
import np.freeappsnepal.admin.auth.AdminSessionViewModel
import np.freeappsnepal.admin.navigation.AdminNavGraph
import np.freeappsnepal.admin.ui.theme.AdminTheme

@AndroidEntryPoint
class AdminActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val sessionViewModel: AdminSessionViewModel = hiltViewModel()
            val state by sessionViewModel.state.collectAsStateWithLifecycle()
            val busy by sessionViewModel.busy.collectAsStateWithLifecycle()
            val error by sessionViewModel.error.collectAsStateWithLifecycle()

            AdminTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AdminNavGraph(
                        state = state,
                        busy = busy,
                        error = error,
                        sessionViewModel = sessionViewModel
                    )
                }
            }
        }
    }
}
