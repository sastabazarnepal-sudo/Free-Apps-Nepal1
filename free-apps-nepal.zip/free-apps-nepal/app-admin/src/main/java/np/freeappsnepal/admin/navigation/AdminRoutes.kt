package np.freeappsnepal.admin.navigation

import np.freeappsnepal.core.model.ItemType

object AdminRoutes {
    const val DASHBOARD = "dashboard"
    const val APPS = "apps"
    const val GAMES = "games"
    const val CATEGORIES = "categories"
    const val PROMOTIONS = "promotions"
    const val PRO = "pro"
    const val SUBSCRIBERS = "subscribers"
    const val REVIEWS = "reviews"
    const val EDITOR = "editor?itemId={itemId}&itemType={itemType}"

    const val ITEM_ID = "itemId"
    const val ITEM_TYPE = "itemType"

    fun editor(itemType: ItemType, itemId: String? = null): String =
        "editor?itemId=${itemId.orEmpty()}&itemType=${itemType.name}"
}
