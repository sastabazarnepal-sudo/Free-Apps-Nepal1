package np.freeappsnepal.admin.ui.screens.promotions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import np.freeappsnepal.admin.data.AdminDataRepository
import np.freeappsnepal.admin.data.PromotionDraft
import np.freeappsnepal.core.model.Promotion
import javax.inject.Inject

@HiltViewModel
class PromotionsViewModel @Inject constructor(
    private val dataRepository: AdminDataRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val promotions: List<Promotion> = emptyList(),
        val draft: PromotionDraft? = null,
        val saving: Boolean = false,
        val message: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val result = dataRepository.promotions()
            _state.update {
                it.copy(
                    loading = false,
                    promotions = result.getOrNull().orEmpty(),
                    message = result.errorOrNull()?.userMessage
                )
            }
        }
    }

    fun beginNew() = _state.update { it.copy(draft = PromotionDraft()) }

    fun beginEdit(promotion: Promotion) = _state.update {
        it.copy(draft = PromotionDraft.from(promotion))
    }

    fun cancelEdit() = _state.update { it.copy(draft = null) }

    fun updateDraft(transform: (PromotionDraft) -> PromotionDraft) = _state.update { current ->
        current.draft?.let { current.copy(draft = transform(it)) } ?: current
    }

    fun save() {
        val draft = _state.value.draft ?: return
        if (draft.enabled && draft.title.isBlank()) {
            _state.update { it.copy(message = "A title is required for an enabled promotion.") }
            return
        }
        if (draft.enabled && draft.imageUrl.isNotBlank() && !draft.imageUrl.startsWith("http")) {
            _state.update { it.copy(message = "The banner image URL must start with http:// or https://") }
            return
        }
        if (draft.buttonUrl.isNotBlank() && !draft.buttonUrl.startsWith("http")) {
            _state.update {
                it.copy(message = "The button URL must start with http:// or https://")
            }
            return
        }
        if (draft.startAtMillis != null && draft.endAtMillis != null &&
            draft.endAtMillis < draft.startAtMillis
        ) {
            _state.update { it.copy(message = "The end date is before the start date.") }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(saving = true, message = null) }
            val result = dataRepository.savePromotion(draft)
            _state.update {
                it.copy(
                    saving = false,
                    draft = if (result.getOrNull() != null) null else it.draft,
                    message = result.errorOrNull()?.userMessage ?: "Promotion saved."
                )
            }
            load()
        }
    }

    fun delete(promotion: Promotion) {
        viewModelScope.launch {
            val result = dataRepository.deletePromotion(promotion.promotionId)
            _state.update { it.copy(message = result.errorOrNull()?.userMessage ?: "Promotion deleted.") }
            load()
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }
}
