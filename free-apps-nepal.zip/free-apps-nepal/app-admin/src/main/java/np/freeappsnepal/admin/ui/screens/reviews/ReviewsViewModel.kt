package np.freeappsnepal.admin.ui.screens.reviews

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.ReviewRepository
import np.freeappsnepal.core.model.Review
import javax.inject.Inject

@HiltViewModel
class ReviewsViewModel @Inject constructor(
    private val reviewRepository: ReviewRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val reviews: List<Review> = emptyList(),
        val message: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val result = reviewRepository.allReviews(limit = 200)
            _state.update {
                it.copy(
                    loading = false,
                    reviews = result.getOrNull().orEmpty(),
                    message = result.errorOrNull()?.userMessage
                )
            }
        }
    }

    /**
     * Hiding a review is a moderation action. The rules allow an administrator to set only this one
     * field, so a compromised admin client still cannot rewrite a review's text or rating.
     */
    fun setHidden(review: Review, hidden: Boolean) {
        viewModelScope.launch {
            val result = reviewRepository.setHidden(review.itemType, review.itemId, review.reviewId, hidden)
            _state.update { it.copy(message = result.errorOrNull()?.userMessage) }
            load()
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }
}
