package np.freeappsnepal.admin.ui.screens.promotions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.admin.ui.components.ToggleRow
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.Formatters

@Composable
fun PromotionsScreen(viewModel: PromotionsViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = viewModel::beginNew,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("New promotion") }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            state.draft?.let { draft ->
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ToggleRow(
                        label = "Enabled",
                        checked = draft.enabled,
                        supporting = "A disabled or expired promotion is never shown, and no empty space is reserved.",
                        onCheckedChange = { value ->
                            viewModel.updateDraft { it.copy(enabled = value) }
                        }
                    )
                    OutlinedTextField(
                        value = draft.title,
                        onValueChange = { value -> viewModel.updateDraft { it.copy(title = value) } },
                        label = { Text("Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.shortDescription,
                        onValueChange = { value ->
                            viewModel.updateDraft { it.copy(shortDescription = value) }
                        },
                        label = { Text("Short description") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.imageUrl,
                        onValueChange = { value -> viewModel.updateDraft { it.copy(imageUrl = value) } },
                        label = { Text("Banner image URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.buttonText,
                        onValueChange = { value ->
                            viewModel.updateDraft { it.copy(buttonText = value) }
                        },
                        label = { Text("Button text") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.buttonUrl,
                        onValueChange = { value -> viewModel.updateDraft { it.copy(buttonUrl = value) } },
                        label = { Text("Button URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Start: ${Formatters.dateTime(draft.startAtMillis)} · " +
                            "End: ${Formatters.dateTime(draft.endAtMillis)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = FanColors.TextSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = {
                            viewModel.updateDraft { it.copy(startAtMillis = System.currentTimeMillis()) }
                        }) { Text("Start now") }
                        OutlinedButton(onClick = {
                            viewModel.updateDraft { it.copy(startAtMillis = null) }
                        }) { Text("Clear start") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = {
                            viewModel.updateDraft {
                                it.copy(endAtMillis = (it.endAtMillis ?: System.currentTimeMillis()) + 86_400_000L)
                            }
                        }) { Text("End +1 day") }
                        OutlinedButton(onClick = {
                            viewModel.updateDraft { it.copy(endAtMillis = System.currentTimeMillis() + 7 * 86_400_000L) }
                        }) { Text("End +7 days") }
                        OutlinedButton(onClick = {
                            viewModel.updateDraft { it.copy(endAtMillis = null) }
                        }) { Text("Clear end") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = viewModel::save,
                            enabled = !state.saving,
                            modifier = Modifier.weight(1f)
                        ) { Text(if (state.saving) "Saving…" else "Save") }
                        OutlinedButton(onClick = viewModel::cancelEdit, modifier = Modifier.weight(1f)) {
                            Text("Cancel")
                        }
                    }
                }
            }

            when {
                state.loading -> LoadingState(label = "Loading promotions…")
                state.promotions.isEmpty() -> EmptyState(
                    title = "No promotions yet",
                    subtitle = "Create one to show a banner on the home screen."
                )
                else -> LazyColumn(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.promotions, key = { it.promotionId }) { promotion ->
                        Card(
                            onClick = { viewModel.beginEdit(promotion) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = promotion.title.ifBlank { "Untitled promotion" },
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = if (promotion.enabled) "Enabled" else "Disabled",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (promotion.enabled) FanColors.Success else FanColors.TextSecondary
                                    )
                                    Text(
                                        text = "Window: ${Formatters.dateTime(promotion.startAt?.toDate()?.time)}" +
                                            " → ${Formatters.dateTime(promotion.endAt?.toDate()?.time)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = FanColors.TextSecondary
                                    )
                                }
                                IconButton(onClick = { viewModel.delete(promotion) }) {
                                    Icon(
                                        Icons.Filled.Delete,
                                        contentDescription = "Delete",
                                        tint = FanColors.Error
                                    )
                                }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }
}
