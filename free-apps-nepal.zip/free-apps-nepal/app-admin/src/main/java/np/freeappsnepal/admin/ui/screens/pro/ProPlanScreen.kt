package np.freeappsnepal.admin.ui.screens.pro

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.admin.ui.components.KeyValueRow
import np.freeappsnepal.admin.ui.components.SectionCard
import np.freeappsnepal.admin.ui.components.ToggleRow
import np.freeappsnepal.core.model.Plan
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.Formatters
import java.util.Calendar

@Composable
fun ProPlanScreen(viewModel: ProPlanViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        if (state.loading) {
            LoadingState(label = "Loading the Pro plan…")
            return@Scaffold
        }

        val pricePaisa = state.priceNpr.trim().toDoubleOrNull()?.let { (it * 100).toLong() } ?: 0L
        val percent = state.discountPercent.trim().toDoubleOrNull() ?: 0.0
        val previewPlan = Plan(
            planId = Plan.DEFAULT_PLAN_ID,
            pricePaisa = pricePaisa,
            enabled = state.enabled,
            discountEnabled = state.discountEnabled,
            discountPercentage = percent,
            discountStartAt = state.discountStartMillis?.let {
                com.google.firebase.Timestamp(java.util.Date(it))
            },
            discountEndAt = state.discountEndMillis?.let {
                com.google.firebase.Timestamp(java.util.Date(it))
            }
        )

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionCard(title = "Monthly Pro plan") {
                OutlinedTextField(
                    value = state.planName,
                    onValueChange = viewModel::setPlanName,
                    label = { Text("Plan name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = state.description,
                    onValueChange = viewModel::setDescription,
                    label = { Text("Description") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = state.priceNpr,
                    onValueChange = viewModel::setPrice,
                    label = { Text("Monthly price (NPR)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = state.durationDays.toString(),
                    onValueChange = { viewModel.setDuration(it.toIntOrNull() ?: 30) },
                    label = { Text("Duration (days)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                ToggleRow(
                    label = "Plan enabled",
                    checked = state.enabled,
                    onCheckedChange = viewModel::setEnabled
                )
            }

            SectionCard(title = "Discount") {
                ToggleRow(
                    label = "Apply a percentage discount",
                    checked = state.discountEnabled,
                    onCheckedChange = viewModel::setDiscountEnabled
                )
                if (state.discountEnabled) {
                    OutlinedTextField(
                        value = state.discountPercent,
                        onValueChange = viewModel::setDiscountPercent,
                        label = { Text("Discount percentage") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    DatePickerField(
                        label = "Discount starts",
                        millis = state.discountStartMillis,
                        onPick = viewModel::setDiscountStart
                    )
                    DatePickerField(
                        label = "Discount ends",
                        millis = state.discountEndMillis,
                        onPick = viewModel::setDiscountEnd
                    )
                }
            }

            SectionCard(title = "What users will see") {
                val effective = previewPlan.effectivePricePaisa(state.serverNowMillis)
                val appliedPercent = previewPlan.effectiveDiscountPercentage(state.serverNowMillis)
                KeyValueRow(
                    label = "Original price",
                    value = Formatters.moneyFromPaisa(pricePaisa) + "/month"
                )
                if (appliedPercent > 0.0) {
                    KeyValueRow(
                        label = "Discount",
                        value = Formatters.discountPercent(appliedPercent)
                    )
                    Text(
                        text = "Users currently see ${Formatters.moneyFromPaisa(effective)}/month " +
                            "and the line \"All Pro Apps & Games Included\".",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                } else {
                    Text(
                        text = "No discount is active for the current server time, so users see " +
                            "the original price.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FanColors.TextSecondary
                    )
                }
                Text(
                    text = "The backend recomputes this exact rule for every order, so the amount " +
                        "charged can never be influenced by the app.",
                    style = MaterialTheme.typography.bodySmall,
                    color = FanColors.TextSecondary,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Button(
                onClick = viewModel::save,
                enabled = !state.saving,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (state.saving) "Saving…" else "Save plan")
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DatePickerField(label: String, millis: Long?, onPick: (Long?) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = if (millis == null) "Not set (open ended)" else Formatters.dateTime(millis),
                style = MaterialTheme.typography.bodySmall,
                color = FanColors.TextSecondary
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            androidx.compose.material3.TextButton(onClick = { onPick(System.currentTimeMillis()) }) {
                Text("Now")
            }
            androidx.compose.material3.TextButton(onClick = { onPick(millis?.plus(86_400_000L) ?: nextDay()) }) {
                Text("+1 day")
            }
            androidx.compose.material3.TextButton(onClick = { onPick(null) }) { Text("Clear") }
        }
    }
}

private fun nextDay(): Long {
    val calendar = Calendar.getInstance()
    calendar.add(Calendar.DAY_OF_YEAR, 1)
    return calendar.timeInMillis
}
