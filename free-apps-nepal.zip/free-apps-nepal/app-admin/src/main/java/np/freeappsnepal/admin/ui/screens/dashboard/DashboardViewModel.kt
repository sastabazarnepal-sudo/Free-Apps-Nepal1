package np.freeappsnepal.admin.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.CatalogRepository
import np.freeappsnepal.core.data.repo.NetworkMonitor
import np.freeappsnepal.core.data.repo.PromotionRepository
import np.freeappsnepal.core.data.repo.ServerClockRepository
import np.freeappsnepal.core.data.repo.SettingsRepository
import np.freeappsnepal.core.data.repo.SubscriptionRepository
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.Counters
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.Promotion
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject

/**
 * Dashboard data.
 *
 * Every number on this screen is either a value the backend maintained or a count of documents that
 * were actually read. Nothing is estimated, projected or padded. Revenue is shown only from the
 * `revenuePaisa` counter, which the backend increments by the verified paid amount, so a payment
 * that failed verification never contributes to it.
 */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val subscriptionRepository: SubscriptionRepository,
    private val promotionRepository: PromotionRepository,
    private val catalogRepository: CatalogRepository,
    private val serverClockRepository: ServerClockRepository,
    private val networkMonitor: NetworkMonitor
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val counters: Counters = Counters(),
        val latestApps: List<AppItem> = emptyList(),
        val latestGames: List<AppItem> = emptyList(),
        val activePromotion: Promotion? = null,
        val subscribersLoaded: Int = 0,
        val offline: Boolean = false,
        val errorMessage: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            val clock = serverClockRepository.serverClock(forceRefresh = true)
            val serverNow = clock.now(System.currentTimeMillis())

            val countersDeferred = async { settingsRepository.counters() }
            val latestAppsDeferred = async { catalogRepository.page(ItemType.APP, limit = 5) }
            val latestGamesDeferred = async { catalogRepository.page(ItemType.GAME, limit = 5) }
            val promotionDeferred = async { promotionRepository.activePromotion(serverNow) }
            val subscribersDeferred = async { subscriptionRepository.allSubscriptions(limit = 100) }

            val countersResult = countersDeferred.await()
            val latestAppsResult = latestAppsDeferred.await()
            val latestGamesResult = latestGamesDeferred.await()
            val promotionResult = promotionDeferred.await()
            val subscribersResult = subscribersDeferred.await()

            val error = sequenceOf(
                countersResult,
                latestAppsResult,
                latestGamesResult,
                promotionResult
            ).mapNotNull { (it as? AppResult.Failure)?.error?.userMessage }.firstOrNull()

            _state.value = State(
                loading = false,
                counters = countersResult.getOrNull() ?: _state.value.counters,
                latestApps = latestAppsResult.getOrNull()?.items.orEmpty(),
                latestGames = latestGamesResult.getOrNull()?.items.orEmpty(),
                activePromotion = promotionResult.getOrNull(),
                subscribersLoaded = subscribersResult.getOrNull()?.size ?: 0,
                offline = !networkMonitor.currentlyOnline(),
                errorMessage = error
            )
        }
    }
}
