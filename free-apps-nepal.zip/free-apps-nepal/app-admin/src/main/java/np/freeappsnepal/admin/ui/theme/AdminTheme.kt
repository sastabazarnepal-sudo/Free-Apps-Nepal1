package np.freeappsnepal.admin.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import np.freeappsnepal.core.ui.theme.FanColors

/**
 * The admin application is deliberately not the coral red marketplace palette. A neutral
 * professional surface makes it obvious at a glance which application is open, which matters when a
 * destructive catalogue action is one tap away.
 */
private val AdminNavy = Color(0xFF1F2937)
private val AdminTeal = Color(0xFF0F766E)
private val AdminTealContainer = Color(0xFFD5F0EC)
private val AdminSurface = Color(0xFFFFFFFF)
private val AdminBackground = Color(0xFFFAFAFB)

private val LightScheme = lightColorScheme(
    primary = AdminTeal,
    onPrimary = Color.White,
    primaryContainer = AdminTealContainer,
    onPrimaryContainer = Color(0xFF00201C),
    secondary = AdminNavy,
    onSecondary = Color.White,
    background = AdminBackground,
    onBackground = FanColors.TextPrimary,
    surface = AdminSurface,
    onSurface = FanColors.TextPrimary,
    surfaceVariant = FanColors.SurfaceVariant,
    onSurfaceVariant = FanColors.TextSecondary,
    outline = FanColors.Outline,
    error = FanColors.Error,
    onError = Color.White
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF4FD1C5),
    onPrimary = Color(0xFF00332D),
    secondary = Color(0xFF9AA5B1),
    background = Color(0xFF121417),
    surface = Color(0xFF1B1F23)
)

@Composable
fun AdminTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        content = content
    )
}
