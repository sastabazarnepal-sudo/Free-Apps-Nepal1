package np.freeappsnepal.admin

import android.app.Application
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.crashlytics.FirebaseCrashlytics
import dagger.hilt.android.HiltAndroidApp
import np.freeappsnepal.core.BuildConfig

@HiltAndroidApp
class FreeAppsNepalAdminApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // App Check runs in the admin application too. It attests that catalogue writes and plan
        // edits come from the genuine, unmodified admin build installed from the trusted source.
        // Same split as the user app: Play Integrity cannot attest a CI built debug APK, so the
        // debug provider is used there and Play Integrity in release.
        val appCheckProvider = if (BuildConfig.DEBUG) {
            DebugAppCheckProviderFactory.getInstance()
        } else {
            PlayIntegrityAppCheckProviderFactory.getInstance()
        }
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(appCheckProvider)

        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(!BuildConfig.DEBUG)
    }
}
