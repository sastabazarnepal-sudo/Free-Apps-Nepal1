package np.freeappsnepal.admin.ui.screens.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.admin.data.AdminDataRepository
import np.freeappsnepal.admin.data.AdminWriteRepository
import np.freeappsnepal.admin.data.ItemDraft
import np.freeappsnepal.core.model.Category
import np.freeappsnepal.core.model.ItemType
import javax.inject.Inject

@HiltViewModel
class ItemEditorViewModel @Inject constructor(
    private val dataRepository: AdminDataRepository,
    private val writeRepository: AdminWriteRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val saving: Boolean = false,
        val draft: ItemDraft = ItemDraft(),
        val categories: List<Category> = emptyList(),
        val existingProUrlConfigured: Boolean = false,
        val message: String? = null,
        val saved: Boolean = false
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private var itemType: ItemType = ItemType.APP

    fun start(type: ItemType, itemId: String?) {
        itemType = type
        viewModelScope.launch {
            val categories = dataRepository.categories().getOrNull().orEmpty()
            if (itemId.isNullOrBlank()) {
                _state.value = State(
                    loading = false,
                    draft = ItemDraft(type = type),
                    categories = categories
                )
                return@launch
            }
            val item = dataRepository.item(type, itemId).getOrNull()
            // The Pro URL is not readable from the catalogue document. The editor shows whether one
            // is already configured instead of the value itself.
            val secureUrl = dataRepository.proSecureLink(itemId).getOrNull().orEmpty()
            _state.value = State(
                loading = false,
                draft = item?.let { ItemDraft.from(it, proUrl = "") } ?: ItemDraft(type = type),
                categories = categories,
                existingProUrlConfigured = secureUrl.isNotBlank()
            )
        }
    }

    fun update(transform: (ItemDraft) -> ItemDraft) {
        _state.value = _state.value.copy(draft = transform(_state.value.draft), message = null)
    }

    fun save() {
        val draft = _state.value.draft
        if (draft.name.isBlank()) {
            _state.value = _state.value.copy(message = "A name is required.")
            return
        }
        if (draft.freeEnabled && !draft.freeDownloadUrl.startsWith("http")) {
            _state.value = _state.value.copy(
                message = "The Free download URL must start with http:// or https://"
            )
            return
        }
        if (draft.proEnabled && draft.proDownloadUrl.isNotBlank() &&
            !draft.proDownloadUrl.startsWith("http")
        ) {
            _state.value = _state.value.copy(
                message = "The Pro download URL must start with http:// or https://"
            )
            return
        }

        viewModelScope.launch {
            _state.value = _state.value.copy(saving = true, message = null)
            val result = writeRepository.saveItem(itemType, draft.toMap())
            _state.value = _state.value.copy(
                saving = false,
                saved = result.getOrNull() != null,
                message = result.errorOrNull()?.userMessage
                    ?: "Saved. The user app will reflect this change automatically."
            )
        }
    }

    fun delete(onDeleted: () -> Unit) {
        val itemId = _state.value.draft.itemId
        if (itemId.isBlank()) return
        viewModelScope.launch {
            val result = writeRepository.deleteItem(itemType, itemId)
            if (result.getOrNull() != null) onDeleted() else {
                _state.value = _state.value.copy(message = result.errorOrNull()?.userMessage)
            }
        }
    }

    fun clearMessage() {
        _state.value = _state.value.copy(message = null)
    }
}
