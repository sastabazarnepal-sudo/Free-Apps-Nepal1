package np.freeappsnepal.admin.ui.screens.categories

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.admin.ui.components.ToggleRow
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.theme.FanColors

@Composable
fun CategoriesScreen(viewModel: CategoriesViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = viewModel::beginNew,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("New category") }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            val draft = state.draft
            if (draft != null) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (draft.categoryId.isBlank()) "New category" else "Edit category",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedTextField(
                        value = draft.name,
                        onValueChange = { value -> viewModel.updateDraft { it.copy(name = value) } },
                        label = { Text("Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.nameNe,
                        onValueChange = { value -> viewModel.updateDraft { it.copy(nameNe = value) } },
                        label = { Text("Name (Nepali)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.description,
                        onValueChange = { value ->
                            viewModel.updateDraft { it.copy(description = value) }
                        },
                        label = { Text("Description") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.iconUrl,
                        onValueChange = { value -> viewModel.updateDraft { it.copy(iconUrl = value) } },
                        label = { Text("Icon URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.appliesTo,
                        onValueChange = { value ->
                            viewModel.updateDraft { it.copy(appliesTo = value.uppercase()) }
                        },
                        label = { Text("Applies to (APP, GAME or BOTH)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.order.toString(),
                        onValueChange = { value ->
                            viewModel.updateDraft { it.copy(order = value.toIntOrNull() ?: 0) }
                        },
                        label = { Text("Sort order") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    ToggleRow(
                        label = "Enabled",
                        checked = draft.enabled,
                        onCheckedChange = { value ->
                            viewModel.updateDraft { it.copy(enabled = value) }
                        }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = viewModel::save,
                            enabled = !state.saving,
                            modifier = Modifier.weight(1f)
                        ) { Text(if (state.saving) "Saving…" else "Save") }
                        OutlinedButton(onClick = viewModel::cancelEdit, modifier = Modifier.weight(1f)) {
                            Text("Cancel")
                        }
                    }
                }
            }

            when {
                state.loading -> LoadingState(label = "Loading categories…")
                state.categories.isEmpty() -> EmptyState(
                    title = "No categories yet",
                    subtitle = "Add the first category with the button below."
                )
                else -> LazyColumn(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.categories, key = { it.categoryId }) { category ->
                        Card(
                            onClick = { viewModel.beginEdit(category) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = category.displayName,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Applies to ${category.type?.name ?: "Apps and Games"}" +
                                            if (!category.enabled) " · disabled" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = FanColors.TextSecondary
                                    )
                                }
                                IconButton(onClick = { viewModel.delete(category) }) {
                                    Icon(
                                        Icons.Filled.Delete,
                                        contentDescription = "Delete",
                                        tint = FanColors.Error
                                    )
                                }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }
}
