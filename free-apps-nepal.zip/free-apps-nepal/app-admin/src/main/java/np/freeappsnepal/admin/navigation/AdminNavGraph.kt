package np.freeappsnepal.admin.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.launch
import np.freeappsnepal.admin.auth.AdminSessionViewModel
import np.freeappsnepal.admin.ui.screens.auth.AdminGateScreen
import np.freeappsnepal.admin.ui.screens.categories.CategoriesScreen
import np.freeappsnepal.admin.ui.screens.dashboard.DashboardScreen
import np.freeappsnepal.admin.ui.screens.editor.ItemEditorScreen
import np.freeappsnepal.admin.ui.screens.items.ItemsScreen
import np.freeappsnepal.admin.ui.screens.pro.ProPlanScreen
import np.freeappsnepal.admin.ui.screens.promotions.PromotionsScreen
import np.freeappsnepal.admin.ui.screens.reviews.ReviewsScreen
import np.freeappsnepal.admin.ui.screens.subscribers.SubscribersScreen
import np.freeappsnepal.core.model.ItemType

private data class DrawerEntry(val route: String, val label: String, val icon: ImageVector)

private val drawerEntries = listOf(
    DrawerEntry(AdminRoutes.DASHBOARD, "Dashboard", Icons.Filled.Dashboard),
    DrawerEntry(AdminRoutes.APPS, "Apps", Icons.AutoMirrored.Filled.List),
    DrawerEntry(AdminRoutes.GAMES, "Games", Icons.Filled.Games),
    DrawerEntry(AdminRoutes.CATEGORIES, "Categories", Icons.Filled.WorkspacePremium),
    DrawerEntry(AdminRoutes.PROMOTIONS, "Promotions", Icons.Filled.Campaign),
    DrawerEntry(AdminRoutes.PRO, "Pro plan", Icons.Filled.WorkspacePremium),
    DrawerEntry(AdminRoutes.SUBSCRIBERS, "Subscribers", Icons.Filled.People),
    DrawerEntry(AdminRoutes.REVIEWS, "Reviews", Icons.Filled.Star)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminNavGraph(
    state: AdminSessionViewModel.AdminState,
    busy: Boolean,
    error: String?,
    sessionViewModel: AdminSessionViewModel
) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val currentRoute = navController.currentBackStackEntry?.destination?.route
    val title = drawerEntries.firstOrNull { it.route == currentRoute }?.label ?: "Free Apps Nepal Admin"

    when (state) {
        is AdminSessionViewModel.AdminState.Loading -> {
            AdminGateScreen(
                title = "Checking administrator access",
                message = "Verifying your account against the backend before anything is shown.",
                busy = true,
                actionLabel = null,
                onAction = {},
                error = null
            )
        }

        is AdminSessionViewModel.AdminState.SignedOut -> {
            AdminGateScreen(
                title = "Administrator sign in",
                message = "Sign in with an administrator account. Access is granted by a backend " +
                    "custom claim, never by a hardcoded password or an email check in the app.",
                busy = busy,
                actionLabel = "Sign in",
                onSignIn = sessionViewModel::signIn,
                onAction = {},
                error = error
            )
        }

        is AdminSessionViewModel.AdminState.NotAdmin -> {
            AdminGateScreen(
                title = "Not an administrator",
                message = "The account ${state.email} is signed in but has no administrator claim. " +
                    "If no administrator exists yet on this project, you may claim the first one " +
                    "here; the backend only allows this while no administrator exists.",
                busy = busy,
                actionLabel = "Claim first administrator",
                onAction = sessionViewModel::claimFirstAdmin,
                onSignOut = sessionViewModel::signOut,
                error = error
            )
        }

        is AdminSessionViewModel.AdminState.Ready -> {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet {
                        Text(
                            text = "Free Apps Nepal Admin",
                            modifier = Modifier.padding(16.dp),
                            style = androidx.compose.material3.MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = state.email,
                            modifier = Modifier.padding(horizontal = 16.dp),
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = np.freeappsnepal.core.ui.theme.FanColors.TextSecondary
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                        drawerEntries.forEach { entry ->
                            NavigationDrawerItem(
                                label = { Text(entry.label) },
                                icon = { Icon(entry.icon, contentDescription = entry.label) },
                                selected = currentRoute == entry.route,
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    navController.navigate(entry.route) {
                                        launchSingleTop = true
                                        popUpTo(AdminRoutes.DASHBOARD)
                                    }
                                },
                                modifier = Modifier.padding(horizontal = 10.dp)
                            )
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                        NavigationDrawerItem(
                            label = { Text("Sign out") },
                            icon = { Icon(Icons.Filled.People, contentDescription = null) },
                            selected = false,
                            onClick = sessionViewModel::signOut,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        )
                    }
                }
            ) {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text(title) },
                            navigationIcon = {
                                androidx.compose.material3.IconButton(
                                    onClick = { scope.launch { drawerState.open() } }
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Menu")
                                }
                            }
                        )
                    }
                ) { padding ->
                    NavHost(
                        navController = navController,
                        startDestination = AdminRoutes.DASHBOARD,
                        modifier = Modifier.padding(padding)
                    ) {
                        composable(AdminRoutes.DASHBOARD) { DashboardScreen() }
                        composable(AdminRoutes.APPS) {
                            ItemsScreen(
                                itemType = ItemType.APP,
                                onOpenEditor = { type, id ->
                                    navController.navigate(AdminRoutes.editor(type, id))
                                }
                            )
                        }
                        composable(AdminRoutes.GAMES) {
                            ItemsScreen(
                                itemType = ItemType.GAME,
                                onOpenEditor = { type, id ->
                                    navController.navigate(AdminRoutes.editor(type, id))
                                }
                            )
                        }
                        composable(AdminRoutes.CATEGORIES) { CategoriesScreen() }
                        composable(AdminRoutes.PROMOTIONS) { PromotionsScreen() }
                        composable(AdminRoutes.PRO) { ProPlanScreen() }
                        composable(AdminRoutes.SUBSCRIBERS) { SubscribersScreen() }
                        composable(AdminRoutes.REVIEWS) { ReviewsScreen() }
                        composable(
                            route = AdminRoutes.EDITOR,
                            arguments = listOf(
                                navArgument(AdminRoutes.ITEM_ID) {
                                    type = NavType.StringType
                                    defaultValue = ""
                                },
                                navArgument(AdminRoutes.ITEM_TYPE) {
                                    type = NavType.StringType
                                    defaultValue = ItemType.APP.name
                                }
                            )
                        ) { entry ->
                            ItemEditorScreen(
                                itemId = entry.arguments?.getString(AdminRoutes.ITEM_ID).orEmpty(),
                                itemType = ItemType.fromName(
                                    entry.arguments?.getString(AdminRoutes.ITEM_TYPE)
                                ),
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
