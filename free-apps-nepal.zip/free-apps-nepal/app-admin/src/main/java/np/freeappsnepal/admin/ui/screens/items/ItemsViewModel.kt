package np.freeappsnepal.admin.ui.screens.items

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.admin.data.AdminDataRepository
import np.freeappsnepal.admin.data.AdminWriteRepository
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.ItemType
import javax.inject.Inject

@HiltViewModel
class ItemsViewModel @Inject constructor(
    private val dataRepository: AdminDataRepository,
    private val writeRepository: AdminWriteRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val items: List<AppItem> = emptyList(),
        val publishedOnly: Boolean = false,
        val message: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private var itemType: ItemType = ItemType.APP

    fun start(type: ItemType) {
        itemType = type
        load()
    }

    fun load(publishedOnly: Boolean = _state.value.publishedOnly) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val result = dataRepository.items(itemType, publishedOnly, limit = 100)
            _state.value = State(
                loading = false,
                items = result.getOrNull().orEmpty(),
                publishedOnly = publishedOnly,
                message = result.errorOrNull()?.userMessage
            )
        }
    }

    /** Publishing and unpublishing go through the server, which owns the catalogue document. */
    fun setPublished(item: AppItem, published: Boolean) {
        viewModelScope.launch {
            val fields = mapOf(
                "itemId" to item.itemId,
                "name" to item.name,
                "freeEnabled" to item.freeEnabled,
                "freeDownloadUrl" to item.freeDownloadUrl,
                "proEnabled" to item.proEnabled,
                "published" to published,
                "featured" to item.featured,
                "popular" to item.popular,
                "isNew" to item.isNew
            )
            val result = writeRepository.saveItem(itemType, fields)
            _state.value = _state.value.copy(
                message = result.errorOrNull()?.userMessage
                    ?: if (published) "Published ${item.name}." else "Unpublished ${item.name}."
            )
            load()
        }
    }

    fun delete(item: AppItem) {
        viewModelScope.launch {
            val result = writeRepository.deleteItem(itemType, item.itemId)
            _state.value = _state.value.copy(
                message = result.errorOrNull()?.userMessage ?: "Deleted ${item.name}."
            )
            load()
        }
    }

    fun clearMessage() {
        _state.value = _state.value.copy(message = null)
    }
}
