package np.freeappsnepal.admin.ui.screens.pro

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.admin.data.AdminWriteRepository
import np.freeappsnepal.core.data.repo.ServerClockRepository
import np.freeappsnepal.core.data.repo.SubscriptionRepository
import np.freeappsnepal.core.model.Plan
import np.freeappsnepal.core.util.Formatters
import javax.inject.Inject

/**
 * The Pro plan editor.
 *
 * The client never sends a price at purchase time; it only edits the plan document here, and the
 * backend recomputes the effective price from that document for every order. The preview below is
 * display only and uses the same rule the backend applies: an enabled discount with a positive
 * percentage inside its window.
 */
@HiltViewModel
class ProPlanViewModel @Inject constructor(
    private val subscriptionRepository: SubscriptionRepository,
    private val writeRepository: AdminWriteRepository,
    private val serverClockRepository: ServerClockRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val saving: Boolean = false,
        val plan: Plan? = null,
        val planName: String = "",
        val description: String = "",
        val priceNpr: String = "99",
        val durationDays: Int = 30,
        val enabled: Boolean = true,
        val discountEnabled: Boolean = false,
        val discountPercent: String = "0",
        val discountStartMillis: Long? = null,
        val discountEndMillis: Long? = null,
        val serverNowMillis: Long = System.currentTimeMillis(),
        val message: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private var bootstrapAttempted = false

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val plan = subscriptionRepository.plan().getOrNull()
            val serverNow = serverClockRepository
                .serverClock(forceRefresh = true)
                .now(System.currentTimeMillis())
            _state.value = if (plan == null) {
                State(loading = false, serverNowMillis = serverNow)
            } else {
                State(
                    loading = false,
                    plan = plan,
                    planName = plan.name,
                    description = plan.description,
                    priceNpr = Formatters.amountFromPaisa(plan.pricePaisa),
                    durationDays = plan.durationDays,
                    enabled = plan.enabled,
                    discountEnabled = plan.discountEnabled,
                    discountPercent = plan.discountPercentage.toString(),
                    discountStartMillis = plan.discountStartAt?.toDate()?.time,
                    discountEndMillis = plan.discountEndAt?.toDate()?.time,
                    serverNowMillis = serverNow
                )
            }
            // A brand new project has no plan document. Creating the default one requires the
            // bootstrap callable, which the administrator claim authorises. It is attempted once so
            // a failure cannot spin this screen.
            if (plan == null && !bootstrapAttempted) {
                bootstrapAttempted = true
                val created = writeRepository.bootstrapProject(9900L)
                if (created.getOrNull() != null) load()
            }
        }
    }

    fun setPlanName(value: String) = _state.update { it.copy(planName = value) }
    fun setDescription(value: String) = _state.update { it.copy(description = value) }
    fun setPrice(value: String) = _state.update { it.copy(priceNpr = value) }
    fun setDuration(days: Int) = _state.update { it.copy(durationDays = days) }
    fun setEnabled(value: Boolean) = _state.update { it.copy(enabled = value) }
    fun setDiscountEnabled(value: Boolean) = _state.update { it.copy(discountEnabled = value) }
    fun setDiscountPercent(value: String) = _state.update { it.copy(discountPercent = value) }
    fun setDiscountStart(millis: Long?) = _state.update { it.copy(discountStartMillis = millis) }
    fun setDiscountEnd(millis: Long?) = _state.update { it.copy(discountEndMillis = millis) }

    private inline fun MutableStateFlow<State>.update(block: (State) -> State) {
        value = block(value)
    }

    fun save() {
        val current = _state.value
        val pricePaisa = current.priceNpr.trim().toDoubleOrNull()?.let { (it * 100).toLong() }
        if (pricePaisa == null || pricePaisa <= 0L) {
            _state.value = current.copy(message = "Enter a valid monthly price in NPR.")
            return
        }
        val percent = current.discountPercent.trim().toDoubleOrNull() ?: 0.0
        if (current.discountEnabled && percent <= 0.0) {
            _state.value = current.copy(message = "Enter a discount percentage greater than zero.")
            return
        }
        if (current.discountEnabled &&
            current.discountStartMillis != null &&
            current.discountEndMillis != null &&
            current.discountEndMillis < current.discountStartMillis
        ) {
            _state.value = current.copy(message = "The discount end date is before the start date.")
            return
        }

        viewModelScope.launch {
            _state.value = current.copy(saving = true, message = null)
            val result = writeRepository.savePlan(
                mapOf(
                    "planId" to Plan.DEFAULT_PLAN_ID,
                    "name" to current.planName.trim(),
                    "description" to current.description.trim(),
                    "pricePaisa" to pricePaisa,
                    "durationDays" to current.durationDays,
                    "enabled" to current.enabled,
                    "discountEnabled" to current.discountEnabled,
                    "discountPercentage" to percent,
                    "discountStartAt" to current.discountStartMillis,
                    "discountEndAt" to current.discountEndMillis
                )
            )
            _state.value = _state.value.copy(
                saving = false,
                message = result.errorOrNull()?.userMessage ?: "Plan saved."
            )
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }
}
