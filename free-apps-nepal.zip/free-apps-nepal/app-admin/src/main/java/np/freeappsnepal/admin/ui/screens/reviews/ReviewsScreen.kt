package np.freeappsnepal.admin.ui.screens.reviews

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.Formatters

/**
 * Review moderation. An administrator can hide or restore a review, but cannot edit its text or
 * rating, which the security rules enforce at the field level.
 */
@Composable
fun ReviewsScreen(viewModel: ReviewsViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        if (state.loading) {
            LoadingState(label = "Loading reviews…")
            return@Scaffold
        }
        if (state.reviews.isEmpty()) {
            EmptyState(
                title = "No reviews yet",
                subtitle = "Reviews written by users will appear here for moderation."
            )
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.reviews, key = { it.reviewId }) { review ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = review.itemName.ifBlank { review.itemId },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${review.userName.ifBlank { review.userId }} · " +
                                        "${review.itemType.name.lowercase()} · " +
                                        "${review.rating}/5",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = FanColors.TextSecondary
                                )
                            }
                            Switch(
                                checked = review.hidden,
                                onCheckedChange = { hidden -> viewModel.setHidden(review, hidden) }
                            )
                        }
                        if (review.text.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(text = review.text, style = MaterialTheme.typography.bodyMedium)
                        }
                        Text(
                            text = Formatters.dateTime(review.createdAt?.toDate()?.time) +
                                if (review.hidden) " · hidden from users" else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = FanColors.TextSecondary,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
