package np.freeappsnepal.admin.ui.screens.subscribers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.admin.ui.components.KeyValueRow
import np.freeappsnepal.core.model.SubscriptionStatus
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.Formatters

@Composable
fun SubscribersScreen(viewModel: SubscribersViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var filter by remember { mutableStateOf<SubscriptionStatus?>(null) }

    LaunchedEffect(Unit) { viewModel.load() }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filter == null,
                onClick = { filter = null },
                label = { Text("All") }
            )
            SubscriptionStatus.entries.forEach { status ->
                FilterChip(
                    selected = filter == status,
                    onClick = { filter = status },
                    label = { Text(status.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        when {
            state.loading -> LoadingState(label = "Loading subscriptions…")
            else -> {
                val visible = state.subscriptions.filter { filter == null || it.status == filter }
                if (visible.isEmpty()) {
                    EmptyState(
                        title = "No subscriptions",
                        subtitle = "Nothing matches this filter yet."
                    )
                } else {
                    LazyColumn(
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(visible, key = { it.subscriptionId }) { subscription ->
                            val active = subscription.isCurrentlyActive(state.serverNowMillis)
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = subscription.paymentMethod.label,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = subscription.status.name,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = when {
                                                active -> FanColors.Success
                                                subscription.status == SubscriptionStatus.PENDING -> FanColors.Warning
                                                else -> FanColors.TextSecondary
                                            }
                                        )
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    KeyValueRow("User", subscription.userId)
                                    KeyValueRow("Plan", subscription.planName.ifBlank { subscription.planId })
                                    KeyValueRow(
                                        "Original amount",
                                        Formatters.moneyFromPaisa(subscription.originalPricePaisa)
                                    )
                                    KeyValueRow(
                                        "Discount",
                                        if (subscription.discountPercentage > 0.0) {
                                            Formatters.discountPercent(subscription.discountPercentage)
                                        } else {
                                            "None"
                                        }
                                    )
                                    KeyValueRow(
                                        "Final amount",
                                        Formatters.moneyFromPaisa(subscription.finalPricePaidPaisa)
                                    )
                                    KeyValueRow("Transaction ID", subscription.transactionId)
                                    KeyValueRow("Order ID", subscription.orderId)
                                    KeyValueRow("Start", Formatters.dateTime(subscription.startAt?.toDate()?.time))
                                    KeyValueRow(
                                        "Expiry",
                                        Formatters.dateTime(subscription.expiresAt?.toDate()?.time)
                                    )
                                    KeyValueRow(
                                        "Verified by",
                                        subscription.verifiedBy.ifBlank { "backend" }
                                    )
                                }
                            }
                        }
                        item { Spacer(Modifier.height(24.dp)) }
                    }
                }
            }
        }
    }
}
