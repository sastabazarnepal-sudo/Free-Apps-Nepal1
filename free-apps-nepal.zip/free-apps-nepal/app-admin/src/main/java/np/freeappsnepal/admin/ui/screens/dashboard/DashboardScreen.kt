package np.freeappsnepal.admin.ui.screens.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.admin.ui.components.KeyValueRow
import np.freeappsnepal.admin.ui.components.SectionCard
import np.freeappsnepal.admin.ui.components.StatCard
import np.freeappsnepal.core.ui.common.ErrorState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.components.ItemListRow
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.Formatters

@Composable
fun DashboardScreen(viewModel: DashboardViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    if (state.loading) {
        LoadingState(label = "Loading dashboard…")
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Overview",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
            if (state.offline) {
                Text(
                    text = "No connection. Showing the last values this device stored.",
                    style = MaterialTheme.typography.bodySmall,
                    color = FanColors.Warning
                )
            }
            if (state.errorMessage != null) {
                ErrorState(message = state.errorMessage!!, onRetry = viewModel::load)
            }
        }

        item {
            val counters = state.counters
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Apps", counters.totalApps.toString(), Modifier.weight(1f))
                    StatCard("Games", counters.totalGames.toString(), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Users", counters.totalUsers.toString(), Modifier.weight(1f))
                    StatCard("Page views", counters.pageViews.toString(), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        "Free download clicks",
                        counters.freeDownloadClicks.toString(),
                        Modifier.weight(1f)
                    )
                    StatCard(
                        "Pro download clicks",
                        counters.proDownloadClicks.toString(),
                        Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        "Active Pro subscribers",
                        counters.activeProSubscribers.toString(),
                        Modifier.weight(1f)
                    )
                    StatCard(
                        "Subscription purchases",
                        counters.subscriptionPurchases.toString(),
                        Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            SectionCard(title = "Payments and revenue") {
                KeyValueRow(
                    label = "Pending payments",
                    value = state.counters.pendingPayments.toString()
                )
                KeyValueRow(
                    label = "Verified revenue",
                    value = Formatters.moneyFromPaisa(state.counters.revenuePaisa)
                )
                Text(
                    text = "Revenue is the sum of payments the backend verified with the provider. " +
                        "Pending, failed and cancelled payments are not counted.",
                    style = MaterialTheme.typography.bodySmall,
                    color = FanColors.TextSecondary
                )
            }
        }

        item {
            SectionCard(title = "Active promotion") {
                val promotion = state.activePromotion
                if (promotion == null) {
                    Text(
                        text = "No promotion is active right now. The banner is not shown to users.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FanColors.TextSecondary
                    )
                } else {
                    KeyValueRow(label = "Title", value = promotion.title)
                    KeyValueRow(label = "Button", value = promotion.buttonText)
                    KeyValueRow(label = "URL", value = promotion.buttonUrl)
                }
            }
        }

        item {
            SectionCard(title = "Latest apps") {
                if (state.latestApps.isEmpty()) {
                    Text("No published apps yet.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.latestApps.forEach { item ->
                            ItemListRow(item = item, onClick = {})
                        }
                    }
                }
            }
        }

        item {
            SectionCard(title = "Latest games") {
                if (state.latestGames.isEmpty()) {
                    Text("No published games yet.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.latestGames.forEach { item ->
                            ItemListRow(item = item, onClick = {})
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}
