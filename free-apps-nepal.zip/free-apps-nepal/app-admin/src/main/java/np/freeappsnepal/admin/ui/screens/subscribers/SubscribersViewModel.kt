package np.freeappsnepal.admin.ui.screens.subscribers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.ServerClockRepository
import np.freeappsnepal.core.data.repo.SubscriptionRepository
import np.freeappsnepal.core.model.Subscription
import np.freeappsnepal.core.model.SubscriptionStatus
import javax.inject.Inject

/**
 * Subscriber and payment records.
 *
 * Everything displayed is read from the subscription and order documents the backend wrote after a
 * provider verification. There is no locally derived "paid" state, so a pending payment never shows
 * as revenue and a failed verification never shows as active.
 */
@HiltViewModel
class SubscribersViewModel @Inject constructor(
    private val subscriptionRepository: SubscriptionRepository,
    private val serverClockRepository: ServerClockRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val subscriptions: List<Subscription> = emptyList(),
        val serverNowMillis: Long = System.currentTimeMillis(),
        val message: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val serverNow = serverClockRepository.serverClock().now(System.currentTimeMillis())
            val result = subscriptionRepository.allSubscriptions(limit = 200)
            _state.update {
                it.copy(
                    loading = false,
                    subscriptions = result.getOrNull().orEmpty(),
                    serverNowMillis = serverNow,
                    message = result.errorOrNull()?.userMessage
                )
            }
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }
}

internal fun Subscription.isCurrentlyActive(serverNowMillis: Long): Boolean =
    status == SubscriptionStatus.ACTIVE &&
        (expiresAt?.toDate()?.time ?: 0L) > serverNowMillis
