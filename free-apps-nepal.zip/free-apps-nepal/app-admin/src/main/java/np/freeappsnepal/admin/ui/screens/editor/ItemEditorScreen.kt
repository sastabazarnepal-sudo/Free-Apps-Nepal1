package np.freeappsnepal.admin.ui.screens.editor

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.admin.ui.components.SectionCard
import np.freeappsnepal.admin.ui.components.ToggleRow
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.theme.FanColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemEditorScreen(
    itemId: String,
    itemType: ItemType,
    onBack: () -> Unit,
    viewModel: ItemEditorViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(itemId, itemType) { viewModel.start(itemType, itemId) }
    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }
    LaunchedEffect(state.saved) { if (state.saved) onBack() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(if (itemId.isBlank()) "New ${itemType.label}" else "Edit ${itemType.label}") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (itemId.isNotBlank()) {
                        IconButton(onClick = { viewModel.delete(onBack) }) {
                            Icon(
                                Icons.Filled.Delete,
                                contentDescription = "Delete",
                                tint = FanColors.Error
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (state.loading) {
            LoadingState(label = "Loading listing…")
            return@Scaffold
        }
        val draft = state.draft

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionCard(title = "Basics") {
                Field("Name", draft.name) { viewModel.update { d -> d.copy(name = it) } }
                Field("Developer", draft.developerName) {
                    viewModel.update { d -> d.copy(developerName = it) }
                }
                Field("Version", draft.version) { viewModel.update { d -> d.copy(version = it) } }
                Field("File size", draft.fileSize) {
                    viewModel.update { d -> d.copy(fileSize = it) }
                }
                Field("Minimum Android version", draft.minAndroidVersion) {
                    viewModel.update { d -> d.copy(minAndroidVersion = it) }
                }
                Field("Icon URL", draft.iconUrl) { viewModel.update { d -> d.copy(iconUrl = it) } }
                Field(
                    label = "Screenshots (one URL per line)",
                    value = draft.screenshots,
                    singleLine = false
                ) { viewModel.update { d -> d.copy(screenshots = it) } }
                Field("Description", draft.description, singleLine = false) {
                    viewModel.update { d -> d.copy(description = it) }
                }
                Field("What's new", draft.whatsNew, singleLine = false) {
                    viewModel.update { d -> d.copy(whatsNew = it) }
                }
            }

            SectionCard(title = "Category") {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = draft.categoryName.ifBlank { "Select a category" },
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        state.categories
                            .filter { it.appliesTo(itemType) }
                            .forEach { category ->
                                DropdownMenuItem(
                                    text = { Text(category.displayName) },
                                    onClick = {
                                        viewModel.update { d ->
                                            d.copy(
                                                categoryId = category.categoryId,
                                                categoryName = category.name
                                            )
                                        }
                                        expanded = false
                                    }
                                )
                            }
                    }
                }
            }

            SectionCard(title = "Offering") {
                ToggleRow(
                    label = "Free version",
                    checked = draft.freeEnabled,
                    supporting = "The Free download link stays available to everyone, including Pro users.",
                    onCheckedChange = { viewModel.update { d -> d.copy(freeEnabled = it) } }
                )
                if (draft.freeEnabled) {
                    Field("Free download URL (external, used as entered)", draft.freeDownloadUrl) {
                        viewModel.update { d -> d.copy(freeDownloadUrl = it) }
                    }
                }
                Spacer(Modifier.height(6.dp))
                ToggleRow(
                    label = "Pro version",
                    checked = draft.proEnabled,
                    supporting = "Direct download for active subscribers. No extra ad, no per app purchase.",
                    onCheckedChange = { viewModel.update { d -> d.copy(proEnabled = it) } }
                )
                if (draft.proEnabled) {
                    if (state.existingProUrlConfigured) {
                        Text(
                            text = "A Pro link is already stored on the server. Leave the field " +
                                "blank to keep it, or type a new URL to replace it.",
                            style = MaterialTheme.typography.bodySmall,
                            color = FanColors.TextSecondary
                        )
                    }
                    Field("Pro download URL", draft.proDownloadUrl) {
                        viewModel.update { d -> d.copy(proDownloadUrl = it) }
                    }
                }
            }

            SectionCard(title = "Visibility and flags") {
                ToggleRow(
                    label = "Published",
                    checked = draft.published,
                    supporting = "Only published listings appear in the user app.",
                    onCheckedChange = { viewModel.update { d -> d.copy(published = it) } }
                )
                ToggleRow(
                    label = "Featured",
                    checked = draft.featured,
                    onCheckedChange = { viewModel.update { d -> d.copy(featured = it) } }
                )
                ToggleRow(
                    label = "Popular",
                    checked = draft.popular,
                    onCheckedChange = { viewModel.update { d -> d.copy(popular = it) } }
                )
                ToggleRow(
                    label = "New",
                    checked = draft.isNew,
                    onCheckedChange = { viewModel.update { d -> d.copy(isNew = it) } }
                )
            }

            Button(
                onClick = viewModel::save,
                enabled = !state.saving,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (state.saving) "Saving…" else "Save")
            }

            OutlinedButton(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cancel")
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    singleLine: Boolean = true,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 3,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (singleLine) KeyboardType.Text else KeyboardType.Text
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    )
}
