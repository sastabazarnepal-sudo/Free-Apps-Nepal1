package np.freeappsnepal.admin.data

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await
import np.freeappsnepal.core.data.Mappers
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.Category
import np.freeappsnepal.core.model.FirestoreCollections
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.Promotion
import np.freeappsnepal.core.util.AppError
import np.freeappsnepal.core.util.AppResult
import np.freeappsnepal.core.util.AppResultKt
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Catalogue, plan and secure link writes from the admin application.
 *
 * All of these go through callables. Security rules refuse client writes to the catalogue, plans and
 * secure links, so the admin application is a thin client for a server that re-checks the
 * administrator claim, the URL shape and the price inputs on every request.
 */
@Singleton
class AdminWriteRepository @Inject constructor(
    private val functions: FirebaseFunctions
) {

    suspend fun saveItem(itemType: ItemType, fields: Map<String, Any?>): AppResult<String> =
        call("upsertItem", fields + ("itemType" to itemType.name)) { data ->
            data["itemId"]?.toString().orEmpty()
        }

    suspend fun deleteItem(itemType: ItemType, itemId: String): AppResult<Unit> =
        call("deleteItem", mapOf("itemId" to itemId, "itemType" to itemType.name)) { }

    suspend fun savePlan(fields: Map<String, Any?>): AppResult<Unit> =
        call("upsertPlan", fields) { }

    suspend fun bootstrapProject(pricePaisa: Long): AppResult<Unit> =
        call("bootstrapProject", mapOf("pricePaisa" to pricePaisa)) { }

    suspend fun grantAdmin(targetUid: String, grant: Boolean): AppResult<Unit> =
        call("setAdminClaim", mapOf("targetUid" to targetUid, "grant" to grant)) { }

    private suspend fun <T> call(
        name: String,
        payload: Map<String, Any?>,
        mapper: (Map<*, *>) -> T
    ): AppResult<T> = runCatching {
        val result = functions.getHttpsCallable(name)
            .call(payload.filterValues { it != null })
            .await()
        mapper(result.data as? Map<*, *> ?: emptyMap<Any, Any>())
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })
}

/**
 * Administrative reads and the category and promotion writes.
 *
 * Categories and promotions are the only administrative collections a claimed administrator may
 * write directly; the rules scope that grant to an `admin == true` claim. Nothing here can change a
 * price, a subscription or a secure link.
 */
@Singleton
class AdminDataRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val functions: FirebaseFunctions
) {

    suspend fun items(itemType: ItemType, publishedOnly: Boolean = false, limit: Long = 50L): AppResult<List<AppItem>> =
        runCatching {
            var query: Query = firestore.collection(itemType.collection)
            if (publishedOnly) query = query.whereEqualTo("published", true)
            query.orderBy("updatedAt", Query.Direction.DESCENDING)
                .limit(limit)
                .get()
                .await()
                .documents
                .mapNotNull { Mappers.item(it, itemType) }
        }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun item(itemType: ItemType, itemId: String): AppResult<AppItem> = runCatching {
        Mappers.item(firestore.collection(itemType.collection).document(itemId).get().await(), itemType)
            ?: throw AppError.NotFound.toException()
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun categories(): AppResult<List<Category>> = runCatching {
        firestore.collection(FirestoreCollections.CATEGORIES)
            .orderBy("order", Query.Direction.ASCENDING)
            .limit(200)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.category(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun saveCategory(draft: CategoryDraft): AppResult<Unit> = runCatching {
        val collection = firestore.collection(FirestoreCollections.CATEGORIES)
        val reference = draft.categoryId.takeIf { it.isNotBlank() }
            ?.let { collection.document(it) }
            ?: collection.document()
        reference.set(
            draft.toMap() + mapOf(
                "categoryId" to reference.id,
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun deleteCategory(categoryId: String): AppResult<Unit> = runCatching {
        firestore.collection(FirestoreCollections.CATEGORIES).document(categoryId).delete().await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun promotions(): AppResult<List<Promotion>> = runCatching {
        firestore.collection(FirestoreCollections.PROMOTIONS)
            .orderBy("priority", Query.Direction.DESCENDING)
            .limit(100)
            .get()
            .await()
            .documents
            .mapNotNull { Mappers.promotion(it) }
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun savePromotion(draft: PromotionDraft): AppResult<Unit> = runCatching {
        val collection = firestore.collection(FirestoreCollections.PROMOTIONS)
        val reference = draft.promotionId.takeIf { it.isNotBlank() }
            ?.let { collection.document(it) }
            ?: collection.document()
        reference.set(
            draft.toMap() + mapOf(
                "promotionId" to reference.id,
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun deletePromotion(promotionId: String): AppResult<Unit> = runCatching {
        firestore.collection(FirestoreCollections.PROMOTIONS).document(promotionId).delete().await()
    }.fold({ AppResultKt.success(Unit) }, { AppResultKt.failure(AppError.from(it)) })

    /**
     * `secureLinks` is unreadable by every client, including this one. The stored Pro URL is
     * therefore fetched through a callable that re-checks the administrator claim on the server.
     */
    suspend fun proSecureLink(itemId: String): AppResult<String> = runCatching {
        val result = functions.getHttpsCallable("getProLinkForAdmin")
            .call(mapOf("itemId" to itemId))
            .await()
        val data = result.data as? Map<*, *> ?: emptyMap<Any, Any>()
        data["proDownloadUrl"]?.toString().orEmpty()
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })

    suspend fun user(userId: String): AppResult<DocumentSnapshot> = runCatching {
        firestore.collection(FirestoreCollections.USERS).document(userId).get().await()
    }.fold({ AppResultKt.success(it) }, { AppResultKt.failure(AppError.from(it)) })
}

/** A category form draft, kept separate from the Firestore model for two way binding. */
data class CategoryDraft(
    val categoryId: String = "",
    val name: String = "",
    val nameNe: String = "",
    val description: String = "",
    val iconUrl: String = "",
    val appliesTo: String = BOTH,
    val order: Int = 0,
    val enabled: Boolean = true
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "name" to name.trim(),
        "nameNe" to nameNe.trim(),
        "description" to description.trim(),
        "iconUrl" to iconUrl.trim(),
        "type" to appliesTo.takeIf { it != BOTH },
        "order" to order,
        "enabled" to enabled
    )

    companion object {
        const val BOTH = "BOTH"

        fun from(category: Category) = CategoryDraft(
            categoryId = category.categoryId,
            name = category.name,
            nameNe = category.nameNe,
            description = category.description,
            iconUrl = category.iconUrl,
            appliesTo = category.type?.name ?: BOTH,
            order = category.order,
            enabled = category.enabled
        )
    }
}

/** A promotion form draft. The banner is hidden whenever it is disabled or outside its window. */
data class PromotionDraft(
    val promotionId: String = "",
    val enabled: Boolean = false,
    val title: String = "",
    val shortDescription: String = "",
    val imageUrl: String = "",
    val buttonText: String = "",
    val buttonUrl: String = "",
    val startAtMillis: Long? = null,
    val endAtMillis: Long? = null,
    val priority: Int = 0
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "enabled" to enabled,
        "title" to title.trim(),
        "shortDescription" to shortDescription.trim(),
        "imageUrl" to imageUrl.trim(),
        "buttonText" to buttonText.trim(),
        "buttonUrl" to buttonUrl.trim(),
        "startAt" to startAtMillis?.let { java.util.Date(it) },
        "endAt" to endAtMillis?.let { java.util.Date(it) },
        "priority" to priority
    )

    companion object {
        fun from(promotion: Promotion) = PromotionDraft(
            promotionId = promotion.promotionId,
            enabled = promotion.enabled,
            title = promotion.title,
            shortDescription = promotion.shortDescription,
            imageUrl = promotion.imageUrl,
            buttonText = promotion.buttonText,
            buttonUrl = promotion.buttonUrl,
            startAtMillis = promotion.startAt?.toDate()?.time,
            endAtMillis = promotion.endAt?.toDate()?.time,
            priority = promotion.priority
        )
    }
}

/** The listing editor draft with exactly the fields an administrator may set. */
data class ItemDraft(
    val itemId: String = "",
    val type: ItemType = ItemType.APP,
    val name: String = "",
    val developerName: String = "",
    val iconUrl: String = "",
    val screenshots: String = "",
    val description: String = "",
    val categoryId: String = "",
    val categoryName: String = "",
    val version: String = "",
    val fileSize: String = "",
    val minAndroidVersion: String = "",
    val whatsNew: String = "",
    val freeEnabled: Boolean = false,
    val freeDownloadUrl: String = "",
    val proEnabled: Boolean = false,
    val proDownloadUrl: String = "",
    val featured: Boolean = false,
    val popular: Boolean = false,
    val isNew: Boolean = false,
    val published: Boolean = false
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "itemId" to itemId.takeIf { it.isNotBlank() },
        "name" to name.trim(),
        "developerName" to developerName.trim(),
        "iconUrl" to iconUrl.trim(),
        "screenshots" to screenshots.split('\n').map { it.trim() }.filter { it.isNotEmpty() },
        "description" to description.trim(),
        "categoryId" to categoryId.trim(),
        "categoryName" to categoryName.trim(),
        "version" to version.trim(),
        "fileSize" to fileSize.trim(),
        "minAndroidVersion" to minAndroidVersion.trim(),
        "whatsNew" to whatsNew.trim(),
        "freeEnabled" to freeEnabled,
        "freeDownloadUrl" to freeDownloadUrl.trim(),
        "proEnabled" to proEnabled,
        "proDownloadUrl" to proDownloadUrl.trim(),
        "featured" to featured,
        "popular" to popular,
        "isNew" to isNew,
        "published" to published
    )

    companion object {
        fun from(item: AppItem, proUrl: String = "") = ItemDraft(
            itemId = item.itemId,
            type = item.type,
            name = item.name,
            developerName = item.developerName,
            iconUrl = item.iconUrl,
            screenshots = item.screenshots.joinToString("\n"),
            description = item.description,
            categoryId = item.categoryId,
            categoryName = item.categoryName,
            version = item.version,
            fileSize = item.fileSize,
            minAndroidVersion = item.minAndroidVersion,
            whatsNew = item.whatsNew,
            freeEnabled = item.freeEnabled,
            freeDownloadUrl = item.freeDownloadUrl,
            proEnabled = item.proEnabled,
            proDownloadUrl = proUrl,
            featured = item.featured,
            popular = item.popular,
            isNew = item.isNew,
            published = item.published
        )
    }
}
