# Architecture

## Modules

```
core/           Android library. Shared by both applications.
  model/        Firestore document types and enums
  data/         FirestoreRefs, Mappers, repositories
  domain/       DownloadAccessResolver, PricingCalculator, SubscriptionEvaluator, SearchQuery
  ui/           theme, common states, reusable components (DownloadSection, ItemCard, ...)
  util/         AppResult, AppError, LinkOpener, UrlValidator, Formatters, ServerClock
  di/           Hilt modules for Firebase singletons
app-user/       The marketplace application.
app-admin/      The administration application.
firebase/       Rules, indexes and Cloud Functions.
```

The two applications share `core` so that the download decision, the price arithmetic and the
subscription evaluation exist once. `app-user` and `app-admin` do not depend on each other, and
neither contains payment or authorisation logic that the other would duplicate.

## Layers

- **UI**: Jetpack Compose screens and `ViewModel`s. A `ViewModel` exposes one immutable state object
  through `StateFlow` and receives user intents as function calls. Screens render state and never
  call Firestore directly.
- **Repository**: `core` repositories wrap Firestore and Cloud Functions, convert every outcome into
  `AppResult<T>` and every exception into an `AppError`. A repository is the only place that knows a
  collection name or a callable name.
- **Domain**: pure Kotlin, no Android or Firebase types except the document models. This is where
  the commercial rules live and where they are unit tested.
- **Backend**: Cloud Functions. This is the only writer for plans, subscriptions, orders, counters
  and `secureLinks`, and the only place that talks to a payment provider.

## Data flow for a download tap

```
User taps FREE DOWNLOAD
  -> ItemDetailViewModel
  -> PaymentRepository.trackFreeDownload(itemType, itemId)      callable
  -> backend loads the listing, checks published and freeEnabled,
     validates the URL, records a click, increments counters
  -> backend returns the stored URL unchanged
  -> LinkOpener opens it with ACTION_VIEW
```

```
User taps PRO DOWNLOAD
  -> ItemDetailViewModel
  -> PaymentRepository.getProDownloadLink(itemType, itemId)     callable
  -> backend loads userSubscriptions/{uid}, compares expiresAt with the server clock
  -> if inactive: returns a message, no URL
  -> if active: loads secureLinks/{itemId}, records the click, returns the URL
  -> LinkOpener opens it with ACTION_VIEW
```

The Pro URL is absent from the listing document. A client reading `apps/` or `games/` cannot obtain
it, because it is not there.

## Data flow for a purchase

```
ProScreen shows the quote from getPlanQuote (or the cached plan document)
User taps Pay with Khalti / eSewa
  -> PaymentRepository.createProOrder(planId, method)           callable
  -> backend prices from plans/{planId}, writes orders/{orderId} as PENDING,
     calls the provider, returns a payment URL (Khalti) or a signed form (eSewa)
  -> PaymentWebActivity loads the provider page
Provider returns to the app
  -> PaymentRepository.verifyKhalti / verifyEsewa               callable
  -> backend queries the provider, compares the paid amount with orders/{orderId}.amountPaisa
  -> on success the backend writes subscriptions/{id} and userSubscriptions/{uid},
     marks the order ACTIVE and updates the counters
  -> SessionViewModel refreshes and the UI reports PRO ACTIVE
```

No path in the client sets `status` to `ACTIVE`.

## Offline and performance

- Firestore offline persistence is enabled with an unlimited cache, so a cold start paints the
  catalogue from disk before the network answers.
- The home screen issues several small paged queries rather than one large read.
- Listing documents carry `iconUrl` only; screenshots load lazily when the detail screen opens.
- Images are loaded with Coil, which caches decoded bitmaps and supports thumbnails.
- Every catalogue query is paged with a limit and a cursor. No screen loads a whole collection.
- `searchKeywords` and `nameLower` are denormalised on write so search uses indexed prefix ranges
  instead of client side filtering.

## Threading and lifecycle

Repositories are `suspend` and dispatch through `kotlinx-coroutines-play-services`. Firestore
listeners are registered on `Dispatchers.Default` and collected with `collectAsStateWithLifecycle`,
so a listener stops with the screen. View models cancel their own scopes when cleared.

## Error handling

Every repository returns `AppResult`. `AppError` maps Firebase exceptions to a stable, user facing
message: no internet, timeout, permission denied, not found, invalid URL, payment failure, payment
pending, verification failure, expired subscription, unauthorised admin and a generic server error.
Technical detail is kept for logs and is never shown to the user.

## Administrators

The admin app signs in with the same Firebase Authentication project, then reads the `admin` custom
claim from the ID token. The claim is minted by `setAdminClaim` and enforced by Firestore rules and
by `requireAdmin` in every administrative callable. The app also refuses to open the dashboard when
the claim is absent, but that check is a convenience: the server is the authority.
