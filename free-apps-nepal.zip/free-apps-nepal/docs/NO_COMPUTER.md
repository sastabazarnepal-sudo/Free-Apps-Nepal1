# Sirf mobile se — poora rasta (computer nahi chahiye)

Ye guide us bande ke liye hai jiske paas laptop/PC nahi hai, sirf Android phone hai.

## Pehle ek zaroori sach

`firebase deploy` aur `gradlew assembleDebug` jaise command **phone se nahi chalti**.
Kyunki:

- Cloud Functions deploy karne ke liye Node.js + Firebase CLI chahiye (phone me nahi hota)
- APK build karne ke liye Android SDK + JDK chahiye (phone me nahi hota)

Lekin ghabrane ki baat nahi — **do raaste hain**, dono mobile se chal jaate hain:

| Kaam | Mobile se kaise |
| --- | --- |
| **APK build karna** | GitHub Actions (free, browser se) |
| **Rules deploy karna** | Firebase Console me **copy-paste** (paste button kaam karta hai) |
| **Admin banane** | Firebase Console me **ek chhota code** (console me hi chalta hai) |
| **Code likhna/change karna** | GitHub web editor (ya Claude/OpenHands mobile se) |

---

## Part 1 — Rules deploy karo (Firebase Console se, paste karke)

Command nahi, bas **paste** karna hai.

1. Phone browser me `console.firebase.google.com` kholo
2. Apna project `Free Apps Nepal` kholo
3. Left menu → **Firestore Database** → upar **Rules** tab
4. Ab is repo se `firebase/firestore.rules` file ka **poora content** copy karo
   - GitHub app me file kholo → pencil/edit → "Select all" → copy
5. Console ke Rules editor me **jo likha hai wo poora delete karo** (Ctrl+A / select all → delete)
6. Tumhara copied content **paste** karo
7. **Publish** button dabao
8. Green tick / "Rules published" aaya = **ho gaya** ✅

Firebase Storage ki zaroorat **nahi** hai, isliye Storage ka step chhod do. Icon aur
screenshots admin app me URL ke roop me daale jaate hain, to images free image host
(jaise postimages.org) se aa sakti hain. Isse Blaze plan bhi bach jaata hai.

### Indexes (bahut zaroori — warna home screen error dega)

Indexes paste nahi hote, unhe **console me banana padta hai**, par sirf 3–4 minute:

1. Firestore Database → **Indexes** tab
2. **Create index** dabao
3. Har index ke liye collection aur fields select karo. Hamare app ko ye 4 chahiye:

   **Index 1** — Apps, latest:
   - Collection ID: `apps`
   - Fields: `published` (Ascending), `createdAt` (Descending)
   - Query scope: Collection

   **Index 2** — Games, latest:
   - Collection ID: `games`
   - Fields: `published` (Ascending), `createdAt` (Descending)

   **Index 3** — Apps, popular:
   - Collection ID: `apps`
   - Fields: `published` (Ascending), `viewCount` (Descending)

   **Index 4** — Games, popular:
   - Collection ID: `games`
   - Fields: `published` (Ascending), `viewCount` (Descending)

4. **Create** dabao. Status "Building" se "Enabled" hone me 1–5 minute.

> **Trick:** jab app chalakar home screen kholo, aur console pe error aaye, to Firebase khud
> terminal me ek **link** deta hai jo index khud bana deta hai. Us link pe tap karo → Create → done.
> Yani tumhe manually dhoondhna bhi nahi padta.

---

## Part 2 — Pehla admin banao (Firebase Console se)

`tools/grant-admin.js` script computer ke liye hai. Phone me iske liye ek chhota jugaad hai.

### Tarika: Cloud Shell (Google ka free online terminal)

Google Cloud Shell ek **browser me chalne wala Linux terminal** hai — mobile browser me bhi kaam karta hai! Card nahi chahiye.

1. Phone browser me kholo: `shell.cloud.google.com`
2. Google account se login karo
3. Ek terminal khulega (online, tumhare phone me nahi chal raha — Google ke server pe)

Ab is shell me Firebase Admin SDK se claim lagao:

```
# apna project id daalo
gcloud config set project free-apps-nepal

# firebase-admin install karo
mkdir -p ~/fan && cd ~/fan && npm install firebase-admin

# claim lagao (email apna daalo)
node -e "
const admin=require('firebase-admin');
admin.initializeApp({projectId:'free-apps-nepal'});
(async()=>{
  const u=await admin.auth().getUserByEmail('tumhara@email.com');
  await admin.auth().setCustomUserClaims(u.uid,{admin:true,role:'admin'});
  await admin.firestore().collection('users').doc(u.uid).set({admin:true},{merge:true});
  console.log('admin granted for',u.email,u.uid);
})();
"
```

Ye Cloud Shell me chalta hai kyunki wahan Google ka service access already ho jaata hai.
`admin granted for ...` aaya = **ho gaya** ✅

> **Agar ye permission error de:** to Console → Project settings → Service accounts →
> "Generate new private key" se key download karo, Cloud Shell me upload karo (menu me
> "Upload" hota hai), phir `GOOGLE_APPLICATION_CREDENTIALS=<file> node -e "..."` chalao.

---

## Part 3 — APK build karo (GitHub se, mobile pe)

Ye **asli rasta** hai mobile ke liye. GitHub tumhare liye APK banayega, tum download kar logi.

### Ek baar ka setup

1. Phone me browser → `github.com` → login
2. Tumhara repo kholo: `github.com/sastabazarnepal-sudo/free-apps-nepal`
3. **Settings** → **Secrets and variables** → **Actions**
4. **New repository secret** dabao, do secrets banao:

   | Name | Value |
   | --- | --- |
   | `GOOGLE_SERVICES_JSON_USER` | `app-user/google-services.json` ka poora content (jaise hai waise) |
   | `GOOGLE_SERVICES_JSON_ADMIN` | `app-admin/google-services.json` ka poora content |

   Secret daalne ke liye file ka **poora text** copy karke paste karo. Ye safe hai — secret
   encrypted rehta hai aur logs me nahi dikhta.

### APK banao

1. Repo → **Actions** tab
2. Left me **"Build APKs"** select karo
3. **Run workflow** button → **Run workflow** dabao
4. 3–6 minute wait karo (page refresh karte raho)
5. Green tick ✅ aaya = build ho gaya
6. Us run pe tap karo → neeche **Artifacts** section
7. **app-user-debug** download karo → ek zip milega jisme `app-user-debug.apk` hai
8. Wahi **app-admin-debug** ke liye

### Phone me install karo

1. Download hui zip ko Files app se **extract** karo
2. APK file pe tap karo
3. "Install unknown apps" **Allow** karo
4. **Install** dabao

Done — app khul jayega.

---

## Part 4 — Code change karna ho to (mobile se)

GitHub ki website phone pe chhoti lagti hai, par kaam karti hai:

1. Repo me file kholo
2. Upar **pencil ✏️** icon dabao
3. Edit karo
4. Neeche **Commit changes** → commit message likho → **Commit**
5. Push hone par **Actions khud APK bana dega** — dobara "Run workflow" ki zaroorat nahi

Yani: **edit karo → 5 min wait → nayi APK.** Bilkul mobile se.

---

## Ek nazar me — mobile ka poora kaam

```
1. Console -> Firestore -> Rules -> paste -> Publish        (rules)
2. Console -> Firestore -> Indexes -> index banao            (search)
3. Authentication -> Email/Password on + admin user banao    (login)
4. Cloud Shell -> chhota node code chalakar admin banao      (admin claim)
5. GitHub -> Settings -> 2 secrets daalo                     (ek baar)
6. GitHub -> Actions -> Run workflow                         (APK)
7. Artifact download -> extract -> install                    (phone me)
```

Koi bhi step pe atak jao, wahi screenshot bhej do — main bata dunga kahan click karna hai.
