# Data model

Prices are stored in paisa (1 NPR = 100 paisa) as integers, so no monetary value is ever held in a
floating point type. All dates are Firestore timestamps written from the server clock.

## users/{userId}

| Field | Type | Notes |
| --- | --- | --- |
| userId | string | Matches the Auth uid |
| displayName | string | User editable |
| email | string | |
| photoUrl | string | |
| admin | bool | Set only by the backend when the claim is granted |
| fcmTokens | array | Device tokens for notifications |
| createdAt, updatedAt, lastLoginAt | timestamp | |

A client may update only `displayName`, `photoUrl`, `fcmTokens`, `lastTokenAt`, `updatedAt` and
`lastLoginAt` on its own document.

## apps/{appId} and games/{gameId}

Both collections share one shape. `type` is `APP` or `GAME`.

| Field | Type | Public | Notes |
| --- | --- | --- | --- |
| itemId | string | yes | Document id |
| type | string | yes | `APP` or `GAME` |
| name | string | yes | |
| nameLower | string | yes | Derived, used by search |
| developerName | string | yes | |
| developerNameLower | string | yes | Derived |
| iconUrl | string | yes | Storage URL |
| screenshots | array | yes | Storage URLs |
| description | string | yes | |
| categoryId | string | yes | |
| categoryName | string | yes | Denormalised for display |
| version | string | yes | |
| fileSize | string | yes | Display string, e.g. `18 MB` |
| minAndroidVersion | string | yes | e.g. `6.0` |
| whatsNew | string | yes | |
| lastUpdated | timestamp | yes | |
| freeEnabled | bool | yes | |
| freeDownloadUrl | string | yes | Admin configured, opened verbatim |
| proEnabled | bool | yes | The Pro URL is not in this document |
| featured, popular, isNew, published | bool | yes | Badge and visibility flags |
| viewCount | number | yes | Incremented by the backend |
| freeDownloadClickCount | number | yes | Incremented by the backend |
| proDownloadClickCount | number | yes | Incremented by the backend |
| ratingSum, ratingCount, reviewCount | number | yes | Maintained by review triggers |
| searchKeywords | array | yes | Derived prefix tokens |
| createdAt, updatedAt | timestamp | yes | |

**The Pro download URL is not stored here.** It lives in `secureLinks/{itemId}`.

## secureLinks/{itemId}

| Field | Type | Notes |
| --- | --- | --- |
| itemId | string | |
| proDownloadUrl | string | Admin configured |
| updatedBy | string | Admin uid |
| updatedAt | timestamp | |

Read and write are denied to every client by security rules. The only path to the value is the
`getProDownloadLink` callable.

## categories/{categoryId}

| Field | Type | Notes |
| --- | --- | --- |
| categoryId | string | Immutable |
| name | string | |
| nameLower | string | Derived |
| iconUrl | string | |
| order | number | Display order |
| enabled | bool | Hidden from browse when false |
| createdAt, updatedAt | timestamp | |

## plans/{planId}

One document, `pro_monthly` by default.

| Field | Type | Notes |
| --- | --- | --- |
| planId | string | |
| name | string | |
| description | string | |
| currency | string | `NPR` |
| pricePaisa | number | Base monthly price |
| durationDays | number | 30 by default |
| enabled | bool | |
| benefits | array | Shown on the Pro screen |
| discountEnabled | bool | |
| discountPercentage | number | Applied only inside the window |
| discountStartAt, discountEndAt | timestamp | Open ended when absent |
| updatedBy | string | |
| createdAt, updatedAt | timestamp | |

## subscriptions/{subscriptionId}

Written only by the backend, readable by the owner and by administrators.

| Field | Type | Notes |
| --- | --- | --- |
| subscriptionId | string | |
| userId | string | |
| planId, planName | string | Snapshotted at purchase |
| originalPricePaisa | number | Before discount |
| discountPercentage | number | Applied at purchase |
| finalPricePaidPaisa | number | Verified provider amount |
| currency | string | |
| paymentMethod | string | `KHALTI` or `ESEWA` |
| transactionId | string | Provider transaction |
| orderId | string | |
| status | string | `PENDING`, `ACTIVE`, `EXPIRED`, `FAILED`, `CANCELLED`, `REFUNDED` |
| startAt, expiresAt | timestamp | Server clock |
| cancelledAt, refundedAt | timestamp | |
| verifiedBy | string | |
| createdAt, updatedAt | timestamp | |

## userSubscriptions/{userId}

A denormalised snapshot so the client needs one read.

| Field | Type | Notes |
| --- | --- | --- |
| userId | string | |
| subscriptionId | string | |
| planId | string | |
| status | string | |
| active | bool | |
| paymentMethod | string | |
| startAt, expiresAt | timestamp | |
| serverTimeMillis | number | Anchors the clock-skew correction |
| updatedAt | timestamp | |

## orders/{orderId}

| Field | Type | Notes |
| --- | --- | --- |
| orderId | string | |
| userId | string | |
| planId | string | |
| paymentMethod | string | |
| originalPricePaisa | number | |
| discountPercentage | number | |
| amountPaisa | number | Server computed charge |
| currency | string | |
| status | string | Same status set as subscriptions |
| providerToken | string | Khalti pidx |
| providerTransactionId | string | |
| providerReferenceId | string | |
| failureReason | string | Internal only |
| subscriptionId | string | Set when activated |
| expiresAt | number | Set when activated |
| createdAt, updatedAt | timestamp | |

## {apps|games}/{itemId}/reviews/{reviewId}

| Field | Type | Notes |
| --- | --- | --- |
| reviewId | string | Typically the author's uid, one review per user per listing |
| itemId | string | |
| itemType | string | |
| userId | string | |
| userName, userPhotoUrl | string | |
| rating | number | 1 to 5 |
| text | string | |
| hidden | bool | Moderation flag, admin only |
| createdAt, updatedAt | timestamp | |

A user may create, edit and delete only their own review. An administrator may only toggle `hidden`.

## favorites/{userId}/items/{itemId}

| Field | Type | Notes |
| --- | --- | --- |
| itemId | string | |
| itemType | string | |
| name, iconUrl | string | Denormalised for the list |
| addedAt | timestamp | |

Scoped to the owner by the rules, so no other user can read or write it.

## promotions/{promotionId}

| Field | Type | Notes |
| --- | --- | --- |
| promotionId | string | |
| enabled | bool | Master switch |
| imageUrl | string | |
| title, description | string | |
| buttonText, buttonUrl | string | |
| startAt, endAt | timestamp | Window evaluated against the server clock |
| priority | number | Highest active promotion wins |
| createdAt, updatedAt | timestamp | |

The home screen renders a promotion only when `enabled` is true and the server time is inside the
window.

## settings/{settingId}

- `settings/app`: app name, support email and phone, about text, privacy and terms URLs, maintenance
  mode and message, force update flag, minimum version code, update URL, `proPlanEnabled`.
- `settings/counters`: total apps, total games, total users, page views, free and Pro download
  clicks, active Pro subscribers, subscription purchases, pending payments, revenue in paisa.
- `settings/serverTime`: the last published trusted timestamp.
- `settings/platform`: reserved for future platform switches.

## statistics/{yyyy-MM-dd}

Daily rollups: page views, free download clicks, Pro download clicks, new users, subscription
purchases, revenue. Aggregates are readable by clients; the raw events are not.

## downloadEvents/{eventId}

Not readable by clients because it carries a user id. One document per observed download click, with
`kind` `FREE` or `PRO`. This records the click only, never a completed transfer.

## adminTasks/{taskId}

Administrator visible bookkeeping documents, used to record deploy and maintenance actions.
