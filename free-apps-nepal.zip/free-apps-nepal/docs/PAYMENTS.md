# Payments

Pro is a single monthly subscription. Khalti and eSewa are the two supported providers. This
document describes how a purchase is created, verified and closed, and what the client is and is not
allowed to decide.

## Principles

1. The client never sends an amount. `createProOrder` receives only a plan id and a payment method.
2. The amount is computed from `plans/{planId}` on the server, applying the discount only if the
   server clock is inside the discount window.
3. The client never declares a payment successful. A subscription becomes active only after the
   backend has queried the provider and compared the reported amount with the stored order amount.
4. Provider credentials are Cloud Functions secrets. They are not present anywhere in either Android
   app, and no client configuration point accepts them.
5. An order records both the original price and the discount that was applied, so a later price
   change does not rewrite history.

## Order lifecycle

```
createProOrder        orders/{orderId}.status = PENDING
provider initiated    providerToken / providerTransactionId stored
provider returns      verify<Provider>Payment
  COMPLETED           subscriptions/{id} + userSubscriptions/{uid} written, order ACTIVE
  PENDING             order stays PENDING, the client may retry verification
  FAILED/CANCELED     order closed, no subscription written
  REFUNDED            order and subscription marked REFUNDED
```

The subscription document carries `originalPricePaisa`, `discountPercentage`, `finalPricePaidPaisa`,
the provider `transactionId`, the `orderId`, `startAt` and `expiresAt`. Both timestamps are written
from the server clock. `userSubscriptions/{uid}` is a denormalised snapshot holding `active`,
`status`, `expiresAt` and `serverTimeMillis`, which the client uses to render Pro state and to apply
a clock-skew correction.

## Khalti

Khalti ePayment is a two step flow: initiate, then verify.

1. `createProOrder` calls `POST {KHALTI_BASE_URL}/epayment/initiate/` with the amount in paisa, the
   order id as `purchase_order_id`, and a return URL. The returned `pidx` and `payment_url` are
   stored on the order and returned to the client.
2. The app opens `payment_url` in a WebView.
3. On the return redirect the app calls `verifyKhaltiPayment` with the order id.
4. The function calls `POST {KHALTI_BASE_URL}/epayment/lookup/` with the `pidx` **read from the
   order**, never from the request, so a caller cannot point the lookup at another user's payment.
5. `status = COMPLETED` activates the subscription. `PENDING` or `INITIATED` leaves it pending.
   `REFUNDED`, `USER CANCELED` and any other status close the order.

Secrets: `KHALTI_SECRET_KEY`, `KHALTI_BASE_URL`.

## eSewa

eSewa ePay v2 is a signed form POST followed by a status confirmation.

1. `createProOrder` builds the form fields. `signed_field_names` is
   `total_amount,transaction_uuid,product_code`, and `signature` is the base64 HMAC-SHA256 of the
   concatenated `name=value` pairs keyed by the merchant secret. The client posts the form.
2. eSewa redirects to the success URL with a base64 `data` parameter.
3. The app calls `verifyEsewaPayment` with the order id and the encoded payload.
4. Two independent checks run. The redirect signature is recomputed and compared in constant time,
   which proves the payload came from eSewa and was not altered. Then the transaction is confirmed
   against `{ESEWA_STATUS_URL}/api/epay/transaction/status/`.
5. Only when both checks pass and the reported amount matches the order amount is the subscription
   activated.

Secrets: `ESEWA_SECRET_KEY`, `ESEWA_PRODUCT_CODE`, `ESEWA_BASE_URL`, `ESEWA_STATUS_URL`.

## Amount checking

`finalisePaidOrder` is the single place that closes a paid order. It:

- loads the order and confirms it belongs to the caller
- compares the provider reported amount with `orders/{orderId}.amountPaisa`, rejecting a shortfall
- is idempotent: a second verification of an already active order returns the existing subscription
  instead of creating a second one

The signature check for eSewa runs before the API check, but the API check is the authoritative one.
Either provider path ends in the same amount comparison.

## Failure handling in the app

| Situation | What the user sees |
| --- | --- |
| No connection | A network message and a Retry action |
| Provider unreachable | "still pending verification", communicated as `PaymentPending` |
| Payment failed or cancelled | "the payment could not be completed", communicated as `PaymentFailed` |
| Verification mismatch | A message advising them to contact support with the transaction id |
| Pro expired after a previous purchase | "renew Pro", not "get Pro" |

The payment screen never reports success from a local signal. The WebView shows the provider page;
the app waits for the verification callable before changing the visible Pro state.

## Pending payments and reconciliation

`settings/counters.pendingPayments` is incremented when an order is created and decremented when it
closes. To reconcile a stuck order, call the verify function for that order: it re-queries the
provider and either activates or closes the order. This is safe to run repeatedly.

## Testing without real money

Use the Firebase Functions emulator with a provider sandbox. Point `KHALTI_BASE_URL`,
`ESEWA_BASE_URL` and `ESEWA_STATUS_URL` at the sandbox hosts and set sandbox credentials. The
verification logic is unchanged: it still queries the configured host and still compares the amount.
Never point the production URLs at a sandbox, and never add a client side "activate Pro" path for
testing. There is deliberately no such path.

## What is not claimed

Activation proves that the provider reported a completed payment of at least the expected amount for
this order. It does not by itself perform a settlement or bank reconciliation; that remains a finance
concern, using `orders` and `subscriptions` as the ledger.
