# Administration guide

The admin app (`Free Apps Nepal Admin`) manages the catalogue that the user app renders. Every
change you make in Firestore is live: users see updated names, prices, URLs and banners without
installing a new version of the user app.

## Signing in

Sign in with an account that carries the `admin` custom claim. The app reads the claim from the
fresh ID token and refuses to open the console without it. If you sign in on an account you have
just promoted, sign out and in again so the token is refreshed.

See `SETUP.md` for how the first administrator claims the role.

## Dashboard

The dashboard reads the `settings/counters` document as stored. It reports:

- Total apps and total games
- Total users
- Page views
- Free download clicks and Pro download clicks
- Active Pro subscribers
- Subscription purchases
- Pending payments
- Recorded revenue, summed from successful orders only
- The currently active promotion
- The most recent apps and games

Nothing on this screen is estimated. If a counter is zero it is because the corresponding event has
not been recorded, not because the value was hidden.

## Managing apps and games

Each listing has one of two types, `APP` or `GAME`, and is stored in `apps/` or `games/`
respectively. The editor covers:

- Name and developer
- Icon and screenshots (uploaded to Storage under `catalog/`)
- Description, category, version, file size, minimum Android version and what's new
- Free version on/off and the Free download URL
- Pro version on/off and the Pro download URL
- Featured, popular, new and published flags

### The Free URL

This is the link every user receives, with or without a subscription. It may be a monetised page
such as a MediaFire or advertising supported download page. The user app opens exactly the URL you
enter and does nothing to its contents, so any advertising or monetisation on that page is handled
by the external service under its own terms.

### The Pro URL

This link is given only to users whose monthly Pro subscription is active, and it requires no
advertisement and no further payment. The URL is stored separately from the public listing, in
`secureLinks/{itemId}`, and is released by a Cloud Function that re-verifies the subscription. It is
not readable by any client, so it never appears in a catalogue query.

Keep in mind that once a subscriber has the URL they have seen it, and a direct download link cannot
be made permanently secret. Treat the Pro URL as a convenience for paying users rather than as
confidential data, and prefer a link you are comfortable being shared if that matters to you.

### Both, one, or neither version

- Free on, Pro off: users see Free Download. No Pro button is shown.
- Free off, Pro on: the listing is still visible to everyone. Users without a subscription see a
  locked Pro button; active subscribers see it unlocked.
- Both on: both buttons appear. Free is available to everyone; Pro is unlocked only for subscribers.
- Neither on: no download actions appear. Publish a listing only once at least one version is set.

## Categories

Categories are dynamic. Add, rename, reorder or disable them at any time. A disabled category is
hidden from the browse screen but existing listings keep their reference so nothing is lost if you
re-enable it.

## The Pro plan

The Pro plan is a single monthly subscription. Set:

- Plan name
- Monthly price in NPR
- Enabled or disabled
- Discount on/off, percentage, start date and end date

The user app displays the original price, the discount percentage and the final price, for example
`NPR 99/month`, `30% OFF`, `NPR 69.30/month`. The discount applies only between its start and end
dates and reverts automatically once the window passes. The amount charged is recomputed on the
server when an order is created, so a stale client cannot pay the wrong amount.

## Subscribers and payments

The subscribers screen lists subscription records with the user, status, payment method, transaction
id, order id, original amount, discount, final amount, start date and expiry date. Orders are listed
with their provider status. A pending order means the provider has not yet confirmed the payment.
Reconciliation of a pending order is done by calling the verify function for that order, which asks
the provider for the current status.

## Promotions

A promotion has an image, title, short description, button text, button URL, start date and end
date, plus an enabled flag. The user app draws the banner on the home screen only while the
promotion is enabled and the current server time is inside the window. When it is disabled or
expired the banner is removed entirely and no empty space is left behind.

## Reviews

The moderation screen shows user reviews across all listings. You can hide a review that breaks the
rules. You cannot edit a review's text or rating, and neither can any other user: a review belongs
to its author.

## Reviews of your own catalogue data

Before publishing, check that:

- The Free URL opens and matches the description.
- The Pro URL opens for a test subscriber.
- The icon and screenshots are the right ones.
- The version, file size and minimum Android version are accurate.
- The category exists and is enabled.
