# Setup

This document takes a fresh machine to a working pair of applications against your own Firebase
project.

## 1. Prerequisites

- JDK 17 or newer (JDK 21 is what the project is built and tested with)
- The Android SDK with platform 35 and build tools matching AGP 8.5.2
- Node.js 20 for the Cloud Functions
- The Firebase CLI: `npm install -g firebase-tools`

Create `local.properties` in the repository root with your SDK location:

```
sdk.dir=/path/to/Android/sdk
```

## 2. Create the Firebase project

1. Create a project in the Firebase console.
2. Add two Android apps to it, with these package names:
   - `np.freeappsnepal.user`
   - `np.freeappsnepal.admin`
3. Download `google-services.json` for each and place it in `app-user/` and `app-admin/`
   respectively. Both files are ignored by version control.
4. Enable Authentication with the Email/Password and Google providers.
5. Create the Firestore database and a Storage bucket.
6. In the project settings, open Cloud Messaging and note that no further setup is required.

The debug build type appends `.debug` to the application id. A `google-services.json` that only
contains the release package names will fail the `processDebugGoogleServices` task. Register the
debug package names as well, or build only the release variant.

## 3. Deploy the backend

```
cd firebase
firebase login
firebase use --add          # pick the project, alias it "default"
cd functions && npm install && cd ..
firebase deploy --only firestore:rules,firestore:indexes,storage,functions
```

Set the payment secrets before deploying functions, or the payment callables will fail to start:

```
firebase functions:secrets:set KHALTI_SECRET_KEY
firebase functions:secrets:set KHALTI_BASE_URL
firebase functions:secrets:set ESEWA_SECRET_KEY
firebase functions:secrets:set ESEWA_PRODUCT_CODE
firebase functions:secrets:set ESEWA_BASE_URL
firebase functions:secrets:set ESEWA_STATUS_URL
```

See `PAYMENTS.md` for the values each provider expects.

## 4. Create the first administrator

There is no hardcoded administrator password and no client editable allowlist. The admin claim is
minted by a Cloud Function and enforced by security rules.

1. Register an account in the user app, or create one directly in the Firebase console.
2. Ask the backend to grant the claim to that account. With the Functions emulator this is a call to
   `setAdminClaim`. From the Firebase console you can invoke the callable through the Functions
   "Testing" tab, passing `{ "targetUid": "<uid>", "grant": true }`.
3. The bootstrap rule: while no administrator exists, the first caller may claim the role. After
   that, only an existing administrator can grant or revoke it.
4. Sign out and in again so the client receives a fresh ID token containing the claim.

Then open the admin app and run `bootstrapProject` once (the dashboard offers this on a fresh
project). It creates the Pro plan document, the counters document and the public settings document.

## 5. App Check

Both apps install the Play Integrity provider in their `Application` class. Register the apps in
the Firebase console under App Check, and enable enforcement for Firestore, Storage and Functions
once you have verified that legitimate traffic passes. The debug build uses the App Check debug
provider, so register the debug token printed in logcat during development.

## 6. Build and run

```
./gradlew :app-user:assembleDebug :app-admin:assembleDebug
./gradlew :core:testDebugUnitTest
```

The APKs are written to `app-user/build/outputs/apk/debug/` and
`app-admin/build/outputs/apk/debug/`.

For a release build, configure a signing key in `app-user/build.gradle.kts` and
`app-admin/build.gradle.kts` and keep the keystore out of version control. Enable minification: the
ProGuard rules are already written to keep the model classes that Firestore maps reflectively.

## 7. Optional: remote configuration of the web client id

Google sign in needs an OAuth web client id. It is injected at build time so the repository is not
pinned to one Firebase project:

```
./gradlew :app-user:assembleRelease -Pfan.googleWebClientId=XXXX.apps.googleusercontent.com
```

The value is a public identifier, not a secret, but keeping it in the build invocation rather than
in the source keeps the project portable.
