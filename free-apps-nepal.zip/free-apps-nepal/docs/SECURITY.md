# Security

This document describes what the system protects, how, and where the guarantees stop. The explicit
limits matter: overstating them would be worse than the limits themselves.

## Trust boundaries

| Decision | Made by | Never made by |
| --- | --- | --- |
| Price and discount | Backend, from `plans/{planId}` | Client |
| Payment success | Khalti or eSewa, queried by the backend | Client |
| Subscription active | Backend, compared with the server clock | Client clock alone |
| Administrator role | Custom claim minted by a function | Client email check |
| Pro download URL | Backend, released per request | Public listing document |

## Firestore rules

- Listings (`apps`, `games`), plans, categories, promotions and public settings are world readable
  so the marketplace can be browsed, and are writable only by an administrator. Every write to a
  listing normally goes through `upsertItem`, which validates URLs and keeps counters intact.
- `secureLinks` is denied to every client, read and write.
- `subscriptions`, `userSubscriptions` and `orders` are readable by their owner and by an
  administrator, and writable by nobody from a client.
- Reviews are writable only by their author, and an administrator may change only the `hidden` flag.
- `favorites/{uid}/**` is scoped to its owner.
- `users/{uid}` accepts updates only to a small allowlist of profile fields, so a user cannot set
  `admin` or any counter on their own document.
- `downloadEvents` is not client readable because each document carries a user id.

Rules are the second line of defence behind the backend. Both would have to fail for a value such as
a price or a subscription status to be forged.

## Administrator authorisation

There is no hardcoded password and no client side allowlist. The `admin` custom claim is granted by
`setAdminClaim`, which requires an existing administrator once one exists. The bootstrap case, where
no administrator exists yet, lets the first caller claim the role; this is a one time state on a
fresh project, and the correct sequence is to claim it before announcing the app. Every
administrative callable calls `requireAdmin`, which checks the claim on the verified ID token, and
Firestore and Storage rules check the same claim.

A client that hides the console has not been authorised; the server has.

## Payment integrity

- The client sends no amount.
- `createProOrder` computes the charge from the plan document.
- Verification queries the provider and compares the reported amount with the stored order amount.
- eSewa responses are checked twice: the signature is recomputed in constant time, and the
  transaction is confirmed with the status API.
- Khalti verification uses the `pidx` stored on the order, not one supplied by the request, so a
  caller cannot verify someone else's payment.
- Activation is idempotent, so replaying a verification does not create duplicate subscriptions.
- Only `finalisePaidOrder` writes an active subscription.

## Provider secrets

`KHALTI_SECRET_KEY`, `KHALTI_BASE_URL`, `ESEWA_SECRET_KEY`, `ESEWA_PRODUCT_CODE`, `ESEWA_BASE_URL`
and `ESEWA_STATUS_URL` are Cloud Functions secrets managed by the Firebase CLI. They are decrypted
only in the function runtime. Neither Android app contains a payment secret, and neither app has a
configuration field that accepts one.

## Server time

Subscription and discount windows are evaluated against the server clock. `userSubscriptions/{uid}`
stores `serverTimeMillis` next to the expiry so the client can correct for a device clock that is
wrong or has been changed. `expireSubscriptions` runs on a schedule and flips lapsed subscriptions to
`EXPIRED` on the server, so state self-corrects even if a device never opens the app again.

## App Check

Both apps install the Play Integrity provider. App Check is a control against scripted abuse of
Firebase resources, not an authentication mechanism. Register the apps and enable enforcement for
Firestore, Storage and Functions once legitimate traffic is confirmed.

## Pro download links, and the honest limit

The Pro URL is stored in `secureLinks`, denied to clients, and released by `getProDownloadLink`
after re-verification. This prevents the application from being used to obtain a Pro link without an
active subscription, and keeps the URL out of catalogue queries.

It does not make the URL permanently secret. Once it has been shown to a legitimate subscriber, that
person has seen it and could pass it on. Any plain external URL behaves this way. The reasonable goal
is application and backend access control, and that is what is implemented. Treat the Pro URL as a
convenience for paying users rather than as confidential data.

## Download analytics honesty

A tap records that the configured URL was opened. The transfer is performed by an external service
and cannot be observed here, so the system tracks clicks, not completed downloads. No counter claims
that a file was installed or delivered.

## Reviews and social inputs

Rating is range checked, text is length limited, and a review is owned by its author by rule. An
administrator can hide a review but cannot rewrite it.

## Transport and storage

All traffic uses HTTPS, enforced by the network security configuration, which also disallows
cleartext. Firestore offline persistence stores the local cache in the app sandbox. Crash reporting
is enabled but never receives a payment secret, an ID token or a Pro URL.

## Error messages

Every failure is mapped to a fixed user facing string in `AppError`. Provider payloads, stack traces
and identifiers are retained for logs only and are not shown in the UI.

## Reporting a problem

If you believe you have found a security issue, contact the address in `settings/app.supportEmail`
rather than opening a public issue.
