# Step by step — setup, connect, build

Ye guide uske liye hai jo pehli baar Firebase project bana raha hai. Har step me likha hai
*kya karna hai*, *kahan click karna hai* aur *kaise pata chalega ki ho gaya*.

---

## Zaroori shabd jo baar baar aayenge

| Shabd | Matlab |
| --- | --- |
| **Firebase Console** | Website: console.firebase.google.com — yahan tum project banate ho |
| **google-services.json** | Ek chhoti file jo Firebase deta hai. Isme project id aur API key hoti hai |
| **Firestore** | Firebase ka database. Yahan apps, users, payment sab save hote hain |
| **Cloud Functions** | Firebase ka server code. Payment verify aur Pro link isi se milta hai |
| **Rules** | Security ki deewar. Kaun kya padh/likh sakta hai, ye decide karti hai |
| **Deploy** | Apna code Firebase ke server pe bhejna |
| **Terminal** | Command chalane ki black screen (Windows: PowerShell / Mac: Terminal) |

---

## Step 1 se 7 — jab tak ho gaye

Tumne bataya 1–7 ho gaye. Ye the: project banana, do Android apps add karna,
google-services.json download karna, Authentication on karna, Firestore banana.

Agar 1–7 me se koi shak hai, to console me ye dikhna chahiye:

- Project dashboard khulta ho
- Project Settings → General me 2 apps dikhein: `np.freeappsnepal.user` aur `np.freeappsnepal.admin`
- Authentication → Sign-in method me Email/Password **Enabled** likha ho
- Firestore Database me ek database bana ho (production mode theek hai, rules hum deploy karenge)

---

## Step 8 — Backend deploy (rules + indexes)

### Ye kyun chahiye?

`firebase/` folder me kuch files hain jo tumhare Firebase project me jaani chahiye:

```
firestore.rules          → kaun kya padh/likh sakta hai
firestore.indexes.json   → tez search ke liye indexes
functions/               → payment verify, Pro link, admin claim
```

Firebase Storage ki zaroorat **nahi** hai. Catalogue ke icon aur screenshots admin app me
URL ke roop me daale jaate hain, to images kisi bhi free image host se aa sakti hain.
Isliye Storage bucket banane ki aur Blaze plan lene ki zaroorat nahi.

Agar deploy nahi karoge:
- Database me default rules chalengi, jo ya to sab band kar deti hain ya bahut khuli hoti hain
- Tez search ke indexes nahi banenge, to home screen ke queries error denge

### Pehle Firebase CLI install karo (ek hi baar)

Firebase CLI = ek command-line tool jo tumhare computer se Firebase ko control karta hai.

**Windows (PowerShell):**
```
npm install -g firebase-tools
```

**Mac:** wahi command. Agar `npm` nahi mila to pehle Node.js install karo: nodejs.org se LTS version.

Check karo install hua:
```
firebase --version
```
Kuch number aaya (jaise `13.x.x`) to ho gaya.

### Ab deploy karo

Terminal kholo aur **project folder** me jao (jahan `firebase` folder dikhta hai):

```
cd path/to/project
```

Phir:

```
firebase login
```
Browser khulega → apna Google account jo Firebase project ka owner hai, usse login karo → Allow dabao.

```
cd firebase
firebase use --add
```
- Jo project list aaye usme **free-apps-nepal** (ya jo naam tumne rakha) select karo
- Alias poochhega → `default` likh do

Ab deploy:
```
firebase deploy --only firestore:rules,firestore:indexes
```

> **Note:** `functions` abhi deploy mat karo. Cloud Functions ko Blaze plan chahiye (card).
> Uske bina ye step fail hoga — aur ye normal hai. Rules aur indexes Spark (free) plan pe
> bhi deploy ho jaate hain. Functions ki jagah hamare paas Plan B hai (admin approve).

### Kaise pata chalega ki ho gaya?

Terminal me aisa likha aayega:
```
✔  Deploy complete!
```
Aur console → Firestore → Rules tab me tumhari nayi rules dikhengi.

---

## Step 9 — Pehla administrator banao

### Problem kya hai?

Admin app kholne ke liye account pe **admin** ka tick hona chahiye. Ye tick Firebase
custom claim se aata hai. Ye claim koi bhi client app khud nahi de sakti, warna koi bhi
apne aap ko admin bana leta.

Hum ise **ek chhoti script** se lagayenge jo tumhare computer se chalti hai.
Iske liye card ki zaroorat nahi — sirf ek service account key file.

### Service account key download karo

1. Firebase Console → gear icon **Project settings** → **Service accounts** tab
2. **Generate new private key** dabao → **Generate key**
3. Ek `.json` file download hogi (naam jaise `free-apps-nepal-firebase-adminsdk-xxxx.json`)

**Ye file asli secret hai.** Isse kisi ko mat do, git me mat daalo, chat me mat bhejo.
Isko safe folder me rakho (jaise Desktop pe).

### Script chalao

```
cd tools
npm install
GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account-key.json" node grant-admin.js you@example.com
```

Path apni file ka daalo, aur email ki jagah apna email jo admin app me login karoge.
Output me `admin: true` dikhe to ho gaya.

### Verify

Admin app kholo → login karo → Dashboard khul gaya to admin claim lag gaya.
Agar "You do not have admin access" dikhe, to claim nahi laga — script dobara chalao.

---

## google-services.json kaise daalein

### Kahan se aayi?

Jab tumne Firebase me Android app add kiya, Firebase ne ek file di hogi:
`google-services.json`. Agar download nahi ki, to console →
Project settings → General → tumhara app → **google-services.json** download karo.

**Do file chahiye** — ek user app ki, ek admin app ki. Dono alag hain kyunki
package name alag hai.

### Kahan rakhni hai — ye sabse zaroori baat hai

File **project ke root me nahi**, module folder me jaati hai:

```
project/
├── app-user/
│   └── google-services.json     ← user app ki file YAHAN
├── app-admin/
│   └── google-services.json     ← admin app ki file YAHAN
├── core/
├── build.gradle.kts
└── settings.gradle.kts
```

### Naam bilkul same hona chahiye

File ka naam **exactly** `google-services.json` hona chahiye. Agar download ke waqt naam
kuch aur hua (jaise `google-services (1).json`), to rename karo. Windows me extension
chhupa hota hai — dhyan rakho ki `google-services.json.txt` na ban jaye.
File Explorer → View → File name extensions ON karo.

### Kaunsa file kis folder me?

File kholo (Notepad se) aur dekho `package_name` kya likha hai:

- `"package_name": "np.freeappsnepal.user"` → ye `app-user/` me jaayegi
- `"package_name": "np.freeappsnepal.admin"` → ye `app-admin/` me jaayegi

### Sirf 2 apps add karo, chaar nahi

Debug build bhi **release ke package name hi** use karta hai, isliye Firebase me sirf do apps
register karni hain:

```
np.freeappsnepal.user      -> app-user/google-services.json
np.freeappsnepal.admin     -> app-admin/google-services.json
```

Debug aur release ka farak sirf Crashlytics reporting me hai, package name me nahi.

### Confirm karo ki file sahi jagah hai

Terminal me project folder se:
```
ls app-user/google-services.json app-admin/google-services.json
```
Dono naam dikhe to sahi jagah hain.

_(Windows PowerShell me: `dir app-user\google-services.json` )_

---

## Build kaise karein

### Build ka matlab kya hai?

"Build" = tumhare Kotlin/Compose code ko ek **APK file** me badalna, jo phone me install
hoti hai. Gradle naam ka tool ye kaam karta hai. Tumhe code samajhna nahi padta, bas
command chalani hai. Aur `gradlew` neeche `build/` folder me sab kuch khud bana leta hai.

### Pehle check karo ki sab theek hai

```
./gradlew :app-user:compileDebugKotlin
```

**Windows (PowerShell / CMD):**
```
gradlew.bat :app-user:compileDebugKotlin
```

`BUILD SUCCESSFUL` aaya — code theek hai aur Firebase file bhi sahi jagah hai.

### Ab APK banao (phone me daalne ke liye)

```
./gradlew :app-user:assembleDebug :app-admin:assembleDebug
```

Windows:
```
gradlew.bat :app-user:assembleDebug :app-admin:assembleDebug
```

Pehli baar 2–5 minute ya zyada lega, kyunki Gradle aur dependencies download hote hain.
Uske baad bahut tez.

### APK kahan bani?

```
app-user/build/outputs/apk/debug/app-user-debug.apk
app-admin/build/outputs/apk/debug/app-admin-debug.apk
```

Yahi 2 files phone me install karni hain. Phone me transfer karke tap karo aur
"Install from unknown sources" allow karo.

### Unit tests chalao (optional, par accha hai)

```
./gradlew :core:testDebugUnitTest
```
Ye download / free / Pro / expiry ka logic check karta hai. `BUILD SUCCESSFUL` aana chahiye.

### Release build (Play Store ke liye, baad me)

Play Store pe daalne ke liye release APK/AAB chahiye, jo signed hona chahiye:
```
./gradlew :app-user:assembleRelease
```
Iske liye ek signing key banani padegi aur `app-user/build.gradle.kts` me configure karni
padegi. Abhi debug build se test karo, release baad me.

### Agar error aaye

| Error | Matlab | Fix |
| --- | --- | --- |
| `SDK location not found` | Android SDK ka path nahi mila | `local.properties` me `sdk.dir=/path/to/Android/Sdk` likho |
| `No matching client found for package name` | `google-services.json` me wo package nahi | Firebase me `.debug` package add karo, nayi file download karo |
| `File google-services.json is missing` | File galat jagah hai | `app-user/` aur `app-admin/` me rakho |
| `JAVA_HOME is not set` | Java nahi mila | JDK 17 ya 21 install karo, `JAVA_HOME` set karo |
| `Unsupported class file major version` | Java purana hai | JDK 21 use karo |

### Gradle wrapper kya hai?

Command me `./gradlew` likha hai, `gradle` nahi. `gradlew` = Gradle Wrapper. Ye project ke
saath aata hai aur **khud sahi Gradle version download** kar leta hai (hamare case me 8.9).
Isliye Gradle alag se install karne ki zaroorat nahi — bas `gradlew` chalao.

---

## Poora order — ek nazar me

```
1.  Firebase project banao                              ✅ ho gaya
2.  2 Android apps add karo (user + admin)               ✅ ho gaya
3.  google-services.json download karo                   ✅ ho gaya
4.  Email/Password auth on karo                          ✅ ho gaya
5.  Firestore database banao                             ✅ ho gaya
6.  (jo bhi ho gaya)                                     ✅
7.  (jo bhi ho gaya)                                     ✅
8.  firebase login → firebase use --add                  ← AB YAHAN
    firebase deploy --only firestore:rules,...
9.  Service account key → tools/grant-admin.js           ← PHIR YAHAN
10. gradlew assembleDebug                                ← SABSE AAKHIR
```

## Yaad rakhne wali 3 baatein

1. **google-services.json module folder me jaati hai**, root me nahi
2. **`.debug` package bhi add karna hai**, warna debug build fail hoga
3. **`./gradlew` chalao** (Windows pe `gradlew.bat`), `gradle` nahi
