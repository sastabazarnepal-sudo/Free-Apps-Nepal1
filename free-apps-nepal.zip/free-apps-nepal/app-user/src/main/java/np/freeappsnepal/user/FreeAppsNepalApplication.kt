package np.freeappsnepal.user

import android.app.Application
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.crashlytics.FirebaseCrashlytics
import dagger.hilt.android.HiltAndroidApp
import np.freeappsnepal.core.BuildConfig

@HiltAndroidApp
class FreeAppsNepalApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // App Check attests that requests come from the genuine, unmodified application installed
        // by Play. It reduces abuse of Firestore, Functions and Storage quota without adding any
        // user visible behaviour.
        // Play Integrity only attests to a build installed by Play, so it fails outright on a
        // debug APK downloaded from CI. That would leave App Check unauthenticated in exactly the
        // build we are testing. The debug provider stands in during development; release keeps Play
        // Integrity. App Check enforcement should stay off until the release build is live.
        val appCheckProvider = if (BuildConfig.DEBUG) {
            DebugAppCheckProviderFactory.getInstance()
        } else {
            PlayIntegrityAppCheckProviderFactory.getInstance()
        }
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(appCheckProvider)

        // Crash reporting stays off in debug so an emulator session does not pollute the console.
        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(!BuildConfig.DEBUG)
    }
}
