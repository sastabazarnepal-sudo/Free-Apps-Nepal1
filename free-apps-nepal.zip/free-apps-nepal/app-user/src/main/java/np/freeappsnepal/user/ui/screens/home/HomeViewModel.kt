package np.freeappsnepal.user.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.CatalogRepository
import np.freeappsnepal.core.data.repo.NetworkMonitor
import np.freeappsnepal.core.data.repo.PromotionRepository
import np.freeappsnepal.core.data.repo.ServerClockRepository
import np.freeappsnepal.core.data.repo.SettingsRepository
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.Promotion
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject

/** The eleven Home sections plus the optional promotion banner. */
data class HomeUiState(
    val loading: Boolean = true,
    val refreshing: Boolean = false,
    val offline: Boolean = false,
    val errorMessage: String? = null,
    val promotion: Promotion? = null,
    val featuredApps: List<AppItem> = emptyList(),
    val latestApps: List<AppItem> = emptyList(),
    val popularApps: List<AppItem> = emptyList(),
    val featuredGames: List<AppItem> = emptyList(),
    val latestGames: List<AppItem> = emptyList(),
    val popularGames: List<AppItem> = emptyList(),
    val freeApps: List<AppItem> = emptyList(),
    val proApps: List<AppItem> = emptyList(),
    val freeGames: List<AppItem> = emptyList(),
    val proGames: List<AppItem> = emptyList(),
    val proUnavailable: Boolean = false
) {
    val isEmpty: Boolean
        get() = featuredApps.isEmpty() && latestApps.isEmpty() && latestGames.isEmpty() &&
            freeApps.isEmpty() && proApps.isEmpty() && freeGames.isEmpty() && proGames.isEmpty()
}

/**
 * Loads Home.
 *
 * Every section is a small, bounded query issued concurrently. Nothing loads the whole catalogue:
 * each section asks for a fixed number of documents ordered by an indexed field, so opening Home
 * costs a handful of cheap reads rather than a full collection scan. Pro sections are shown to
 * everyone, because Pro listings must never be hidden from a user without a subscription.
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val catalogRepository: CatalogRepository,
    private val promotionRepository: PromotionRepository,
    private val settingsRepository: SettingsRepository,
    private val serverClockRepository: ServerClockRepository,
    private val networkMonitor: NetworkMonitor
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    init {
        load(initial = true)
    }

    fun refresh() {
        load(initial = false)
    }

    private fun load(initial: Boolean) {
        viewModelScope.launch {
            _state.value = _state.value.copy(
                loading = initial,
                refreshing = !initial,
                offline = !networkMonitor.currentlyOnline(),
                errorMessage = null
            )

            val clock = serverClockRepository.serverClock()
            val serverNow = clock.now(System.currentTimeMillis())

            val settingsDeferred = async { settingsRepository.appSettings() }
            val promotionDeferred = async { promotionRepository.activePromotion(serverNow) }
            val featuredAppsDeferred = async { catalogRepository.flagged(ItemType.APP, SECTION_FEATURED) }
            val featuredGamesDeferred = async { catalogRepository.flagged(ItemType.GAME, SECTION_FEATURED) }
            val popularAppsDeferred = async { catalogRepository.flagged(ItemType.APP, SECTION_POPULAR) }
            val popularGamesDeferred = async { catalogRepository.flagged(ItemType.GAME, SECTION_POPULAR) }
            val latestAppsDeferred = async {
                catalogRepository.page(ItemType.APP, limit = SECTION_SIZE.toLong())
            }
            val latestGamesDeferred = async {
                catalogRepository.page(ItemType.GAME, limit = SECTION_SIZE.toLong())
            }
            val freeAppsDeferred = async {
                catalogRepository.byOffering(ItemType.APP, freeOnly = true, limit = SECTION_SIZE.toLong())
            }
            val proAppsDeferred = async {
                catalogRepository.byOffering(ItemType.APP, freeOnly = false, limit = SECTION_SIZE.toLong())
            }
            val freeGamesDeferred = async {
                catalogRepository.byOffering(ItemType.GAME, freeOnly = true, limit = SECTION_SIZE.toLong())
            }
            val proGamesDeferred = async {
                catalogRepository.byOffering(ItemType.GAME, freeOnly = false, limit = SECTION_SIZE.toLong())
            }

            awaitAll(
                settingsDeferred,
                promotionDeferred,
                featuredAppsDeferred,
                featuredGamesDeferred,
                popularAppsDeferred,
                popularGamesDeferred,
                latestAppsDeferred,
                latestGamesDeferred,
                freeAppsDeferred,
                proAppsDeferred,
                freeGamesDeferred,
                proGamesDeferred
            )

            val settings = settingsDeferred.await().getOrNull()
            val promotion = promotionDeferred.await().getOrNull()
            val proPlanDisabled = settings != null && !settings.proPlanEnabled

            val latestApps = latestAppsDeferred.await().getOrNull()
            val latestGames = latestGamesDeferred.await().getOrNull()

            val failureMessage = listOf(
                featuredAppsDeferred,
                featuredGamesDeferred,
                popularAppsDeferred,
                popularGamesDeferred
            ).firstNotNullOfOrNull { it.await().errorOrNull()?.userMessage }

            _state.value = HomeUiState(
                loading = false,
                refreshing = false,
                offline = !networkMonitor.currentlyOnline(),
                errorMessage = failureMessage,
                promotion = promotion,
                featuredApps = featuredAppsDeferred.await().getOrNull().orEmpty(),
                latestApps = latestApps?.items.orEmpty(),
                popularApps = popularAppsDeferred.await().getOrNull().orEmpty(),
                featuredGames = featuredGamesDeferred.await().getOrNull().orEmpty(),
                latestGames = latestGames?.items.orEmpty(),
                popularGames = popularGamesDeferred.await().getOrNull().orEmpty(),
                freeApps = freeAppsDeferred.await().getOrNull()?.items.orEmpty(),
                proApps = proAppsDeferred.await().getOrNull()?.items.orEmpty(),
                freeGames = freeGamesDeferred.await().getOrNull()?.items.orEmpty(),
                proGames = proGamesDeferred.await().getOrNull()?.items.orEmpty(),
                proUnavailable = proPlanDisabled
            )
        }
    }

    companion object {
        const val SECTION_SIZE = 10
        private const val SECTION_FEATURED = "featured"
        private const val SECTION_POPULAR = "popular"
    }
}
