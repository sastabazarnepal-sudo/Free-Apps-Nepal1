package np.freeappsnepal.user.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.core.domain.ProState
import np.freeappsnepal.core.model.Order
import np.freeappsnepal.core.model.Subscription
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.Formatters
import np.freeappsnepal.user.session.SessionState
import np.freeappsnepal.user.session.SessionViewModel

/**
 * Profile and Pro panel.
 *
 * The three subscription states are rendered exactly as the backend reports them: no active
 * subscription, active with a real expiry date, or expired with a renewal prompt.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    session: SessionState,
    sessionViewModel: SessionViewModel,
    onOpenFavorites: () -> Unit,
    onOpenPro: () -> Unit,
    onOpenSubscription: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenLegal: (String) -> Unit,
    onSignIn: () -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(session.uid) {
        viewModel.load(session.uid)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Profile") }) }
    ) { padding ->
        if (!session.isSignedIn) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                EmptyState(
                    title = "You are not signed in",
                    subtitle = "Sign in to manage your Pro subscription, favourites and reviews."
                )
                Button(onClick = onSignIn, modifier = Modifier.padding(16.dp)) {
                    Text("Sign in")
                }
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 32.dp)
        ) {
            item(key = "identity") {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = session.user?.displayName.orEmpty().ifBlank { "Free Apps Nepal user" },
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        text = session.user?.email.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item(key = "pro_panel") {
                ProPanel(
                    state = state,
                    isPro = session.isPro,
                    hasEverHadPro = session.hasEverHadPro,
                    proState = session.proState,
                    onOpenPro = onOpenPro,
                    onOpenSubscription = onOpenSubscription
                )
            }

            item(key = "menu") {
                Column {
                    ProfileMenuItem(
                        icon = Icons.Filled.Favorite,
                        title = "Favourites",
                        onClick = onOpenFavorites
                    )
                    ProfileMenuItem(
                        icon = Icons.Filled.WorkspacePremium,
                        title = "Pro subscription",
                        onClick = onOpenSubscription
                    )
                    ProfileMenuItem(
                        icon = Icons.Filled.Receipt,
                        title = "Payment history",
                        onClick = onOpenHistory
                    )
                    HorizontalDivider()
                    ProfileMenuItem(
                        icon = Icons.Filled.Policy,
                        title = "Privacy Policy",
                        onClick = { onOpenLegal("privacy") }
                    )
                    ProfileMenuItem(
                        icon = Icons.Filled.Policy,
                        title = "Terms of Use",
                        onClick = { onOpenLegal("terms") }
                    )
                    ProfileMenuItem(
                        icon = Icons.Filled.Info,
                        title = "About",
                        onClick = { onOpenLegal("about") }
                    )
                }
            }

            item(key = "sign_out") {
                TextButton(
                    onClick = {
                        viewModel.signOut()
                        sessionViewModel.signOut()
                    },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text("Sign out", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun ProPanel(
    state: ProfileUiState,
    isPro: Boolean,
    hasEverHadPro: Boolean,
    proState: ProState,
    onOpenPro: () -> Unit,
    onOpenSubscription: () -> Unit
) {
    val status = state.proStatus
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPro) FanColors.GoldSurface else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.WorkspacePremium,
                    contentDescription = null,
                    tint = if (isPro) FanColors.Gold else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = when {
                            isPro -> "PRO ACTIVE"
                            hasEverHadPro -> "PRO EXPIRED"
                            proState == ProState.PENDING -> "PRO PENDING"
                            else -> "PRO INACTIVE"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isPro) FanColors.GoldOn else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = when {
                            isPro -> "Expires ${Formatters.date(status?.expiryMillis)}"
                            hasEverHadPro -> "Renew to unlock Pro downloads again"
                            proState == ProState.PENDING ->
                                "Waiting for the payment provider to confirm"
                            else -> "Subscribe once a month to unlock every Pro app and game"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (state.quote != null && !isPro) {
                Spacer(Modifier.height(10.dp))
                PriceLine(state)
            }

            Spacer(Modifier.height(10.dp))
            if (isPro) {
                Button(
                    onClick = onOpenSubscription,
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = FanColors.Gold,
                        contentColor = FanColors.GoldOn
                    )
                ) {
                    Text("Manage subscription")
                }
            } else {
                Button(onClick = onOpenPro) {
                    Text(if (hasEverHadPro) "Renew Pro" else "Get Pro")
                }
            }
        }
    }
}

@Composable
private fun PriceLine(state: ProfileUiState) {
    val quote = state.quote ?: return
    if (quote.hasDiscount) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = Formatters.moneyFromPaisa(quote.originalPaisa, quote.currency),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = Formatters.discountPercent(quote.discountPercentage),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(MaterialTheme.shapes.extraSmall)
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
        Text(
            text = "${Formatters.moneyFromPaisa(quote.finalPaisa, quote.currency)}/month",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
    } else {
        Text(
            text = "${Formatters.moneyFromPaisa(quote.originalPaisa, quote.currency)}/month",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
    }
    Text(
        text = "All Pro Apps & Games included",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun ProfileMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(14.dp))
        Text(text = title, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Icon(
            Icons.Filled.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** Payment history. Amounts and identifiers come from the backend written order documents. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchaseHistoryScreen(
    session: SessionState,
    onBack: () -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(session.uid) { viewModel.load(session.uid) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Payment history") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)
        ) {
            item(key = "subscriptions_header") {
                Text("Subscriptions", style = MaterialTheme.typography.titleLarge)
            }
            if (state.subscriptions.isEmpty()) {
                item(key = "subs_empty") {
                    Text(
                        text = "No subscriptions yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            } else {
                items(items = state.subscriptions, key = { it.subscriptionId }) { subscription ->
                    SubscriptionRow(subscription)
                }
            }

            item(key = "orders_header") {
                Spacer(Modifier.height(16.dp))
                Text("Payment attempts", style = MaterialTheme.typography.titleLarge)
            }
            if (state.orders.isEmpty()) {
                item(key = "orders_empty") {
                    Text(
                        text = "No payment attempts yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            } else {
                items(items = state.orders, key = { it.orderId }) { order -> OrderRow(order) }
            }
        }
    }
}

@Composable
private fun SubscriptionRow(subscription: Subscription) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = subscription.status.name,
                style = MaterialTheme.typography.titleMedium,
                color = when (subscription.status.name) {
                    "ACTIVE" -> FanColors.Success
                    "PENDING" -> FanColors.Warning
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = Formatters.moneyFromPaisa(subscription.finalPricePaidPaisa, subscription.currency),
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Text(
            text = "${subscription.paymentMethod.label} • Ref ${subscription.transactionId.ifBlank { "-" }}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = "Start ${Formatters.date(subscription.startAt?.toDate()?.time)} • " +
                "Expires ${Formatters.date(subscription.expiresAt?.toDate()?.time)}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun OrderRow(order: Order) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = order.status.name, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(8.dp))
            Text(
                text = Formatters.moneyFromPaisa(order.amountPaisa, order.currency),
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Text(
            text = "${order.paymentMethod.label} • Order ${order.orderId}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
