package np.freeappsnepal.user.ui.screens.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.FavoritesRepository
import np.freeappsnepal.core.model.FavoriteItem
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject

@HiltViewModel
class FavoritesViewModel @Inject constructor(
    private val favoritesRepository: FavoritesRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val items: List<FavoriteItem> = emptyList(),
        val errorMessage: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private var loadedFor: String? = null

    fun load(uid: String?) {
        if (uid == null) {
            _state.value = State(loading = false)
            return
        }
        if (loadedFor == uid && _state.value.items.isNotEmpty()) return
        loadedFor = uid
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            when (val result = favoritesRepository.favorites(uid)) {
                is AppResult.Success -> _state.value = State(loading = false, items = result.data)
                is AppResult.Failure -> _state.value = State(
                    loading = false,
                    items = _state.value.items,
                    errorMessage = result.error.userMessage
                )
            }
        }
    }
}
