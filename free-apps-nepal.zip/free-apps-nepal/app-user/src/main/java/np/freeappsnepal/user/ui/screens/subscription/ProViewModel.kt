package np.freeappsnepal.user.ui.screens.subscription

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.NetworkMonitor
import np.freeappsnepal.core.data.repo.PaymentRepository
import np.freeappsnepal.core.data.repo.ServerClockRepository
import np.freeappsnepal.core.data.repo.SubscriptionRepository
import np.freeappsnepal.core.domain.PriceQuote
import np.freeappsnepal.core.model.PaymentMethod
import np.freeappsnepal.core.model.Plan
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject

/** Everything the payment screens need, including the exact state to show while verifying. */
data class PaymentUiState(
    val loading: Boolean = true,
    val plan: Plan? = null,
    val quote: PriceQuote? = null,
    val method: PaymentMethod = PaymentMethod.KHALTI,
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    val pendingOrderId: String? = null,
    /** Set when the provider must be opened in a browser. Null when no redirect is required. */
    val redirectUrl: String? = null,
    val redirectFormFields: Map<String, String> = emptyMap(),
    val activeSubscription: Boolean = false,
    val expiryMillis: Long? = null
)

/**
 * Drives the Pro purchase flow.
 *
 * Two rules are enforced here and mirrored by the backend:
 *  1. the price is never sent. It is read from the plan document and displayed, and the backend
 *     recomputes the same value when it creates the order.
 *  2. a payment is never assumed to have succeeded. A return from the provider only triggers a
 *     verification call, and Pro becomes active only when the backend reports it verified a payment
 *     against the provider.
 */
@HiltViewModel
class ProViewModel @Inject constructor(
    private val subscriptionRepository: SubscriptionRepository,
    private val paymentRepository: PaymentRepository,
    private val serverClockRepository: ServerClockRepository,
    private val networkMonitor: NetworkMonitor
) : ViewModel() {

    private val _state = MutableStateFlow(PaymentUiState())
    val state: StateFlow<PaymentUiState> = _state.asStateFlow()

    init {
        loadPlan()
    }

    fun loadPlan() {
        viewModelScope.launch {
            val clock = serverClockRepository.serverClock()
            val serverNow = clock.now(System.currentTimeMillis())
            val planDeferred = async { subscriptionRepository.plan() }
            val quoteDeferred = async { subscriptionRepository.quote(serverNowMillis = serverNow) }
            val planResult = planDeferred.await()
            val quoteResult = quoteDeferred.await()

            _state.value = _state.value.copy(
                loading = false,
                plan = planResult.getOrNull(),
                quote = quoteResult.getOrNull(),
                error = (planResult as? AppResult.Failure)?.error?.userMessage
            )
        }
    }

    fun selectMethod(method: PaymentMethod) {
        _state.value = _state.value.copy(method = method, error = null, message = null)
    }

    /**
     * Creates the order on the backend and returns the provider URL the caller should open, or an
     * empty state when the provider requires a form post instead of a redirect.
     */
    fun startPayment(returnUrl: String?, websiteUrl: String?) {
        if (!networkMonitor.currentlyOnline()) {
            _state.value = _state.value.copy(
                error = "No internet connection. Please check your network."
            )
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(busy = true, error = null, message = null)
            when (val result = paymentRepository.createProOrder(
                planId = _state.value.plan?.planId ?: Plan.DEFAULT_PLAN_ID,
                method = _state.value.method,
                returnUrl = returnUrl,
                websiteUrl = websiteUrl
            )) {
                is AppResult.Success -> {
                    val initiation = result.data
                    if (initiation.paymentMethod == PaymentMethod.ESEWA) {
                        _state.value = _state.value.copy(
                            busy = false,
                            pendingOrderId = initiation.orderId,
                            redirectUrl = initiation.paymentUrl,
                            redirectFormFields = emptyMap(),
                            message = "Complete the payment in eSewa, then return to this app."
                        )
                    } else {
                        _state.value = _state.value.copy(
                            busy = false,
                            pendingOrderId = initiation.orderId,
                            redirectUrl = initiation.paymentUrl,
                            message = "Complete the payment in Khalti, then return to this app."
                        )
                    }
                }
                is AppResult.Failure -> _state.value = _state.value.copy(
                    busy = false,
                    error = result.error.userMessage
                )
            }
        }
    }

    /** Called after the provider redirects back into the app. */
    fun verify(orderId: String, encodedEsewaResponse: String? = null) {
        viewModelScope.launch {
            _state.value = _state.value.copy(busy = true, error = null, message = "Verifying payment…")
            val result = if (_state.value.method == PaymentMethod.ESEWA || encodedEsewaResponse != null) {
                paymentRepository.verifyEsewa(orderId, encodedEsewaResponse)
            } else {
                paymentRepository.verifyKhalti(orderId)
            }

            when (result) {
                is AppResult.Success -> {
                    val outcome = result.data
                    _state.value = _state.value.copy(
                        busy = false,
                        message = when {
                            outcome.isActive ->
                                "Pro is active. Every Pro app and game is now unlocked."
                            outcome.isPending ->
                                "Your payment is still pending with the provider. Pro will be activated once it is confirmed."
                            else -> "The payment was not completed. You have not been charged for Pro."
                        },
                        error = null,
                        activeSubscription = outcome.isActive,
                        expiryMillis = outcome.expiresAtMillis,
                        pendingOrderId = if (outcome.isActive) null else _state.value.pendingOrderId
                    )
                }
                is AppResult.Failure -> _state.value = _state.value.copy(
                    busy = false,
                    error = result.error.userMessage,
                    message = null
                )
            }
        }
    }

    fun markPendingFromReturn(orderId: String) {
        _state.value = _state.value.copy(
            pendingOrderId = orderId,
            message = "We are verifying your payment with the provider. This can take a moment."
        )
    }

    fun clearRedirect() {
        _state.value = _state.value.copy(redirectUrl = null)
    }

    fun consumeMessages() {
        _state.value = _state.value.copy(message = null, error = null)
    }
}
