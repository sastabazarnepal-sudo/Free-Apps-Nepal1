package np.freeappsnepal.user.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.AuthRepository
import np.freeappsnepal.core.data.repo.NetworkMonitor
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject

data class AuthUiState(
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    val signedIn: Boolean = false
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val networkMonitor: NetworkMonitor
) : ViewModel() {

    private val _state = MutableStateFlow(AuthUiState())
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    fun signIn(email: String, password: String) {
        if (!validate(email, password)) return
        viewModelScope.launch {
            _state.value = AuthUiState(busy = true)
            when (val result = authRepository.signInWithEmail(email, password)) {
                is AppResult.Success -> _state.value = AuthUiState(signedIn = true)
                is AppResult.Failure -> _state.value = AuthUiState(error = result.error.userMessage)
            }
        }
    }

    fun signUp(name: String, email: String, password: String) {
        if (!validate(email, password)) return
        if (password.length < MIN_PASSWORD_LENGTH) {
            _state.value = AuthUiState(
                error = "Choose a password with at least $MIN_PASSWORD_LENGTH characters."
            )
            return
        }
        viewModelScope.launch {
            _state.value = AuthUiState(busy = true)
            when (val result = authRepository.signUpWithEmail(email, password, name)) {
                is AppResult.Success -> _state.value = AuthUiState(signedIn = true)
                is AppResult.Failure -> _state.value = AuthUiState(error = result.error.userMessage)
            }
        }
    }

    fun signInWithGoogle(idToken: String) {
        viewModelScope.launch {
            _state.value = AuthUiState(busy = true)
            when (val result = authRepository.signInWithGoogle(idToken)) {
                is AppResult.Success -> _state.value = AuthUiState(signedIn = true)
                is AppResult.Failure -> _state.value = AuthUiState(error = result.error.userMessage)
            }
        }
    }

    fun resetPassword(email: String) {
        if (email.isBlank()) {
            _state.value = AuthUiState(error = "Enter your email address first.")
            return
        }
        viewModelScope.launch {
            _state.value = AuthUiState(busy = true)
            when (val result = authRepository.sendPasswordReset(email)) {
                is AppResult.Success -> _state.value = AuthUiState(
                    message = "A password reset link was sent to $email."
                )
                is AppResult.Failure -> _state.value = AuthUiState(error = result.error.userMessage)
            }
        }
    }

    fun consumeMessage() {
        _state.value = _state.value.copy(message = null, error = null)
    }

    fun googleSignInClient() = authRepository.googleSignInClient()

    private fun validate(email: String, password: String): Boolean {
        if (!networkMonitor.currentlyOnline()) {
            _state.value = AuthUiState(error = "No internet connection. Please check your network.")
            return false
        }
        if (!email.contains("@") || email.isBlank()) {
            _state.value = AuthUiState(error = "Enter a valid email address.")
            return false
        }
        if (password.isBlank()) {
            _state.value = AuthUiState(error = "Enter your password.")
            return false
        }
        return true
    }

    companion object {
        const val MIN_PASSWORD_LENGTH = 6
    }
}
