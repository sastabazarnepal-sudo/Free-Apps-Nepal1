package np.freeappsnepal.user.ui.navigation

import np.freeappsnepal.core.model.ItemType

/** Type safe route definitions. Kept as constants so deep links and the back stack stay predictable. */
object Routes {
    const val HOME = "home"
    const val APPS = "apps"
    const val GAMES = "games"
    const val CATEGORIES = "categories"
    const val SEARCH = "search"
    const val PROFILE = "profile"
    const val FAVORITES = "favorites"
    const val PRO = "pro"
    const val SUBSCRIPTION = "subscription"
    const val HISTORY = "history"
    const val PRIVACY = "privacy"
    const val TERMS = "terms"
    const val ABOUT = "about"
    const val SIGN_IN = "sign_in"
    const val SIGN_UP = "sign_up"

    const val ITEM_ID = "itemId"
    const val ITEM_TYPE = "itemType"
    const val CATEGORY_ID = "categoryId"
    const val CATEGORY_NAME = "categoryName"

    const val DETAIL = "detail/{$ITEM_ID}/{$ITEM_TYPE}"
    const val CATEGORY_ITEMS = "category/{$CATEGORY_ID}/{$CATEGORY_NAME}"

    fun detail(itemType: ItemType, itemId: String): String = "detail/$itemId/${itemType.name}"

    fun category(categoryId: String, categoryName: String): String =
        "category/$categoryId/${java.net.URLEncoder.encode(categoryName, "UTF-8")}"
}
