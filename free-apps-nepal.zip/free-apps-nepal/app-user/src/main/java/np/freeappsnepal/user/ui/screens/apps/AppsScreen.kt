package np.freeappsnepal.user.ui.screens.apps

import androidx.compose.runtime.Composable
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.user.ui.screens.list.CatalogListScreen

@Composable
fun AppsScreen(
    onOpenItem: (String) -> Unit,
    onOpenPro: () -> Unit
) {
    CatalogListScreen(
        title = "Apps",
        subtitle = "Free and Pro apps, all visible to everyone",
        type = ItemType.APP,
        categoryId = null,
        categoryName = null,
        onOpenItem = { _, id -> onOpenItem(id) },
        showFilters = true
    )
}
