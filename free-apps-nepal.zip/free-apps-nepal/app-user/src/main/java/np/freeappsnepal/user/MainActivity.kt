package np.freeappsnepal.user

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.AndroidEntryPoint
import np.freeappsnepal.core.ui.theme.FanTheme
import np.freeappsnepal.user.session.SessionViewModel
import np.freeappsnepal.user.ui.navigation.FanNavGraph
import androidx.hilt.navigation.compose.hiltViewModel

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val sessionViewModel: SessionViewModel = hiltViewModel()
            val session by sessionViewModel.state.collectAsStateWithLifecycle()

            FanTheme(proMode = false) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FanNavGraph(session = session, sessionViewModel = sessionViewModel)
                }
            }
        }
    }
}
