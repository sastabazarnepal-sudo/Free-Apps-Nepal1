package np.freeappsnepal.user.ui.screens.legal

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Static legal pages.
 *
 * The text here is a starting point that the operator can replace. It is stored in code rather than
 * fetched so the pages work offline and so there is no remote document that could be tampered with.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegalScreen(
    title: String,
    documentKey: String,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text(
                text = when (documentKey) {
                    KEY_PRIVACY -> PRIVACY_TEXT
                    else -> TERMS_TEXT
                },
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }

}

const val KEY_PRIVACY = "privacy"
const val KEY_TERMS = "terms"

private val PRIVACY_TEXT = """
    Free Apps Nepal respects your privacy.

    What we collect
    We collect the information required to run your account: your email address, an optional
    display name, and your sign in provider identifier. If you sign in with Google we receive
    your basic profile from Google. We store the identifiers of the apps and games you save as
    favourites and the reviews you write.

    What we collect about downloads
    When you tap a download button we record that the button was tapped, together with the
    listing and your account. We cannot and do not record whether an external download
    completed, because the file is served by an external website that we do not control.

    Payments
    Pro subscription payments are processed by Khalti or eSewa. We never receive or store your
    card, wallet PIN or bank credentials. We store the transaction identifier, the order
    identifier, the amount, and the subscription dates so we can show your payment history and
    manage your subscription.

    Stored on your device
    We keep a local cache of catalogue data so the app opens quickly and works on a weak
    connection, and a small offset between your device clock and our server clock. No payment
    credential is stored on your device.

    Sharing
    We do not sell your personal information. We share what is necessary with the payment
    provider you choose, in order to verify your payment.

    Your choices
    You can edit or delete your reviews, remove your favourites, and sign out at any time. To
    delete your account and its data, contact support.

    Children
    This application is not directed at children under 13.

    Contact
    For privacy questions, contact the support address published in the About page.
    """.trimIndent()

private val TERMS_TEXT = """
    Free Apps Nepal terms of use.

    The service
    Free Apps Nepal is a catalogue of applications and games. We do not host the application
    files. Each listing links to a download location chosen by the operator of this catalogue.
    Downloading happens on an external website that we do not control.

    Free and Pro downloads
    Where a free version is offered, the free download link is available to every user,
    including users with an active Pro subscription. Where a Pro version is offered, the Pro
    download link is available only while a Pro subscription is active. The Pro subscription is
    a single monthly subscription that unlocks every eligible Pro listing. It is not a per
    listing purchase.

    Payments
    Pro subscriptions are paid through Khalti or eSewa. Your subscription becomes active only
    after our server has verified the payment with the provider. Payments that cannot be
    verified do not activate a subscription. Subscription periods run for the number of days
    shown at purchase.

    Refunds
    Refunds are handled according to the policy of the payment provider and applicable law.
    Contact support with your transaction identifier.

    Acceptable use
    Do not attempt to circumvent the subscription controls, resell Pro download links, or use
    this service to distribute unlawful material.

    Content
    Listings and their descriptions are provided by the catalogue operator. Report a listing
    that is inaccurate or unlawful via the support address.

    Changes
    These terms may be updated. Continued use of the application after an update means you
    accept the updated terms.
    """.trimIndent()
