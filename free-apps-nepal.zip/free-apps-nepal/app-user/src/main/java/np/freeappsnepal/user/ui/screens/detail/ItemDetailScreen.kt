package np.freeappsnepal.user.ui.screens.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.Review
import np.freeappsnepal.core.ui.common.ErrorState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.components.BadgeKind
import np.freeappsnepal.core.ui.components.DownloadSection
import np.freeappsnepal.core.ui.components.ItemBadge
import np.freeappsnepal.core.ui.components.RemoteIcon
import np.freeappsnepal.core.util.Formatters
import np.freeappsnepal.core.util.LinkOpener
import np.freeappsnepal.user.session.SessionState
import np.freeappsnepal.user.session.SessionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemDetailScreen(
    itemId: String,
    itemType: ItemType,
    session: SessionState,
    sessionViewModel: SessionViewModel,
    onBack: () -> Unit,
    onOpenPro: () -> Unit,
    viewModel: ItemDetailViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val effect by viewModel.effects.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(itemId, itemType) {
        viewModel.start(itemId, itemType, session.uid, session.isPro)
    }

    // The listing is loaded before the entitlement arrives on a cold start. Once it does, refresh
    // the download section so the Pro button reflects the real subscription immediately.
    LaunchedEffect(session.isPro, state.item?.itemId) {
        val item = state.item ?: return@LaunchedEffect
        viewModel.updateEntitlement(item, session.isPro)
    }

    LaunchedEffect(effect) {
        when (val current = effect) {
            is DetailEffect.OpenUrl -> {
                when (LinkOpener.open(context, current.url)) {
                    LinkOpener.Outcome.InvalidUrl ->
                        snackbarHostState.showSnackbar("The download link is not valid.")
                    LinkOpener.Outcome.NoHandler ->
                        snackbarHostState.showSnackbar("No app is available to open this link.")
                    LinkOpener.Outcome.Opened -> Unit
                }
                viewModel.consumeEffect()
            }
            is DetailEffect.Message -> {
                snackbarHostState.showSnackbar(current.text)
                viewModel.consumeEffect()
            }
            DetailEffect.RequiresSignIn -> {
                snackbarHostState.showSnackbar("Please sign in to continue.")
                viewModel.consumeEffect()
            }
            null -> Unit
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.item?.name ?: "Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleFavorite(session.uid) }) {
                        Icon(
                            imageVector = if (state.favorite) Icons.Filled.Favorite
                            else Icons.Filled.FavoriteBorder,
                            contentDescription = if (state.favorite) "Remove favourite"
                            else "Add favourite",
                            tint = if (state.favorite) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        val item = state.item
        when {
            state.loading -> LoadingState(modifier = Modifier.padding(padding))
            item == null && state.errorMessage != null -> ErrorState(
                message = state.errorMessage.orEmpty(),
                modifier = Modifier.padding(padding),
                onRetry = { viewModel.load(session.uid, session.isPro) }
            )
            item == null -> ErrorState(
                message = "This item is no longer available.",
                modifier = Modifier.padding(padding),
                onRetry = { viewModel.load(session.uid, session.isPro) }
            )
            else -> DetailContent(
                item = item,
                state = state,
                session = session,
                contentPadding = padding,
                onFreeDownload = viewModel::onFreeDownload,
                onProDownload = viewModel::onProDownload,
                onSubscribe = onOpenPro,
                onScreenshotClick = { url -> viewModel.openExternal(url) },
                onSubmitReview = { rating, text ->
                    viewModel.submitReview(
                        uid = session.uid,
                        userName = session.user?.displayName.orEmpty(),
                        userPhotoUrl = session.user?.photoUrl?.toString().orEmpty(),
                        rating = rating,
                        text = text
                    )
                },
                onDeleteReview = { viewModel.deleteReview(session.uid) }
            )
        }
    }
}

@Composable
private fun DetailContent(
    item: AppItem,
    state: DetailUiState,
    session: SessionState,
    contentPadding: PaddingValues,
    onFreeDownload: () -> Unit,
    onProDownload: () -> Unit,
    onSubscribe: () -> Unit,
    onScreenshotClick: (String) -> Unit,
    onSubmitReview: (Int, String) -> Unit,
    onDeleteReview: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item(key = "header") {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RemoteIcon(url = item.iconUrl, name = item.name, size = 76.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = item.name, style = MaterialTheme.typography.headlineSmall)
                        Text(
                            text = item.developerName.ifBlank { "Unknown developer" },
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (item.categoryName.isNotBlank()) {
                            Text(
                                text = item.categoryName,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.padding(top = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Each badge is derived from the administrator flag alone, so a badge is never
                    // shown for a property the listing does not have.
                    if (item.hasFree) ItemBadge(BadgeKind.FREE)
                    if (item.proEnabled) ItemBadge(BadgeKind.PRO)
                    if (item.new) ItemBadge(BadgeKind.NEW)
                    if (item.popular) ItemBadge(BadgeKind.POPULAR)
                    if (item.featured) ItemBadge(BadgeKind.FEATURED)
                }

                if (item.ratingCount > 0) {
                    Row(
                        modifier = Modifier.padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RatingStars(rating = item.averageRating.toInt(), starSize = 16.dp)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = String.format(
                                java.util.Locale.US,
                                "%.1f (%d)",
                                item.averageRating,
                                item.ratingCount
                            ),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (item.screenshots.isNotEmpty()) {
            item(key = "screenshots") {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items = item.screenshots.filter { it.isNotBlank() }, key = { it }) { url ->
                        AsyncImage(
                            model = url,
                            contentDescription = item.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(width = 150.dp, height = 260.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onScreenshotClick(url) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        item(key = "downloads") {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                HorizontalDivider(modifier = Modifier.padding(bottom = 14.dp))
                Text(text = "Download", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))
                DownloadSection(
                    access = state.access,
                    onFreeDownload = onFreeDownload,
                    onProDownload = onProDownload,
                    onSubscribe = onSubscribe
                )
            }
        }

        item(key = "meta") {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                HorizontalDivider(modifier = Modifier.padding(bottom = 14.dp))
                Text(text = "Information", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                MetaRow("Version", item.version)
                MetaRow("File size", item.fileSize)
                MetaRow("Minimum Android", item.minAndroidVersion)
                MetaRow("Last updated", Formatters.date(item.lastUpdated?.toDate()?.time))
                MetaRow("Views", Formatters.count(item.viewCount))
                MetaRow("Free download clicks", Formatters.count(item.freeDownloadClickCount))
                MetaRow("Pro download clicks", Formatters.count(item.proDownloadClickCount))
            }
        }

        if (item.whatsNew.isNotBlank()) {
            item(key = "whats_new") {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(text = "What's new", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(6.dp))
                    Text(text = item.whatsNew, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }

        item(key = "description") {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(text = "About this ${item.type.label}", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = item.description.ifBlank { "No description has been provided." },
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        item(key = "reviews_header") {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                HorizontalDivider(modifier = Modifier.padding(bottom = 14.dp))
                Text(text = "Reviews", style = MaterialTheme.typography.titleLarge)
            }
        }

        item(key = "review_editor") {
            ReviewEditor(
                existing = state.myReview,
                signedIn = session.isSignedIn,
                onSubmit = onSubmitReview,
                onDelete = onDeleteReview
            )
        }

        if (state.reviews.isEmpty()) {
            item(key = "reviews_empty") {
                Text(
                    text = "No reviews yet. Be the first to review this ${item.type.label}.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        } else {
            items(items = state.reviews, key = { it.reviewId }) { review ->
                ReviewRow(review = review)
            }
        }
    }
}

@Composable
private fun MetaRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(160.dp)
        )
        Text(text = value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ReviewRow(review: Review) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = review.userName.ifBlank { "User" },
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.width(8.dp))
            RatingStars(rating = review.rating, starSize = 14.dp)
        }
        if (review.text.isNotBlank()) {
            Text(
                text = review.text,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun ReviewEditor(
    existing: Review?,
    signedIn: Boolean,
    onSubmit: (Int, String) -> Unit,
    onDelete: () -> Unit
) {
    var rating by remember(existing?.reviewId) { mutableIntStateOf(existing?.rating ?: 0) }
    var text by remember(existing?.reviewId) { mutableStateOf(existing?.text.orEmpty()) }

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        if (!signedIn) {
            Text(
                text = "Sign in to rate and review.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            return@Column
        }
        Text(
            text = if (existing == null) "Write a review" else "Edit your review",
            style = MaterialTheme.typography.titleMedium
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            (1..5).forEach { star ->
                IconButton(onClick = { rating = star }, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = if (star <= rating) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = "$star star",
                        tint = np.freeappsnepal.core.ui.theme.FanColors.Gold
                    )
                }
            }
        }
        OutlinedTextField(
            value = text,
            onValueChange = { if (it.length <= 600) text = it },
            label = { Text("Your review") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            maxLines = 4
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.End
        ) {
            if (existing != null) {
                TextButton(onClick = onDelete) { Text("Delete") }
                Spacer(Modifier.width(8.dp))
            }
            Button(onClick = { onSubmit(rating, text) }) {
                Text(if (existing == null) "Post" else "Update")
            }
        }
    }
}

@Composable
private fun RatingStars(rating: Int, starSize: androidx.compose.ui.unit.Dp) {
    Row {
        (1..5).forEach { star ->
            Icon(
                imageVector = if (star <= rating) Icons.Filled.Star else Icons.Filled.StarBorder,
                contentDescription = null,
                tint = np.freeappsnepal.core.ui.theme.FanColors.Gold,
                modifier = Modifier.size(starSize)
            )
        }
    }
}
