package np.freeappsnepal.user.ui.screens.subscription

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.Formatters
import np.freeappsnepal.user.session.SessionState
import np.freeappsnepal.user.session.SessionViewModel
import np.freeappsnepal.user.ui.screens.profile.ProfileViewModel

/**
 * Subscription details.
 *
 * Shows the three states the backend can produce for this user: inactive with a subscribe action,
 * active with the real expiry date, or expired with a renew action.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    session: SessionState,
    sessionViewModel: SessionViewModel,
    onBack: () -> Unit,
    onOpenHistory: () -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(session.uid, session.proStatus) {
        viewModel.load(session.uid)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Subscription") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (state.loading) {
            LoadingState(modifier = Modifier.padding(padding))
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)
        ) {
            item(key = "status_card") {
                val status = state.proStatus
                val isActive = session.isPro
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isActive) FanColors.GoldSurface
                        else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = when {
                                isActive -> "PRO ACTIVE"
                                session.hasEverHadPro -> "PRO EXPIRED"
                                else -> "PRO INACTIVE"
                            },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (isActive) FanColors.GoldOn
                            else MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.height(6.dp))
                        TextRow("Plan", state.plan?.name ?: "Free Apps Nepal Pro")
                        TextRow(
                            "Started",
                            Formatters.date(status?.startMillis)
                        )
                        TextRow(
                            "Expires",
                            Formatters.date(status?.expiryMillis)
                        )
                        if (isActive) {
                            TextRow("Remaining", Formatters.duration(status?.remainingMillis ?: 0L))
                        }
                    }
                }
            }

            item(key = "history_button") {
                TextButton(
                    onClick = onOpenHistory,
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Icon(Icons.Filled.Receipt, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Payment history")
                }
            }

            if (state.orders.isNotEmpty()) {
                item(key = "recent_header") {
                    Spacer(Modifier.height(8.dp))
                    Text("Recent payments", style = MaterialTheme.typography.titleLarge)
                }
                items(state.orders.take(5), key = { it.orderId }) { order ->
                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(order.status.name, style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                Formatters.moneyFromPaisa(order.amountPaisa, order.currency),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        Text(
                            text = "${order.paymentMethod.label} • Order ${order.orderId}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TextRow(label: String, value: String) {
    Row(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(110.dp)
        )
        Text(text = value, style = MaterialTheme.typography.bodyMedium)
    }
}
