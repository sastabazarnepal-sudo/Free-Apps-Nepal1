package np.freeappsnepal.user.ui.screens.list

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.core.domain.ListFilter
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.ErrorState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.common.OfflineState
import np.freeappsnepal.core.ui.components.ItemListRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.hilt.navigation.compose.hiltViewModel

/**
 * The single list implementation behind Apps, Games, a category and a search result set.
 *
 * Load more is triggered from the list state rather than from an item at the end of the list, so a
 * short list still pages correctly and there is no sentinel row to render.
 */
@Composable
fun CatalogListScreen(
    title: String,
    subtitle: String?,
    type: ItemType?,
    categoryId: String?,
    categoryName: String?,
    onOpenItem: (ItemType, String) -> Unit,
    onBack: (() -> Unit)? = null,
    showFilters: Boolean = true,
    viewModel: ItemsViewModel = hiltViewModel()
) {
    LaunchedEffect(title, type, categoryId) {
        viewModel.start(title, subtitle, type, categoryId, categoryName)
    }

    val state by viewModel.state.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    val shouldLoadMore by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = listState.layoutInfo.totalItemsCount
            total > 0 && lastVisible >= total - 3
        }
    }
    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) viewModel.loadMore()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (onBack != null || (!subtitle.isNullOrBlank())) {
            CatalogHeader(title = title, subtitle = subtitle, onBack = onBack)
        }

        if (showFilters) {
            FilterRow(
                selected = state.filter,
                onSelect = viewModel::setFilter
            )
            HorizontalDivider()
        }

        when {
            state.loading -> LoadingState()
            state.items.isEmpty() && state.offline -> OfflineState(onRetry = viewModel::refresh)
            state.items.isEmpty() && state.errorMessage != null ->
                ErrorState(message = state.errorMessage.orEmpty(), onRetry = viewModel::refresh)
            state.items.isEmpty() -> EmptyState(
                title = "Nothing here yet",
                subtitle = "No published listings match this selection."
            )
            else -> LazyColumn(
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(
                    items = state.items,
                    key = { it.type.name + it.itemId },
                    contentType = { "item" }
                ) { item ->
                    ItemListRow(item = item, onClick = { onOpenItem(item.type, item.itemId) })
                }
                if (state.loadingMore) {
                    item(key = "loading_more") {
                        LoadingState(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun CatalogHeader(title: String, subtitle: String?, onBack: (() -> Unit)?) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(text = title, style = MaterialTheme.typography.headlineSmall)
        if (!subtitle.isNullOrBlank()) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun FilterRow(selected: ListFilter, onSelect: (ListFilter) -> Unit) {
    androidx.compose.foundation.layout.Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        ListFilter.entries.forEach { filter ->
            FilterChip(
                selected = selected == filter,
                onClick = { onSelect(filter) },
                label = { Text(filter.label) },
                modifier = Modifier.padding(end = 8.dp)
            )
        }
    }
}
