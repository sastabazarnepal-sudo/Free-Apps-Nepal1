package np.freeappsnepal.user.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.user.session.SessionState
import np.freeappsnepal.user.session.SessionViewModel
import np.freeappsnepal.user.ui.screens.about.AboutScreen
import np.freeappsnepal.user.ui.screens.apps.AppsScreen
import np.freeappsnepal.user.ui.screens.auth.SignInScreen
import np.freeappsnepal.user.ui.screens.auth.SignUpScreen
import np.freeappsnepal.user.ui.screens.categories.CategoriesScreen
import np.freeappsnepal.user.ui.screens.categories.CategoryItemsScreen
import np.freeappsnepal.user.ui.screens.detail.ItemDetailScreen
import np.freeappsnepal.user.ui.screens.favorites.FavoritesScreen
import np.freeappsnepal.user.ui.screens.games.GamesScreen
import np.freeappsnepal.user.ui.screens.home.HomeScreen
import np.freeappsnepal.user.ui.screens.legal.KEY_PRIVACY
import np.freeappsnepal.user.ui.screens.legal.KEY_TERMS
import np.freeappsnepal.user.ui.screens.legal.LegalScreen
import np.freeappsnepal.user.ui.screens.profile.ProfileScreen
import np.freeappsnepal.user.ui.screens.profile.PurchaseHistoryScreen
import np.freeappsnepal.user.ui.screens.search.SearchScreen
import np.freeappsnepal.user.ui.screens.subscription.ProScreen
import np.freeappsnepal.user.ui.screens.subscription.SubscriptionScreen

private data class BottomTab(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val requiresAuth: Boolean = false
)

private val bottomTabs = listOf(
    BottomTab(Routes.HOME, "Home", Icons.Filled.Home),
    BottomTab(Routes.APPS, "Apps", Icons.Filled.Category),
    BottomTab(Routes.GAMES, "Games", Icons.Filled.Games),
    BottomTab(Routes.SEARCH, "Search", Icons.Filled.Search),
    BottomTab(Routes.PROFILE, "Profile", Icons.Filled.Person, requiresAuth = true)
)

@Composable
fun FanNavGraph(
    session: SessionState,
    sessionViewModel: SessionViewModel
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = bottomTabs.any { it.route == currentRoute }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomTabs.forEach { tab ->
                        val selected = backStackEntry?.destination?.hierarchy
                            ?.any { it.route == tab.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (tab.requiresAuth && !session.isSignedIn) {
                                    navController.navigate(Routes.SIGN_IN)
                                    return@NavigationBarItem
                                }
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    session = session,
                    onOpenItem = { type, id -> navController.navigate(Routes.detail(type, id)) },
                    onOpenCategories = { navController.navigate(Routes.CATEGORIES) },
                    onOpenPro = { navController.navigate(Routes.PRO) },
                    onOpenSearch = { navController.navigate(Routes.SEARCH) }
                )
            }

            composable(Routes.APPS) {
                AppsScreen(
                    onOpenItem = { id -> navController.navigate(Routes.detail(ItemType.APP, id)) },
                    onOpenPro = { navController.navigate(Routes.PRO) }
                )
            }

            composable(Routes.GAMES) {
                GamesScreen(
                    onOpenItem = { id -> navController.navigate(Routes.detail(ItemType.GAME, id)) },
                    onOpenPro = { navController.navigate(Routes.PRO) }
                )
            }

            composable(Routes.CATEGORIES) {
                CategoriesScreen(
                    onOpenCategory = { id, name ->
                        navController.navigate(Routes.category(id, name))
                    }
                )
            }

            composable(
                route = Routes.CATEGORY_ITEMS,
                arguments = listOf(
                    navArgument(Routes.CATEGORY_ID) { type = NavType.StringType },
                    navArgument(Routes.CATEGORY_NAME) { type = NavType.StringType }
                )
            ) { entry ->
                CategoryItemsScreen(
                    categoryId = entry.arguments?.getString(Routes.CATEGORY_ID).orEmpty(),
                    categoryName = entry.arguments?.getString(Routes.CATEGORY_NAME).orEmpty(),
                    onOpenItem = { type, id -> navController.navigate(Routes.detail(type, id)) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.SEARCH) {
                SearchScreen(
                    onOpenItem = { type, id -> navController.navigate(Routes.detail(type, id)) },
                    onOpenPro = { navController.navigate(Routes.PRO) }
                )
            }

            composable(
                route = Routes.DETAIL,
                arguments = listOf(
                    navArgument(Routes.ITEM_ID) { type = NavType.StringType },
                    navArgument(Routes.ITEM_TYPE) { type = NavType.StringType }
                )
            ) { entry ->
                ItemDetailScreen(
                    itemId = entry.arguments?.getString(Routes.ITEM_ID).orEmpty(),
                    itemType = ItemType.fromName(entry.arguments?.getString(Routes.ITEM_TYPE)),
                    session = session,
                    sessionViewModel = sessionViewModel,
                    onBack = { navController.popBackStack() },
                    onOpenPro = { navController.navigate(Routes.PRO) }
                )
            }

            composable(Routes.PROFILE) {
                ProfileScreen(
                    session = session,
                    sessionViewModel = sessionViewModel,
                    onOpenFavorites = { navController.navigate(Routes.FAVORITES) },
                    onOpenPro = { navController.navigate(Routes.PRO) },
                    onOpenSubscription = { navController.navigate(Routes.SUBSCRIPTION) },
                    onOpenHistory = { navController.navigate(Routes.HISTORY) },
                    onOpenLegal = { route -> navController.navigate(route) },
                    onSignIn = { navController.navigate(Routes.SIGN_IN) }
                )
            }

            composable(Routes.FAVORITES) {
                FavoritesScreen(
                    session = session,
                    onOpenItem = { type, id -> navController.navigate(Routes.detail(type, id)) },
                    onSignIn = { navController.navigate(Routes.SIGN_IN) }
                )
            }

            composable(Routes.PRO) {
                ProScreen(
                    session = session,
                    sessionViewModel = sessionViewModel,
                    onBack = { navController.popBackStack() },
                    onOpenSubscription = { navController.navigate(Routes.SUBSCRIPTION) }
                )
            }

            composable(Routes.SUBSCRIPTION) {
                SubscriptionScreen(
                    session = session,
                    sessionViewModel = sessionViewModel,
                    onBack = { navController.popBackStack() },
                    onOpenHistory = { navController.navigate(Routes.HISTORY) }
                )
            }

            composable(Routes.HISTORY) {
                PurchaseHistoryScreen(
                    session = session,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.SIGN_IN) {
                SignInScreen(
                    onSignedIn = { navController.popBackStack() },
                    onOpenSignUp = { navController.navigate(Routes.SIGN_UP) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.SIGN_UP) {
                SignUpScreen(
                    onSignedUp = {
                        navController.navigate(Routes.HOME) {
                            popUpTo(Routes.HOME) { inclusive = true }
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.ABOUT) { AboutScreen(onBack = { navController.popBackStack() }) }

            composable(Routes.PRIVACY) {
                LegalScreen(
                    title = "Privacy Policy",
                    documentKey = KEY_PRIVACY,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.TERMS) {
                LegalScreen(
                    title = "Terms of Use",
                    documentKey = KEY_TERMS,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
