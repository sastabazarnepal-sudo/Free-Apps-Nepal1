package np.freeappsnepal.user.ui.screens.search

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.core.domain.SearchFilter
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.components.ItemListRow
import np.freeappsnepal.user.ui.screens.list.ItemsViewModel
import kotlinx.coroutines.delay

/**
 * Search across app and game names, developer names and categories.
 *
 * A short debounce avoids a request per keystroke, which matters on metered mobile data. Pro
 * listings are returned for every filter: [SearchFilter.PRO] selects listings that offer a Pro
 * version, it does not hide the rest from a user without a subscription.
 */
@Composable
fun SearchScreen(
    onOpenItem: (ItemType, String) -> Unit,
    onOpenPro: () -> Unit,
    viewModel: ItemsViewModel = hiltViewModel()
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(SearchFilter.ALL) }
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(query, filter) {
        if (query.isBlank()) return@LaunchedEffect
        delay(280)
        viewModel.search(query, filter)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Search apps, games, developers, categories") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    imeAction = ImeAction.Search
                )
            )

            Row(modifier = Modifier.padding(top = 8.dp)) {
                SearchFilter.entries.forEach { entry ->
                    FilterChip(
                        selected = filter == entry,
                        onClick = { filter = entry },
                        label = { Text(entry.label) },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }
        }

        when {
            query.isBlank() -> EmptyState(
                title = "Search Free Apps Nepal",
                subtitle = "Find free and Pro apps and games by name, developer or category."
            )
            state.loading -> LoadingState()
            state.items.isEmpty() && state.errorMessage != null -> EmptyState(
                title = "Search failed",
                subtitle = state.errorMessage
            )
            state.items.isEmpty() -> EmptyState(
                title = "No results found",
                subtitle = "Try a different keyword."
            )
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    horizontal = 16.dp,
                    vertical = 8.dp
                )
            ) {
                items(
                    items = state.items,
                    key = { it.type.name + it.itemId }
                ) { item ->
                    ItemListRow(item = item, onClick = { onOpenItem(item.type, item.itemId) })
                }
            }
        }
    }
}
