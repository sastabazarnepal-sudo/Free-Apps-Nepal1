package np.freeappsnepal.user.ui.screens.subscription

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.core.model.PaymentMethod
import np.freeappsnepal.core.ui.common.ErrorState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.Formatters
import np.freeappsnepal.user.payment.PaymentContract
import np.freeappsnepal.user.payment.PaymentRequest
import np.freeappsnepal.user.payment.PaymentReturnBus
import np.freeappsnepal.user.payment.PaymentWebActivity

private const val RETURN_SCHEME = "freeappsnepal"

/**
 * The Pro subscription screen.
 *
 * It shows the price the backend computed, including any administrator discount and its exact
 * discount percentage, then starts a real payment. There is no button on this screen that can grant
 * Pro. The only path to an active subscription is a provider payment that the backend has verified.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProScreen(
    session: np.freeappsnepal.user.session.SessionState,
    sessionViewModel: np.freeappsnepal.user.session.SessionViewModel,
    onBack: () -> Unit,
    onOpenSubscription: () -> Unit,
    viewModel: ProViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val paymentLauncher = rememberLauncherForActivityResult(contract = PaymentContract()) { result ->
        val orderId = state.pendingOrderId
        if (orderId != null) {
            val encoded = parseEsewaData(result.query)
            viewModel.verify(orderId, encoded)
        }
    }

    // A provider may return through the deep link activity rather than the in app web view.
    LaunchedEffect(Unit) {
        PaymentReturnBus.consume()?.let { returned ->
            viewModel.verify(returned.orderId, returned.encodedEsewaResponse)
        }
    }

    LaunchedEffect(state.activeSubscription) {
        if (state.activeSubscription) sessionViewModel.refresh()
    }

    val redirectUrl = state.redirectUrl
    LaunchedEffect(redirectUrl) {
        if (!redirectUrl.isNullOrBlank()) {
            paymentLauncher.launch(
                PaymentRequest(
                    url = redirectUrl,
                    method = if (state.method == PaymentMethod.ESEWA && state.redirectFormFields.isNotEmpty()) {
                        PaymentWebActivity.POST_FORM
                    } else {
                        PaymentWebActivity.GET_REDIRECT
                    },
                    formFields = state.redirectFormFields,
                    returnScheme = RETURN_SCHEME
                )
            )
            viewModel.clearRedirect()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Free Apps Nepal Pro") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        when {
            state.loading -> LoadingState(modifier = Modifier.padding(padding))
            state.plan == null -> ErrorState(
                message = state.error ?: "The Pro plan is not available right now.",
                modifier = Modifier.padding(padding),
                onRetry = viewModel::loadPlan
            )
            else -> Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                ProHero(isActive = session.isPro, expiryMillis = session.proStatus.expiryMillis)

                Spacer(Modifier.height(16.dp))
                PriceCard(
                    originalPaisa = state.quote?.originalPaisa ?: 0L,
                    finalPaisa = state.quote?.finalPaisa ?: 0L,
                    discountPercentage = state.quote?.discountPercentage ?: 0.0,
                    hasDiscount = state.quote?.hasDiscount == true,
                    currency = state.quote?.currency ?: "NPR"
                )

                Spacer(Modifier.height(16.dp))
                BenefitsCard()

                if (!session.isPro) {
                    Spacer(Modifier.height(16.dp))
                    Text("Payment method", style = MaterialTheme.typography.titleMedium)
                    Row(modifier = Modifier.padding(top = 8.dp)) {
                        PaymentMethod.entries.forEach { method ->
                            FilterChip(
                                selected = state.method == method,
                                onClick = { viewModel.selectMethod(method) },
                                label = { Text(method.label) },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    state.error?.let {
                        Text(text = it, color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(8.dp))
                    }
                    state.message?.let {
                        Text(
                            text = it,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.startPayment(
                                returnUrl = "$RETURN_SCHEME://payment/return",
                                websiteUrl = "https://freeappsnepal.app"
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !state.busy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FanColors.Gold,
                            contentColor = FanColors.GoldOn
                        )
                    ) {
                        if (state.busy) {
                            CircularProgressIndicator(
                                modifier = Modifier.height(18.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "Pay ${Formatters.moneyFromPaisa(state.quote?.finalPaisa ?: 0L)} with ${state.method.label}",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Payment is verified by our server with Khalti or eSewa before Pro is " +
                            "activated. If verification has not finished, Pro stays inactive and " +
                            "your order remains pending.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onOpenSubscription, modifier = Modifier.fillMaxWidth()) {
                        Text("View subscription details")
                    }
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ProHero(isActive: Boolean, expiryMillis: Long?) {
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isActive) FanColors.GoldSurface else MaterialTheme.colorScheme.primaryContainer,
                MaterialTheme.shapes.medium
            )
            .padding(18.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.WorkspacePremium,
                    contentDescription = null,
                    tint = if (isActive) FanColors.Gold else MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = if (isActive) "Your Pro subscription is active" else "Unlock every Pro app and game",
                    style = MaterialTheme.typography.titleLarge
                )
            }
            Text(
                text = if (isActive) {
                    "Expires ${Formatters.date(expiryMillis)}. Renew any time to extend it."
                } else {
                    "One monthly subscription. No per app purchase, no extra ad on Pro downloads."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
private fun PriceCard(
    originalPaisa: Long,
    finalPaisa: Long,
    discountPercentage: Double,
    hasDiscount: Boolean,
    currency: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text("Monthly plan", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            if (hasDiscount) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${Formatters.moneyFromPaisa(originalPaisa, currency)}/month",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textDecoration = TextDecoration.LineThrough
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = Formatters.discountPercent(discountPercentage),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.shapes.extraSmall
                            )
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${Formatters.moneyFromPaisa(finalPaisa, currency)}/month",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Text(
                    text = "${Formatters.moneyFromPaisa(originalPaisa, currency)}/month",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "All Pro Apps & Games included",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
            Text(
                text = "Only the plan price above is charged. The app never sends a price.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun BenefitsCard() {
    val benefits = listOf(
        "Every eligible Pro App unlocked",
        "Every eligible Pro Game unlocked",
        "Pro direct download with no extra ad",
        "No per app payment",
        "Free download links stay available to you too"
    )
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text("What you get", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            benefits.forEach { benefit ->
                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = FanColors.Success,
                        modifier = Modifier.height(18.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(text = benefit, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

/**
 * Extracts the base64 `data` parameter from an eSewa return query if present. Any other provider
 * return passes through untouched.
 */
private fun parseEsewaData(query: String): String? {
    if (query.isBlank()) return null
    return runCatching {
        Uri.parse("https://local/?$query").getQueryParameter("data")
    }.getOrNull()
}
