package np.freeappsnepal.user.ui.screens.games

import androidx.compose.runtime.Composable
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.user.ui.screens.list.CatalogListScreen

@Composable
fun GamesScreen(
    onOpenItem: (String) -> Unit,
    onOpenPro: () -> Unit
) {
    CatalogListScreen(
        title = "Games",
        subtitle = "Free and Pro games, all visible to everyone",
        type = ItemType.GAME,
        categoryId = null,
        categoryName = null,
        onOpenItem = { _, id -> onOpenItem(id) },
        showFilters = true
    )
}
