package np.freeappsnepal.user.ui.screens.favorites

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.components.BadgeKind
import np.freeappsnepal.core.ui.components.ItemBadge
import np.freeappsnepal.core.ui.components.RemoteIcon
import np.freeappsnepal.user.session.SessionState

/**
 * Favourites are stored per user under `favorites/{userId}/items`, so a user can only ever read
 * their own list. The stored snapshot keeps this screen to a single read.
 */
@Composable
fun FavoritesScreen(
    session: SessionState,
    onOpenItem: (ItemType, String) -> Unit,
    onSignIn: () -> Unit,
    viewModel: FavoritesViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(session.uid) { viewModel.load(session.uid) }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(text = "Favourites", style = MaterialTheme.typography.headlineSmall)
        }

        when {
            !session.isSignedIn -> EmptyState(
                title = "Sign in to see your favourites",
                subtitle = "Your saved apps and games are tied to your account."
            )
            state.loading -> LoadingState()
            state.items.isEmpty() -> EmptyState(
                title = "No favourites yet",
                subtitle = "Tap the heart on any app or game to save it here."
            )
            else -> LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = state.items, key = { it.itemId }, contentType = { "favorite" }) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable { onOpenItem(item.type, item.itemId) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RemoteIcon(url = item.iconUrl, name = item.name, size = 48.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = item.developerName,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                if (item.freeEnabled) ItemBadge(BadgeKind.FREE)
                                if (item.proEnabled) ItemBadge(BadgeKind.PRO)
                            }
                        }
                    }
                }
            }
        }
    }
}
