package np.freeappsnepal.user.ui.screens.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.CatalogRepository
import np.freeappsnepal.core.data.repo.FavoritesRepository
import np.freeappsnepal.core.data.repo.NetworkMonitor
import np.freeappsnepal.core.data.repo.PaymentRepository
import np.freeappsnepal.core.data.repo.ReviewRepository
import np.freeappsnepal.core.domain.DownloadAccess
import np.freeappsnepal.core.domain.DownloadTarget
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.Review
import np.freeappsnepal.core.util.AppResult
import np.freeappsnepal.core.domain.primaryTarget
import javax.inject.Inject

/** A one shot instruction for the screen to perform, then consume. */
sealed interface DetailEffect {
    data class OpenUrl(val url: String) : DetailEffect
    data class Message(val text: String) : DetailEffect
    data object RequiresSignIn : DetailEffect
}

data class DetailUiState(
    val loading: Boolean = true,
    val item: AppItem? = null,
    val access: DownloadAccess = DownloadAccess.hidden(),
    val reviews: List<Review> = emptyList(),
    val myReview: Review? = null,
    val favorite: Boolean = false,
    val errorMessage: String? = null,
    val offline: Boolean = false,
    val downloading: Boolean = false
)

/**
 * Detail screen logic.
 *
 * The three business rules the whole application depends on live in [DownloadAccess] and are
 * re-derived here from the listing plus the subscription state:
 *  - the free link is offered to everyone whenever the administrator enabled a free version
 *  - the pro link button is shown to everyone, but only unlocked for an active subscriber
 *  - a Pro subscriber who taps free receives exactly the same free URL as a non subscriber
 * The Pro URL is never present in the listing document, so it cannot leak from here. It is fetched
 * from the backend at the moment of use, which also re-validates the subscription server side.
 */
@HiltViewModel
class ItemDetailViewModel @Inject constructor(
    private val catalogRepository: CatalogRepository,
    private val paymentRepository: PaymentRepository,
    private val reviewRepository: ReviewRepository,
    private val favoritesRepository: FavoritesRepository,
    private val networkMonitor: NetworkMonitor
) : ViewModel() {

    private val _state = MutableStateFlow(DetailUiState())
    val state: StateFlow<DetailUiState> = _state.asStateFlow()

    private val _effects = MutableStateFlow<DetailEffect?>(null)
    val effects: StateFlow<DetailEffect?> = _effects.asStateFlow()

    private var itemId: String = ""
    private var itemType: ItemType = ItemType.APP

    fun start(itemId: String, itemType: ItemType, uid: String?, isPro: Boolean) {
        if (this.itemId == itemId && this.itemType == itemType && _state.value.item != null) {
            return
        }
        this.itemId = itemId
        this.itemType = itemType
        load(uid, isPro)
    }

    fun updateEntitlement(item: AppItem, isPro: Boolean) {
        _state.value = _state.value.copy(access = DownloadAccess.forItem(item, isPro))
    }

    fun load(uid: String?, isPro: Boolean) {
        viewModelScope.launch {
            _state.value = _state.value.copy(
                loading = _state.value.item == null,
                errorMessage = null,
                offline = !networkMonitor.currentlyOnline()
            )

            when (val result = catalogRepository.detail(itemType, itemId)) {
                is AppResult.Success -> {
                    val item = result.data
                    // A view is counted here, once per screen open, and never claims a download.
                    catalogRepository.requestViewIncrement(itemType, itemId)
                    val reviews = reviewRepository.forItem(itemType, itemId).getOrNull().orEmpty()
                    val myReview = if (uid != null) {
                        reviewRepository.myReview(itemType, itemId, uid).getOrNull()
                    } else {
                        null
                    }
                    val favorite = if (uid != null) {
                        favoritesRepository.isFavorite(uid, itemId).getOrNull() ?: false
                    } else {
                        false
                    }
                    _state.value = _state.value.copy(
                        loading = false,
                        item = item,
                        access = DownloadAccess.forItem(item, isPro),
                        reviews = reviews,
                        myReview = myReview,
                        favorite = favorite,
                        offline = !networkMonitor.currentlyOnline()
                    )
                }
                is AppResult.Failure -> _state.value = _state.value.copy(
                    loading = false,
                    errorMessage = result.error.userMessage,
                    offline = !networkMonitor.currentlyOnline()
                )
            }
        }
    }

    /**
     * Free download. Works for a free user and for a Pro user, and always opens the same configured
     * URL. The backend records the click and echoes the stored URL; the URL is opened verbatim.
     */
    fun onFreeDownload() {
        val item = _state.value.item ?: return
        if (!item.hasFree) return
        viewModelScope.launch {
            _state.value = _state.value.copy(downloading = true)
            val result = paymentRepository.trackFreeDownload(itemType, itemId)
            _state.value = _state.value.copy(downloading = false)
            when (result) {
                is AppResult.Success -> _emit(DetailEffect.OpenUrl(result.data))
                is AppResult.Failure -> {
                    // Fall back to the listing document, which carries the same free URL, so a
                    // transient function error never blocks a download the administrator published.
                    if (item.freeDownloadUrl.isNotBlank()) {
                        _emit(DetailEffect.OpenUrl(item.freeDownloadUrl))
                    } else {
                        _emit(DetailEffect.Message(result.error.userMessage))
                    }
                }
            }
        }
    }

    /**
     * Pro download. Only reachable while the button is unlocked. The backend re-checks the
     * subscription against the trusted clock and only then returns the configured Pro URL.
     */
    fun onProDownload() {
        if (!_state.value.access.proDownloadUnlocked) {
            _emit(DetailEffect.Message(_state.value.access.proLockedReason.orEmpty()))
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(downloading = true)
            val result = paymentRepository.getProDownloadLink(itemType, itemId)
            _state.value = _state.value.copy(downloading = false)
            when (result) {
                is AppResult.Success -> _emit(DetailEffect.OpenUrl(result.data))
                is AppResult.Failure -> _emit(DetailEffect.Message(result.error.userMessage))
            }
        }
    }

    fun openExternal(url: String) {
        if (url.isBlank()) return
        _emit(DetailEffect.OpenUrl(url))
    }

    fun toggleFavorite(uid: String?) {
        val item = _state.value.item ?: return
        if (uid == null) {
            _emit(DetailEffect.RequiresSignIn)
            return
        }
        viewModelScope.launch {
            val result = favoritesRepository.toggle(
                userId = uid,
                itemId = item.itemId,
                itemType = item.type,
                name = item.name,
                developerName = item.developerName,
                iconUrl = item.iconUrl,
                freeEnabled = item.freeEnabled,
                proEnabled = item.proEnabled
            )
            when (result) {
                is AppResult.Success -> _state.value = _state.value.copy(favorite = result.data)
                is AppResult.Failure -> _emit(DetailEffect.Message(result.error.userMessage))
            }
        }
    }

    fun submitReview(
        uid: String?,
        userName: String,
        userPhotoUrl: String,
        rating: Int,
        text: String
    ) {
        val item = _state.value.item ?: return
        if (uid == null) {
            _emit(DetailEffect.RequiresSignIn)
            return
        }
        if (rating !in 1..5) {
            _emit(DetailEffect.Message("Choose a rating from 1 to 5 stars."))
            return
        }
        viewModelScope.launch {
            val result = reviewRepository.submit(
                itemType = itemType,
                itemId = itemId,
                itemName = item.name,
                userId = uid,
                userName = userName.ifBlank { "User" },
                userPhotoUrl = userPhotoUrl,
                rating = rating,
                text = text,
                existingReviewId = _state.value.myReview?.reviewId
            )
            when (result) {
                is AppResult.Success -> {
                    _emit(DetailEffect.Message("Thanks, your review was saved."))
                    load(uid, _state.value.access.proDownloadUnlocked)
                }
                is AppResult.Failure -> _emit(DetailEffect.Message(result.error.userMessage))
            }
        }
    }

    fun deleteReview(uid: String?) {
        val review = _state.value.myReview ?: return
        viewModelScope.launch {
            val result = reviewRepository.delete(itemType, itemId, review.reviewId)
            when (result) {
                is AppResult.Success -> {
                    _emit(DetailEffect.Message("Your review was removed."))
                    load(uid, _state.value.access.proDownloadUnlocked)
                }
                is AppResult.Failure -> _emit(DetailEffect.Message(result.error.userMessage))
            }
        }
    }

    fun consumeEffect() {
        _effects.value = null
    }

    fun message(text: String) {
        _emit(DetailEffect.Message(text))
    }

    private fun _emit(effect: DetailEffect) {
        _effects.value = effect
    }

    /** Maps a download target to the action the screen should take. Used by tests and previews. */
    fun targetFor(access: DownloadAccess): DownloadTarget = access.primaryTarget
}
