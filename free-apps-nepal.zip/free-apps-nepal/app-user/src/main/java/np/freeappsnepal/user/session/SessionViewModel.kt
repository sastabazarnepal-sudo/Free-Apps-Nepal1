package np.freeappsnepal.user.session

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseUser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.AuthRepository
import np.freeappsnepal.core.data.repo.ServerClockRepository
import np.freeappsnepal.core.data.repo.SubscriptionRepository
import np.freeappsnepal.core.domain.ProState
import np.freeappsnepal.core.domain.ProStatus
import np.freeappsnepal.core.domain.SubscriptionEvaluator
import javax.inject.Inject

/** Everything the UI needs to know about the signed in user and their Pro entitlement. */
data class SessionState(
    val user: FirebaseUser? = null,
    val proStatus: ProStatus = ProStatus.INACTIVE,
    val serverNowMillis: Long = System.currentTimeMillis(),
    val loading: Boolean = true
) {
    val isSignedIn: Boolean get() = user != null
    val isPro: Boolean get() = proStatus.isActive
    val proState: ProState get() = proStatus.state
    val hasEverHadPro: Boolean get() = SubscriptionEvaluator.everActive(proStatus)
    val uid: String? get() = user?.uid
}

/**
 * Holds the signed in user, the trusted server clock and the derived Pro entitlement.
 *
 * Pro is a function of the backend written `userSubscriptions` document plus the trusted clock, so
 * the entitlement can never be produced by local state. A user change or an explicit refresh
 * re-reads both and republishes, and every screen that collects this state re-renders.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class SessionViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val subscriptionRepository: SubscriptionRepository,
    private val serverClockRepository: ServerClockRepository
) : ViewModel() {

    private val _refreshTrigger = MutableStateFlow(0)

    val state: StateFlow<SessionState> =
        combine(authRepository.currentUser, _refreshTrigger) { user, trigger -> user to trigger }
            .flatMapLatest { (user, _) -> entitlement(user) }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5_000),
                initialValue = SessionState()
            )

    private fun entitlement(user: FirebaseUser?) = flow {
        emit(SessionState(user = user, loading = true))
        if (user == null) {
            emit(SessionState(user = null, proStatus = ProStatus.INACTIVE, loading = false))
            return@flow
        }
        val deviceNow = System.currentTimeMillis()
        val clock = serverClockRepository.serverClock()
        val serverNow = clock.now(deviceNow)
        val status = subscriptionRepository.proStatus(user.uid, serverNow).getOrNull()
            ?: ProStatus.INACTIVE
        emit(
            SessionState(
                user = user,
                proStatus = status,
                serverNowMillis = serverNow,
                loading = false
            )
        )
    }

    /**
     * Re-reads the server clock and the entitlement. Called after a payment attempt returns and when
     * the user pulls to refresh on the subscription screen.
     */
    fun refresh() {
        viewModelScope.launch {
            serverClockRepository.serverClock(forceRefresh = true)
            _refreshTrigger.value += 1
        }
    }

    fun signOut() {
        authRepository.signOut()
    }

    fun checkAdminClaim(onResult: (Boolean) -> Unit) {
        viewModelScope.launch { onResult(authRepository.hasAdminClaim()) }
    }
}
