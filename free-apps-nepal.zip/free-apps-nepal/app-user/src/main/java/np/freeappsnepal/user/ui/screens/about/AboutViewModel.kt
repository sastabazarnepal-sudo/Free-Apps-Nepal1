package np.freeappsnepal.user.ui.screens.about

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.SettingsRepository
import javax.inject.Inject

@HiltViewModel
class AboutViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val appName: String = "Free Apps Nepal",
        val aboutText: String = "",
        val supportEmail: String = "",
        val supportPhone: String = "",
        val versionName: String = ""
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            val settings = settingsRepository.appSettings().getOrNull()
            _state.value = State(
                loading = false,
                appName = settings?.appName?.ifBlank { "Free Apps Nepal" } ?: "Free Apps Nepal",
                aboutText = settings?.aboutText.orEmpty(),
                supportEmail = settings?.supportEmail.orEmpty(),
                supportPhone = settings?.supportPhone.orEmpty(),
                versionName = installedVersionName()
            )
        }
    }

    private fun installedVersionName(): String = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName.orEmpty()
    }.getOrDefault("")
}
