package np.freeappsnepal.user.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.AuthRepository
import np.freeappsnepal.core.data.repo.FavoritesRepository
import np.freeappsnepal.core.data.repo.ServerClockRepository
import np.freeappsnepal.core.data.repo.SubscriptionRepository
import np.freeappsnepal.core.domain.ProStatus
import np.freeappsnepal.core.domain.PriceQuote
import np.freeappsnepal.core.model.Order
import np.freeappsnepal.core.model.Plan
import np.freeappsnepal.core.model.Subscription
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject

data class ProfileUiState(
    val loading: Boolean = true,
    val plan: Plan? = null,
    val quote: PriceQuote? = null,
    val proStatus: ProStatus? = null,
    val subscriptions: List<Subscription> = emptyList(),
    val orders: List<Order> = emptyList(),
    val errorMessage: String? = null
)

/**
 * Profile, subscription and payment history.
 *
 * The Pro panel here is driven entirely by the backend written `userSubscriptions` document,
 * evaluated against the trusted clock, so it shows inactive, active with an expiry date, or expired
 * exactly as the backend sees it.
 */
@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val subscriptionRepository: SubscriptionRepository,
    private val favoritesRepository: FavoritesRepository,
    private val serverClockRepository: ServerClockRepository
) : ViewModel() {

    private val _state = MutableStateFlow(ProfileUiState())
    val state: StateFlow<ProfileUiState> = _state.asStateFlow()

    fun load(uid: String?) {
        if (uid == null) {
            _state.value = ProfileUiState(loading = false)
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            val clock = serverClockRepository.serverClock()
            val serverNow = clock.now(System.currentTimeMillis())

            val planDeferred = async { subscriptionRepository.plan() }
            val quoteDeferred = async { subscriptionRepository.quote(serverNowMillis = serverNow) }
            val statusDeferred = async { subscriptionRepository.proStatus(uid, serverNow) }
            val subscriptionsDeferred = async { subscriptionRepository.history(uid) }
            val ordersDeferred = async { subscriptionRepository.paymentHistory(uid) }

            val planResult = planDeferred.await()
            val quoteResult = quoteDeferred.await()
            val statusResult = statusDeferred.await()
            val error = sequenceOf(planResult, quoteResult, statusResult)
                .mapNotNull { (it as? AppResult.Failure)?.error?.userMessage }
                .firstOrNull()

            _state.value = ProfileUiState(
                loading = false,
                plan = planResult.getOrNull(),
                quote = quoteResult.getOrNull(),
                proStatus = statusResult.getOrNull(),
                subscriptions = subscriptionsDeferred.await().getOrNull().orEmpty(),
                orders = ordersDeferred.await().getOrNull().orEmpty(),
                errorMessage = error
            )
        }
    }

    fun signOut() {
        authRepository.signOut()
    }
}
