package np.freeappsnepal.user.ui.screens.list

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.DocumentSnapshot
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.CatalogRepository
import np.freeappsnepal.core.data.repo.ItemPage
import np.freeappsnepal.core.data.repo.NetworkMonitor
import np.freeappsnepal.core.domain.ListFilter
import np.freeappsnepal.core.domain.SearchFilter
import np.freeappsnepal.core.domain.SearchRequest
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.util.AppResult
import javax.inject.Inject

data class ItemsUiState(
    val loading: Boolean = true,
    val loadingMore: Boolean = false,
    val items: List<AppItem> = emptyList(),
    val filter: ListFilter = ListFilter.ALL,
    val hasMore: Boolean = false,
    val errorMessage: String? = null,
    val offline: Boolean = false,
    val title: String = "",
    val subtitle: String? = null
) {
    val isEmpty: Boolean get() = !loading && items.isEmpty()
}

/**
 * Paging list used by the Apps tab, the Games tab, a category, and the search result set.
 *
 * Cursor based paging loads one bounded page at a time, so the app never reads a whole collection.
 * Pro listings appear in every filter: the free/pro filters describe which version a listing offers,
 * not which users are allowed to see it.
 */
@HiltViewModel
class ItemsViewModel @Inject constructor(
    private val catalogRepository: CatalogRepository,
    private val networkMonitor: NetworkMonitor
) : ViewModel() {

    private val _state = MutableStateFlow(ItemsUiState())
    val state: StateFlow<ItemsUiState> = _state.asStateFlow()

    private var scope: LoadScope? = null
    private var loadJob: Job? = null
    private var lastDocument: DocumentSnapshot? = null

    /** Called once per screen with the fixed query scope for that screen. */
    fun start(
        title: String,
        subtitle: String?,
        type: ItemType?,
        categoryId: String?,
        categoryName: String?
    ) {
        val fingerprint = "$title|$categoryId|${type?.name}"
        if (scope?.fingerprint == fingerprint) return
        scope = LoadScope(fingerprint, type, categoryId, categoryName)
        _state.value = ItemsUiState(title = title, subtitle = subtitle, loading = true)
        reload()
    }

    fun setFilter(filter: ListFilter) {
        if (_state.value.filter == filter) return
        _state.value = _state.value.copy(filter = filter)
        reload()
    }

    fun refresh() {
        _state.value = _state.value.copy(offline = !networkMonitor.currentlyOnline())
        reload()
    }

    fun loadMore() {
        val current = _state.value
        val activeScope = scope ?: return
        if (current.loading || current.loadingMore || !current.hasMore) return

        viewModelScope.launch {
            _state.value = current.copy(loadingMore = true)
            val page = fetchPage(activeScope, current.filter, lastDocument)
            when (page) {
                is AppResult.Success -> {
                    lastDocument = page.data.lastDocument
                    val existingKeys = _state.value.items.map { it.type.name + it.itemId }.toSet()
                    val appended = page.data.items.filterNot {
                        existingKeys.contains(it.type.name + it.itemId)
                    }
                    _state.value = _state.value.copy(
                        loadingMore = false,
                        items = _state.value.items + appended,
                        hasMore = page.data.hasMore
                    )
                }
                is AppResult.Failure -> _state.value = _state.value.copy(
                    loadingMore = false,
                    errorMessage = page.error.userMessage
                )
            }
        }
    }

    private fun reload() {
        val activeScope = scope ?: return
        loadJob?.cancel()
        lastDocument = null
        loadJob = viewModelScope.launch {
            val page = fetchPage(activeScope, _state.value.filter, null)
            when (page) {
                is AppResult.Success -> {
                    lastDocument = page.data.lastDocument
                    _state.value = _state.value.copy(
                        loading = false,
                        loadingMore = false,
                        items = page.data.items,
                        hasMore = page.data.hasMore,
                        errorMessage = null,
                        offline = !networkMonitor.currentlyOnline()
                    )
                }
                is AppResult.Failure -> _state.value = _state.value.copy(
                    loading = false,
                    loadingMore = false,
                    errorMessage = page.error.userMessage,
                    offline = !networkMonitor.currentlyOnline()
                )
            }
        }
    }

    private suspend fun fetchPage(
        activeScope: LoadScope,
        filter: ListFilter,
        cursor: DocumentSnapshot?
    ): AppResult<ItemPage> {
        val categoryId = activeScope.categoryId
        if (categoryId != null) {
            // A category screen cannot combine the category filter with an offering filter in one
            // indexed query, so it merges a bounded first page per offering locally.
            val types = activeScope.type?.let { listOf(it) } ?: listOf(ItemType.APP, ItemType.GAME)
            val collected = LinkedHashMap<String, AppItem>()
            types.forEach { type ->
                catalogRepository.byCategory(type, categoryId).getOrNull()?.items
                    ?.forEach { collected[it.type.name + it.itemId] = it }
            }
            val filtered = collected.values.filter { item ->
                when (filter) {
                    ListFilter.FREE -> item.hasFree
                    ListFilter.PRO -> item.hasPro
                    ListFilter.ALL -> true
                }
            }
            return AppResult.Success(ItemPage(filtered, null, false))
        }

        val type = activeScope.type ?: return AppResult.Success(ItemPage.EMPTY)
        return when (filter) {
            ListFilter.ALL -> catalogRepository.page(type, startAfter = cursor)
            ListFilter.FREE ->
                catalogRepository.byOffering(type, freeOnly = true, startAfter = cursor)
            ListFilter.PRO ->
                catalogRepository.byOffering(type, freeOnly = false, startAfter = cursor)
        }
    }

    /** Search runs keyword queries instead of ordered pages, so it owns its own state update. */
    fun search(query: String, filter: SearchFilter) {
        loadJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.isBlank()) {
            scope = null
            _state.value = ItemsUiState(
                loading = false,
                title = "Search",
                subtitle = "Try an app name, game name, developer or category."
            )
            return
        }
        scope = null
        _state.value = _state.value.copy(loading = true, errorMessage = null)
        loadJob = viewModelScope.launch {
            val result = catalogRepository.search(
                SearchRequest(
                    query = trimmed,
                    filter = filter,
                    pageSize = PAGE_SIZE
                )
            )
            when (result) {
                is AppResult.Success -> _state.value = _state.value.copy(
                    loading = false,
                    items = result.data.items,
                    hasMore = false,
                    errorMessage = null,
                    title = "Results for \"$trimmed\"",
                    subtitle = null
                )
                is AppResult.Failure -> _state.value = _state.value.copy(
                    loading = false,
                    items = emptyList(),
                    errorMessage = result.error.userMessage
                )
            }
        }
    }

    private data class LoadScope(
        val fingerprint: String,
        val type: ItemType?,
        val categoryId: String?,
        val categoryName: String?
    )

    companion object {
        const val PAGE_SIZE = 20
    }
}
