package np.freeappsnepal.user.payment

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContract
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import org.json.JSONObject

/**
 * Hosts the payment provider page.
 *
 * The app only ever loads a URL that the backend produced after pricing the order, so the page and
 * the amount come from the server. The activity watches for the return deep link, then hands the
 * raw query back to the caller. Nothing here decides whether a payment succeeded: the caller
 * forwards the reference to the backend, which queries the provider.
 */
class PaymentWebActivity : ComponentActivity() {

    private var webView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val paymentUrl = intent.getStringExtra(EXTRA_URL).orEmpty()
        val fields = readFormFields(intent.getStringExtra(EXTRA_FORM_FIELDS))
        val method = intent.getStringExtra(EXTRA_METHOD).orEmpty()
        val returnScheme = intent.getStringExtra(EXTRA_RETURN_SCHEME).orEmpty()

        if (paymentUrl.isBlank()) {
            finishWithResult(null)
            return
        }

        setContent {
            var showProgress by remember { mutableStateOf(true) }

            Surface(color = MaterialTheme.colorScheme.background) {
                Scaffold(
                    topBar = {
                        androidx.compose.material3.TopAppBar(title = { Text("Secure payment") })
                    }
                ) { padding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                    ) {
                        AndroidView(
                            factory = { context ->
                                WebView(context).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.cacheMode = WebSettings.LOAD_NO_CACHE
                                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                                    CookieManager.getInstance().setAcceptCookie(true)
                                    webViewClient = object : WebViewClient() {
                                        override fun onPageStarted(
                                            view: WebView?,
                                            url: String?,
                                            favicon: Bitmap?
                                        ) {
                                            showProgress = true
                                            if (isReturnUrl(url, returnScheme)) {
                                                view?.stopLoading()
                                                finishWithResult(url)
                                            }
                                        }

                                        override fun onPageFinished(view: WebView?, url: String?) {
                                            showProgress = false
                                        }

                                        override fun shouldOverrideUrlLoading(
                                            view: WebView?,
                                            request: WebResourceRequest?
                                        ): Boolean {
                                            val target = request?.url?.toString()
                                            if (isReturnUrl(target, returnScheme)) {
                                                finishWithResult(target)
                                                return true
                                            }
                                            return false
                                        }
                                    }
                                    webView = this

                                    if (method == POST_FORM && fields.isNotEmpty()) {
                                        val inputs = fields.entries.joinToString("") { (key, value) ->
                                            val safeKey = escape(key)
                                            val safeValue = escape(value)
                                            "<input type=\"hidden\" name=\"$safeKey\" value=\"$safeValue\"/>"
                                        }
                                        val html = """
                                            <!doctype html><html><body>
                                            <form id="f" method="post" action="${escape(paymentUrl)}">
                                            $inputs
                                            </form>
                                            <script>document.getElementById('f').submit();</script>
                                            </body></html>
                                        """.trimIndent()
                                        loadDataWithBaseURL(paymentUrl, html, "text/html", "utf-8", null)
                                    } else {
                                        loadUrl(paymentUrl)
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        if (showProgress) {
                            CircularProgressIndicator(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 12.dp)
                            )
                        }
                    }
                }
            }
        }

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    // Leaving the provider page without completing it is not an error. The order
                    // simply stays pending until the daily reconciliation marks it cancelled.
                    finishWithResult(null)
                }
            }
        )
    }

    private fun finishWithResult(returnedUrl: String?) {
        val query = returnedUrl?.substringAfter("?", "") ?: ""
        setResult(
            RESULT_OK,
            Intent().putExtra(RESULT_QUERY, query).putExtra(RESULT_RETURNED_URL, returnedUrl)
        )
        finish()
    }

    private fun isReturnUrl(url: String?, returnScheme: String): Boolean {
        val target = url ?: return false
        if (returnScheme.isBlank()) {
            return target.contains("/payment/") && (target.contains("success") || target.contains("failure"))
        }
        return target.startsWith("$returnScheme://") || target.startsWith("$returnScheme:")
    }

    private fun readFormFields(raw: String?): Map<String, String> {
        if (raw.isNullOrBlank()) return emptyMap()
        return runCatching {
            val json = JSONObject(raw)
            json.keys().asSequence().associateWith { key -> json.optString(key) }
        }.getOrDefault(emptyMap())
    }

    private fun escape(value: String): String =
        value.replace("&", "&amp;")
            .replace("\"", "&quot;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")

    override fun onDestroy() {
        webView?.let { view ->
            view.loadUrl("about:blank")
            view.destroy()
        }
        webView = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_METHOD = "extra_method"
        const val EXTRA_FORM_FIELDS = "extra_form_fields"
        const val EXTRA_RETURN_SCHEME = "extra_return_scheme"
        const val RESULT_QUERY = "result_query"
        const val RESULT_RETURNED_URL = "result_returned_url"

        const val POST_FORM = "POST_FORM"
        const val GET_REDIRECT = "GET_REDIRECT"

        fun intent(context: Context, request: PaymentRequest): Intent {
            val json = JSONObject()
            request.formFields.forEach { (key, value) -> json.put(key, value) }
            return Intent(context, PaymentWebActivity::class.java)
                .putExtra(EXTRA_URL, request.url)
                .putExtra(EXTRA_METHOD, request.method)
                .putExtra(EXTRA_FORM_FIELDS, json.toString())
                .putExtra(EXTRA_RETURN_SCHEME, request.returnScheme)
        }
    }
}

/** Input for the payment activity result contract. */
data class PaymentRequest(
    val url: String,
    val method: String,
    val formFields: Map<String, String>,
    val returnScheme: String
)

/** Activity result contract so the Pro screen can await the payment page outcome. */
class PaymentContract : ActivityResultContract<PaymentRequest, PaymentResult>() {
    override fun createIntent(context: Context, input: PaymentRequest): Intent =
        PaymentWebActivity.intent(context, input)

    override fun parseResult(resultCode: Int, intent: Intent?): PaymentResult {
        val query = intent?.getStringExtra(PaymentWebActivity.RESULT_QUERY).orEmpty()
        val returnedUrl = intent?.getStringExtra(PaymentWebActivity.RESULT_RETURNED_URL)
        return PaymentResult(query = query, returnedUrl = returnedUrl, completed = query.isNotBlank())
    }
}

data class PaymentResult(
    val query: String,
    val returnedUrl: String?,
    val completed: Boolean
)
