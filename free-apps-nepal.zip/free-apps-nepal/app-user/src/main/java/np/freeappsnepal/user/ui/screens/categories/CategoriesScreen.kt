package np.freeappsnepal.user.ui.screens.categories

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import np.freeappsnepal.core.data.repo.CategoryRepository
import np.freeappsnepal.core.data.repo.NetworkMonitor
import np.freeappsnepal.core.model.Category
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.common.OfflineState
import np.freeappsnepal.user.ui.screens.list.CatalogListScreen
import javax.inject.Inject

/** Categories are administrator managed, so this screen renders whatever the backend currently has. */
@HiltViewModel
class CategoriesViewModel @Inject constructor(
    private val categoryRepository: CategoryRepository,
    private val networkMonitor: NetworkMonitor
) : ViewModel() {

    data class State(
        val loading: Boolean = true,
        val categories: List<Category> = emptyList(),
        val offline: Boolean = false,
        val errorMessage: String? = null
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = _state.value.categories.isEmpty())
            val result = categoryRepository.enabledCategories()
            _state.value = when (result) {
                is np.freeappsnepal.core.util.AppResult.Success -> State(
                    loading = false,
                    categories = result.data,
                    offline = !networkMonitor.currentlyOnline()
                )
                is np.freeappsnepal.core.util.AppResult.Failure -> State(
                    loading = false,
                    categories = _state.value.categories,
                    offline = !networkMonitor.currentlyOnline(),
                    errorMessage = result.error.userMessage
                )
            }
        }
    }
}

@Composable
fun CategoriesScreen(
    onOpenCategory: (String, String) -> Unit,
    viewModel: CategoriesViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(text = "Categories", style = MaterialTheme.typography.headlineSmall)
            Text(
                text = "Browse apps and games by category",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        when {
            state.loading -> LoadingState()
            state.categories.isEmpty() && state.offline -> OfflineState(onRetry = viewModel::load)
            state.categories.isEmpty() -> EmptyState(
                title = "No categories yet",
                subtitle = "The administrator has not published any categories."
            )
            else -> LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items = state.categories, key = { it.categoryId }) { category ->
                    CategoryCard(
                        category = category,
                        onClick = { onOpenCategory(category.categoryId, category.name) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryCard(category: Category, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = category.name, style = MaterialTheme.typography.titleMedium)
            if (category.description.isNotBlank()) {
                Text(
                    text = category.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

@Composable
fun CategoryItemsScreen(
    categoryId: String,
    categoryName: String,
    onOpenItem: (np.freeappsnepal.core.model.ItemType, String) -> Unit,
    onBack: () -> Unit
) {
    val decodedName = runCatching {
        java.net.URLDecoder.decode(categoryName, "UTF-8")
    }.getOrDefault(categoryName)

    CatalogListScreen(
        title = decodedName,
        subtitle = "Category",
        type = null,
        categoryId = categoryId,
        categoryName = decodedName,
        onOpenItem = onOpenItem,
        onBack = onBack,
        showFilters = true
    )
}
