package np.freeappsnepal.user.payment

import android.os.Bundle
import androidx.activity.ComponentActivity

/**
 * Entry point for the return deep links that the payment providers redirect to.
 *
 * The provider sends the user back here, either because they paid or because they cancelled. This
 * activity reads the reference and forwards it to [PaymentReturnBus] so the payment screen can
 * verify it. It never marks anything as paid. Verification is a backend call against the provider.
 */
class PaymentReturnActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = intent?.data
        val query = data?.query.orEmpty()
        val orderId = data?.getQueryParameter("orderId")
            ?: data?.getQueryParameter("purchase_order_id")
            ?: data?.getQueryParameter("transaction_uuid")
            ?: data?.getQueryParameter("pidx")

        if (!orderId.isNullOrBlank()) {
            PaymentReturnBus.publish(
                PaymentReturn(
                    orderId = orderId,
                    rawQuery = query,
                    encodedEsewaResponse = data?.getQueryParameter("data")
                )
            )
        }
        finish()
    }
}

data class PaymentReturn(
    val orderId: String,
    val rawQuery: String,
    val encodedEsewaResponse: String?
)

/**
 * A minimal one event bus between the deep link activity and the payment screen.
 *
 * The activity and the screen are not in the same task in every case, so a shared singleton with a
 * single slot is simpler and safer than a broadcast, and it cannot leak: it holds at most one
 * pending return and it is cleared as soon as it is consumed.
 */
object PaymentReturnBus {
    @Volatile
    private var pending: PaymentReturn? = null

    fun publish(value: PaymentReturn) {
        pending = value
    }

    fun consume(): PaymentReturn? {
        val current = pending
        pending = null
        return current
    }

    fun peek(): PaymentReturn? = pending
}
