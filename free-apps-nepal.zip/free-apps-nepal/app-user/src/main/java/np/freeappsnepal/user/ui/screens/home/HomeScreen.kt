package np.freeappsnepal.user.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import np.freeappsnepal.core.model.AppItem
import np.freeappsnepal.core.model.ItemType
import np.freeappsnepal.core.model.Promotion
import np.freeappsnepal.core.ui.common.EmptyState
import np.freeappsnepal.core.ui.common.LoadingState
import np.freeappsnepal.core.ui.common.OfflineState
import np.freeappsnepal.core.ui.components.ItemListSection
import np.freeappsnepal.core.ui.components.ItemRowSection
import np.freeappsnepal.core.ui.theme.FanColors
import np.freeappsnepal.core.util.LinkOpener
import np.freeappsnepal.user.session.SessionState
import androidx.compose.ui.platform.LocalContext

@Composable
fun HomeScreen(
    session: SessionState,
    onOpenItem: (ItemType, String) -> Unit,
    onOpenCategories: () -> Unit,
    onOpenPro: () -> Unit,
    onOpenSearch: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    when {
        state.loading -> LoadingState(label = "Loading Free Apps Nepal…")
        state.offline && state.isEmpty -> OfflineState(onRetry = viewModel::refresh)
        state.isEmpty && state.errorMessage != null ->
            EmptyState(title = state.errorMessage.orEmpty())
        else -> LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                HomeHeader(isPro = session.isPro, onOpenPro = onOpenPro, onOpenSearch = onOpenSearch)
            }

            // The banner is emitted only when an administrator configured an enabled promotion that
            // is inside its date window. There is deliberately no placeholder item here, so a
            // disabled promotion leaves no blank space behind.
            val promotion = state.promotion
            if (promotion != null) {
                item(key = "promotion_${promotion.promotionId}") {
                    PromotionBanner(
                        promotion = promotion,
                        onOpen = { LinkOpener.open(context, promotion.buttonUrl) }
                    )
                }
            }

            if (state.proUnavailable.not()) {
                item(key = "pro_cta") {
                    ProCallToAction(isPro = session.isPro, onOpenPro = onOpenPro)
                }
            }

            item(key = "quick_categories") {
                CategoryShortcutRow(onOpenCategories = onOpenCategories, onOpenSearch = onOpenSearch)
            }

            item(key = "featured_apps") {
                ItemRowSection(
                    title = "Featured Apps",
                    items = state.featuredApps,
                    onOpenItem = { onOpenItem(ItemType.APP, it.itemId) }
                )
            }
            item(key = "latest_apps") {
                ItemRowSection(
                    title = "Latest Apps",
                    items = state.latestApps,
                    onOpenItem = { onOpenItem(ItemType.APP, it.itemId) }
                )
            }
            item(key = "popular_apps") {
                ItemRowSection(
                    title = "Popular Apps",
                    items = state.popularApps,
                    onOpenItem = { onOpenItem(ItemType.APP, it.itemId) }
                )
            }
            item(key = "featured_games") {
                ItemRowSection(
                    title = "Featured Games",
                    items = state.featuredGames,
                    onOpenItem = { onOpenItem(ItemType.GAME, it.itemId) }
                )
            }
            item(key = "latest_games") {
                ItemRowSection(
                    title = "Latest Games",
                    items = state.latestGames,
                    onOpenItem = { onOpenItem(ItemType.GAME, it.itemId) }
                )
            }
            item(key = "popular_games") {
                ItemRowSection(
                    title = "Popular Games",
                    items = state.popularGames,
                    onOpenItem = { onOpenItem(ItemType.GAME, it.itemId) }
                )
            }
            item(key = "free_apps") {
                ItemListSection(
                    title = "Free Apps",
                    subtitle = "Free download available to everyone",
                    items = state.freeApps,
                    onOpenItem = { onOpenItem(ItemType.APP, it.itemId) }
                )
            }
            item(key = "pro_apps") {
                ItemListSection(
                    title = "Pro Apps",
                    subtitle = "Included with the monthly Pro subscription",
                    items = state.proApps,
                    onOpenItem = { onOpenItem(ItemType.APP, it.itemId) }
                )
            }
            item(key = "free_games") {
                ItemListSection(
                    title = "Free Games",
                    items = state.freeGames,
                    onOpenItem = { onOpenItem(ItemType.GAME, it.itemId) }
                )
            }
            item(key = "pro_games") {
                ItemListSection(
                    title = "Pro Games",
                    subtitle = "Included with the monthly Pro subscription",
                    items = state.proGames,
                    onOpenItem = { onOpenItem(ItemType.GAME, it.itemId) }
                )
            }
            item(key = "footer") { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun HomeHeader(isPro: Boolean, onOpenPro: () -> Unit, onOpenSearch: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primary)
            .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Free Apps Nepal",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isPro) "Pro member • all Pro apps and games unlocked"
                    else "Discover free and Pro apps and games",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f)
                )
            }
            if (isPro) {
                Icon(
                    Icons.Filled.WorkspacePremium,
                    contentDescription = "Pro member",
                    tint = FanColors.GoldBright,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 14.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surface)
                .clickable(onClick = onOpenSearch)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.Star,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = "Search apps, games, developers",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (!isPro) {
            TextButton(onClick = onOpenPro, modifier = Modifier.padding(top = 4.dp)) {
                Text(
                    text = "Get Pro",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PromotionBanner(promotion: Promotion, onOpen: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clip(MaterialTheme.shapes.medium)
            .background(FanColors.GoldSurface)
    ) {
        if (promotion.imageUrl.isNotBlank()) {
            AsyncImage(
                model = promotion.imageUrl,
                contentDescription = promotion.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            )
        }
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = promotion.title,
                style = MaterialTheme.typography.titleMedium,
                color = FanColors.GoldOn
            )
            if (promotion.shortDescription.isNotBlank()) {
                Text(
                    text = promotion.shortDescription,
                    style = MaterialTheme.typography.bodyMedium,
                    color = FanColors.GoldOn.copy(alpha = 0.85f),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            if (promotion.buttonText.isNotBlank() && promotion.buttonUrl.isNotBlank()) {
                Button(
                    onClick = onOpen,
                    modifier = Modifier.padding(top = 10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FanColors.Gold,
                        contentColor = FanColors.GoldOn
                    )
                ) {
                    Text(promotion.buttonText, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ProCallToAction(isPro: Boolean, onOpenPro: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .clip(MaterialTheme.shapes.medium)
            .background(if (isPro) FanColors.GoldSurface else MaterialTheme.colorScheme.primaryContainer)
            .clickable(onClick = onOpenPro)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.WorkspacePremium,
            contentDescription = null,
            tint = if (isPro) FanColors.Gold else MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (isPro) "Your Pro subscription is active" else "Unlock every Pro app and game",
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = if (isPro) "Open Pro downloads directly, with no extra ad or payment"
                else "One monthly subscription. No per app purchase.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CategoryShortcutRow(onOpenCategories: () -> Unit, onOpenSearch: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Button(
            onClick = onOpenCategories,
            modifier = Modifier.weight(1f)
        ) {
            Icon(Icons.Filled.CardGiftcard, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Categories")
        }
        Button(
            onClick = onOpenSearch,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            )
        ) {
            Text("Search")
        }
    }
}
