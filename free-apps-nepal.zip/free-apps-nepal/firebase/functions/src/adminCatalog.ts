import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import { REGION, COLLECTIONS, DEFAULT_PLAN_ID } from "./config";
import { requireAdmin, db, FieldValue, computePrice } from "./firebase";

interface UpsertItemPayload {
  /** Present when editing, absent when creating. */
  itemId?: string;
  itemType?: string;
  name?: string;
  developerName?: string;
  iconUrl?: string;
  screenshots?: string[];
  description?: string;
  categoryId?: string;
  categoryName?: string;
  version?: string;
  fileSize?: string;
  minAndroidVersion?: string;
  whatsNew?: string;
  freeEnabled?: boolean;
  freeDownloadUrl?: string;
  proEnabled?: boolean;
  /** Stored only in secureLinks, never on the public listing document. */
  proDownloadUrl?: string;
  featured?: boolean;
  popular?: boolean;
  isNew?: boolean;
  published?: boolean;
}

/**
 * Creates or updates a listing.
 *
 * The Pro download URL is split out and written to `secureLinks/{itemId}`, a collection that no
 * client can read. The public document keeps only `proEnabled`, so the catalogue can advertise the
 * Pro version to everyone without exposing the destination URL to everyone.
 */
export const upsertItem = onCall(
  { region: REGION },
  async (request: CallableRequest<UpsertItemPayload>) => {
    const uid = requireAdmin(request);
    const data = request.data ?? {};
    const itemType = String(data.itemType ?? "APP").toUpperCase();
    if (itemType !== "APP" && itemType !== "GAME") {
      throw new HttpsError("invalid-argument", "Unknown item type.");
    }
    const name = String(data.name ?? "").trim();
    if (!name) {
      throw new HttpsError("invalid-argument", "A name is required.");
    }

    const submittedProUrl = String(data.proDownloadUrl ?? "").trim();
    if (data.freeEnabled === true && !isValidUrl(data.freeDownloadUrl)) {
      throw new HttpsError("invalid-argument", "The Free download URL is not valid.");
    }
    // A Pro listing must either carry a new Pro URL or already have one stored. The stored URL is
    // never returned to the admin client, so a re-save without retyping it keeps the existing link
    // instead of erroring on a field the editor never received.
    if (data.proEnabled === true && !isValidUrl(submittedProUrl)) {
      const existingProLink = await db
        .collection(COLLECTIONS.secureLinks)
        .doc(String(data.itemId ?? ""))
        .get();
      const storedProUrl = String(existingProLink.get("proDownloadUrl") ?? "").trim();
      if (!isValidUrl(storedProUrl)) {
        throw new HttpsError(
          "invalid-argument",
          "The Pro download URL is required when the Pro version is enabled."
        );
      }
    }

    const collection = itemType === "GAME" ? COLLECTIONS.games : COLLECTIONS.apps;
    const itemId = (data.itemId ?? "").toString().trim();
    const itemRef = itemId
      ? db.collection(collection).doc(itemId)
      : db.collection(collection).doc();
    const existing = await itemRef.get();
    const isNewDocument = !existing.exists;

    const keywords = buildKeywords(name, String(data.developerName ?? ""), String(data.categoryName ?? ""));

    const payload: Record<string, unknown> = {
      itemId: itemRef.id,
      type: itemType,
      name,
      nameLower: name.toLowerCase(),
      developerName: String(data.developerName ?? "").trim(),
      iconUrl: String(data.iconUrl ?? "").trim(),
      screenshots: sanitiseList(data.screenshots),
      description: String(data.description ?? ""),
      categoryId: String(data.categoryId ?? ""),
      categoryName: String(data.categoryName ?? ""),
      version: String(data.version ?? ""),
      fileSize: String(data.fileSize ?? ""),
      minAndroidVersion: String(data.minAndroidVersion ?? ""),
      whatsNew: String(data.whatsNew ?? ""),
      freeEnabled: data.freeEnabled === true,
      freeDownloadUrl: String(data.freeDownloadUrl ?? "").trim(),
      proEnabled: data.proEnabled === true,
      featured: data.featured === true,
      popular: data.popular === true,
      isNew: data.isNew === true,
      published: data.published === true,
      searchKeywords: keywords,
      updatedBy: uid,
      updatedAt: FieldValue.serverTimestamp(),
    };

    if (isNewDocument) {
      payload.createdAt = FieldValue.serverTimestamp();
      payload.lastUpdated = FieldValue.serverTimestamp();
      payload.viewCount = 0;
      payload.freeDownloadClickCount = 0;
      payload.proDownloadClickCount = 0;
      payload.ratingSum = 0;
      payload.ratingCount = 0;
      payload.reviewCount = 0;
    } else {
      payload.lastUpdated = FieldValue.serverTimestamp();
    }

    await itemRef.set(payload, { merge: true });

    if (data.proEnabled === true && isValidUrl(submittedProUrl)) {
      await db.collection(COLLECTIONS.secureLinks).doc(itemRef.id).set(
        {
          itemId: itemRef.id,
          itemType,
          proDownloadUrl: submittedProUrl,
          updatedBy: uid,
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    } else if (data.proEnabled === false) {
      await db.collection(COLLECTIONS.secureLinks).doc(itemRef.id).delete().catch(() => undefined);
    }

    return { itemId: itemRef.id, itemType, created: isNewDocument };
  }
);

/** Deletes a listing together with its secure link. Reviews are removed by the delete trigger. */
export const deleteItem = onCall(
  { region: REGION },
  async (request: CallableRequest<{ itemId?: string; itemType?: string }>) => {
    requireAdmin(request);
    const itemId = (request.data?.itemId ?? "").toString();
    const itemType = (request.data?.itemType ?? "APP").toString().toUpperCase();
    if (!itemId) {
      throw new HttpsError("invalid-argument", "An item id is required.");
    }
    const collection = itemType === "GAME" ? COLLECTIONS.games : COLLECTIONS.apps;
    await db.collection(collection).doc(itemId).delete();
    await db.collection(COLLECTIONS.secureLinks).doc(itemId).delete().catch(() => undefined);
    return { itemId, deleted: true };
  }
);

/**
 * Returns the stored Pro URL so the editor can show whether one is configured and let the
 * administrator verify it. It is a callable rather than a direct read because `secureLinks` is
 * denied to every client by the security rules.
 */
export const getProLinkForAdmin = onCall(
  { region: REGION },
  async (request: CallableRequest<{ itemId?: string }>) => {
    requireAdmin(request);
    const itemId = (request.data?.itemId ?? "").toString().trim();
    if (!itemId) {
      return { itemId: "", proDownloadUrl: "", configured: false };
    }
    const snapshot = await db.collection(COLLECTIONS.secureLinks).doc(itemId).get();
    const proDownloadUrl = String(snapshot.get("proDownloadUrl") ?? "").trim();
    return { itemId, proDownloadUrl, configured: proDownloadUrl.length > 0 };
  }
);

interface PlanPayload {
  planId?: string;
  name?: string;
  description?: string;
  pricePaisa?: number;
  durationDays?: number;
  enabled?: boolean;
  benefits?: string[];
  discountEnabled?: boolean;
  discountPercentage?: number;
  discountStartAt?: number | null;
  discountEndAt?: number | null;
}

/**
 * Updates the Pro plan.
 *
 * Everything that determines the price is written here and is therefore owned by the server. The
 * caller cannot influence the price of an individual purchase by anything it sends at payment time.
 */
export const upsertPlan = onCall(
  { region: REGION },
  async (request: CallableRequest<PlanPayload>) => {
    const uid = requireAdmin(request);
    const data = request.data ?? {};
    const planId = String(data.planId ?? DEFAULT_PLAN_ID);
    const pricePaisa = Math.max(0, Math.round(Number(data.pricePaisa ?? 0)));
    const durationDays = Math.max(1, Math.round(Number(data.durationDays ?? 30)));
    const percentage = Math.min(100, Math.max(0, Number(data.discountPercentage ?? 0)));

    if (data.discountEnabled === true && percentage <= 0) {
      throw new HttpsError(
        "invalid-argument",
        "A discount percentage greater than zero is required when the discount is enabled."
      );
    }
    if (
      typeof data.discountStartAt === "number" &&
      typeof data.discountEndAt === "number" &&
      data.discountEndAt < data.discountStartAt
    ) {
      throw new HttpsError("invalid-argument", "The discount end date is before the start date.");
    }

    const payload: Record<string, unknown> = {
      planId,
      name: String(data.name ?? "Free Apps Nepal Pro"),
      description: String(data.description ?? ""),
      currency: "NPR",
      pricePaisa,
      durationDays,
      enabled: data.enabled !== false,
      benefits: sanitiseList(data.benefits),
      discountEnabled: data.discountEnabled === true,
      discountPercentage: data.discountEnabled === true ? percentage : 0,
      discountStartAt: toTimestamp(data.discountStartAt),
      discountEndAt: toTimestamp(data.discountEndAt),
      updatedBy: uid,
      updatedAt: FieldValue.serverTimestamp(),
    };

    await db.collection(COLLECTIONS.plans).doc(planId).set(payload, { merge: true });
    return computePrice(planId);
  }
);

function toTimestamp(value: number | null | undefined): Date | null {
  if (value === null || value === undefined) return null;
  if (!Number.isFinite(value) || value <= 0) return null;
  return new Date(value);
}

function isValidUrl(value: unknown): boolean {
  const text = String(value ?? "").trim();
  return /^https?:\/\/[^\s]+$/i.test(text);
}

function sanitiseList(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((entry) => String(entry).trim())
    .filter((entry) => entry.length > 0)
    .slice(0, 20);
}

function buildKeywords(name: string, developer: string, category: string): string[] {
  const tokens = new Set<string>();
  const add = (value: string): void => {
    const normalised = value.trim().toLowerCase();
    if (!normalised) return;
    tokens.add(normalised);
    for (const word of normalised.split(" ")) {
      if (word.length >= 2) tokens.add(word);
    }
    const limit = Math.min(normalised.length, 12);
    for (let index = 2; index <= limit; index += 1) {
      tokens.add(normalised.substring(0, index));
    }
  };
  add(name);
  add(developer);
  add(category);
  return Array.from(tokens).slice(0, 120);
}
