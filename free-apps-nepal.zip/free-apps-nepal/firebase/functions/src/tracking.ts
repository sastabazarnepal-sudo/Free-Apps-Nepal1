import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import { REGION, COLLECTIONS, DEFAULT_PLAN_ID, dayKey } from "./config";
import { requireAuth, computePrice, db, FieldValue } from "./firebase";

interface TrackFreeDownloadPayload {
  itemId?: string;
  itemType?: string;
}

/**
 * Records that a user opened the administrator configured Free download URL, and returns that URL.
 *
 * The free link is stored on the public listing document because it is available to every user,
 * including users without a subscription. This endpoint returns exactly the stored string and the
 * client opens it unchanged: nothing is rewritten, proxied or redirected. Because the destination
 * is an external service, this records only the click. It never asserts that a file transfer
 * completed.
 */
export const trackFreeDownload = onCall(
  { region: REGION },
  async (request: CallableRequest<TrackFreeDownloadPayload>) => {
    const uid = requireAuth(request);
    const itemId = (request.data?.itemId ?? "").toString();
    const itemType = (request.data?.itemType ?? "APP").toString().toUpperCase();
    if (!itemId) {
      throw new HttpsError("invalid-argument", "An item id is required.");
    }
    if (itemType !== "APP" && itemType !== "GAME") {
      throw new HttpsError("invalid-argument", "Unknown item type.");
    }

    const collection = itemType === "GAME" ? COLLECTIONS.games : COLLECTIONS.apps;
    const itemRef = db.collection(collection).doc(itemId);
    const snapshot = await itemRef.get();
    if (!snapshot.exists) {
      throw new HttpsError("not-found", "This listing no longer exists.");
    }
    const item = snapshot.data() ?? {};
    if (item.published !== true || item.freeEnabled !== true) {
      throw new HttpsError("failed-precondition", "This listing has no Free version.");
    }
    const url = String(item.freeDownloadUrl ?? "").trim();
    if (!/^https?:\/\//i.test(url)) {
      throw new HttpsError("failed-precondition", "The Free download link is not valid.");
    }

    const today = dayKey();
    await db.collection(COLLECTIONS.downloadEvents).add({
      itemId,
      itemType,
      userId: uid,
      kind: "FREE",
      createdAt: new Date(),
    });

    const batch = db.batch();
    batch.set(itemRef, { freeDownloadClickCount: FieldValue.increment(1) }, { merge: true });
    batch.set(
      db.collection(COLLECTIONS.settings).doc("counters"),
      { freeDownloadClicks: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp() },
      { merge: true }
    );
    batch.set(
      db.collection(COLLECTIONS.statistics).doc(today),
      {
        date: today,
        freeDownloadClicks: FieldValue.increment(1),
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
    await batch.commit();

    return { itemId, itemType, url };
  }
);

/**
 * Returns the current Pro price for display.
 *
 * The client renders this quote but the amount charged is recomputed again when the order is
 * created, and the provider reported amount is compared against that recomputation.
 */
export const getPlanQuote = onCall(
  { region: REGION },
  async (request: CallableRequest<{ planId?: string }>) => {
    requireAuth(request);
    const planId = (request.data?.planId ?? DEFAULT_PLAN_ID).toString();
    return computePrice(planId);
  }
);

/**
 * Returns a trusted timestamp and persists it so the client can also read it from Firestore.
 * Subscription and discount countdowns use this value rather than the device clock.
 */
export const getServerTime = onCall(
  { region: REGION },
  async (request: CallableRequest) => {
    requireAuth(request);
    const millis = Date.now();
    await db.collection(COLLECTIONS.settings).doc("serverTime").set(
      {
        serverTime: new Date(millis),
        serverTimeMillis: millis,
        updatedAt: new Date(millis),
      },
      { merge: true }
    );
    return { serverTimeMillis: millis };
  }
);
