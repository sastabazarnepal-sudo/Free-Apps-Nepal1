import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import crypto from "node:crypto";
import {
  REGION,
  KHALTI_SECRET_KEY,
  KHALTI_BASE_URL,
  ESEWA_SECRET_KEY,
  ESEWA_PRODUCT_CODE,
  ESEWA_BASE_URL,
  DEFAULT_PLAN_ID,
  COLLECTIONS,
  nowMillis,
} from "./config";
import {
  requireAuth,
  computePrice,
  db,
  activateSubscription,
  markOrder,
  bumpPendingPayments,
  FieldValue,
} from "./firebase";

interface InitiatePayload {
  planId?: string;
  paymentMethod?: string;
  returnUrl?: string;
  websiteUrl?: string;
}

/**
 * Creates a payment order for the monthly Pro plan.
 *
 * The amount is computed here from the plan document. Whatever the client believes the price to be
 * is irrelevant: the request body only selects a plan id and a payment method.
 */
export const createProOrder = onCall(
  {
    region: REGION,
    secrets: [
      KHALTI_SECRET_KEY,
      KHALTI_BASE_URL,
      ESEWA_SECRET_KEY,
      ESEWA_PRODUCT_CODE,
      ESEWA_BASE_URL,
    ],
  },
  async (request: CallableRequest<InitiatePayload>) => {
    const uid = requireAuth(request);
    const planId = (request.data?.planId ?? DEFAULT_PLAN_ID).toString();
    const method = (request.data?.paymentMethod ?? "KHALTI").toString().toUpperCase();
    if (method !== "KHALTI" && method !== "ESEWA") {
      throw new HttpsError("invalid-argument", "Unsupported payment method.");
    }

    const price = await computePrice(planId, nowMillis());
    const orderRef = db.collection(COLLECTIONS.orders).doc();

    await orderRef.set({
      orderId: orderRef.id,
      userId: uid,
      planId,
      paymentMethod: method,
      originalPricePaisa: price.originalPricePaisa,
      discountPercentage: price.discountPercentage,
      amountPaisa: price.finalPricePaisa,
      currency: price.currency,
      status: "PENDING",
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });

    await bumpPendingPayments(1);

    if (method === "KHALTI") {
      const initiated = await initiateKhalti({
        orderId: orderRef.id,
        amountPaisa: price.finalPricePaisa,
        returnUrl: request.data?.returnUrl ?? "https://freeappsnepal.app/payment/khalti/callback",
        websiteUrl: request.data?.websiteUrl ?? "https://freeappsnepal.app",
        planName: price.planName,
      });
      await orderRef.set({ providerToken: initiated.pidx }, { merge: true });
      return {
        orderId: orderRef.id,
        paymentMethod: method,
        amountPaisa: price.finalPricePaisa,
        price,
        pidx: initiated.pidx,
        paymentUrl: initiated.paymentUrl,
      };
    }

    const esewa = await initiateEsewa({
      orderId: orderRef.id,
      amountPaisa: price.finalPricePaisa,
    });
    return {
      orderId: orderRef.id,
      paymentMethod: method,
      amountPaisa: price.finalPricePaisa,
      price,
      paymentUrl: esewa.paymentUrl,
      formFields: esewa.formFields,
    };
  }
);

async function initiateKhalti(params: {
  orderId: string;
  amountPaisa: number;
  returnUrl: string;
  websiteUrl: string;
  planName: string;
}): Promise<{ pidx: string; paymentUrl: string }> {
  const base = KHALTI_BASE_URL.value().replace(/\/$/, "");
  const response = await fetch(`${base}/epayment/initiate/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `key ${KHALTI_SECRET_KEY.value()}`,
    },
    body: JSON.stringify({
      return_url: params.returnUrl,
      website_url: params.websiteUrl,
      amount: params.amountPaisa,
      purchase_order_id: params.orderId,
      purchase_order_name: params.planName,
    }),
  });

  if (!response.ok) {
    await markOrder(params.orderId, "FAILED", {
      failureReason: `khalti_initiate_${response.status}`,
    });
    await bumpPendingPayments(-1);
    throw new HttpsError("internal", "Could not start the Khalti payment.");
  }

  const payload = (await response.json()) as { pidx?: string; payment_url?: string };
  if (!payload.pidx || !payload.payment_url) {
    await markOrder(params.orderId, "FAILED", { failureReason: "khalti_initiate_malformed" });
    await bumpPendingPayments(-1);
    throw new HttpsError("internal", "The Khalti response was incomplete.");
  }
  return { pidx: payload.pidx, paymentUrl: payload.payment_url };
}

async function initiateEsewa(params: {
  orderId: string;
  amountPaisa: number;
}): Promise<{ paymentUrl: string; formFields: Record<string, string> }> {
  const base = ESEWA_BASE_URL.value().replace(/\/$/, "");
  const productCode = ESEWA_PRODUCT_CODE.value();
  const totalAmount = (params.amountPaisa / 100).toFixed(2);
  const signedFieldNames = "total_amount,transaction_uuid,product_code";
  const signature = esewaSignature(
    `total_amount=${totalAmount},transaction_uuid=${params.orderId},product_code=${productCode}`,
    ESEWA_SECRET_KEY.value()
  );
  return {
    paymentUrl: `${base}/api/epay/main/v2/form`,
    formFields: {
      amount: totalAmount,
      tax_amount: "0",
      total_amount: totalAmount,
      transaction_uuid: params.orderId,
      product_code: productCode,
      product_service_charge: "0",
      product_delivery_charge: "0",
      success_url: "https://freeappsnepal.app/payment/esewa/success",
      failure_url: "https://freeappsnepal.app/payment/esewa/failure",
      signed_field_names: signedFieldNames,
      signature,
    },
  };
}

/**
 * eSewa v2 signs the concatenated values of the listed fields with HMAC SHA256 keyed by the
 * merchant secret, and base64 encodes the digest.
 */
export function esewaSignature(message: string, secret: string): string {
  return crypto.createHmac("sha256", secret).update(message).digest("base64");
}

/** Closes a paid order: activates the subscription and records the transaction. */
export async function finalisePaidOrder(params: {
  uid: string;
  orderId: string;
  transactionId: string;
  paidPaisa: number;
  referenceId: string;
}): Promise<{ subscriptionId: string; expiresAt: number }> {
  const orderRef = db.collection(COLLECTIONS.orders).doc(params.orderId);
  const orderSnapshot = await orderRef.get();
  if (!orderSnapshot.exists) {
    throw new HttpsError("not-found", "Unknown order.");
  }
  const order = orderSnapshot.data() ?? {};
  if (order.userId !== params.uid) {
    throw new HttpsError("permission-denied", "This order belongs to another account.");
  }

  const expected = Number(order.amountPaisa ?? -1);
  if (expected < 0 || params.paidPaisa < expected) {
    await markOrder(params.orderId, "FAILED", {
      failureReason: "amount_mismatch",
      providerTransactionId: params.transactionId,
    });
    throw new HttpsError(
      "invalid-argument",
      "The verified amount does not match the order amount."
    );
  }

  if (order.status === "ACTIVE" && order.subscriptionId) {
    return {
      subscriptionId: String(order.subscriptionId),
      expiresAt: Number(order.expiresAt ?? nowMillis()),
    };
  }

  const price = await computePrice(String(order.planId ?? DEFAULT_PLAN_ID), nowMillis());
  const subscriptionRef = db.collection(COLLECTIONS.subscriptions).doc();

  const activated = await activateSubscription({
    userId: params.uid,
    subscriptionId: subscriptionRef.id,
    planId: price.planId,
    planName: price.planName,
    originalPricePaisa: price.originalPricePaisa,
    discountPercentage: price.discountPercentage,
    paidPaisa: params.paidPaisa,
    currency: price.currency,
    paymentMethod: String(order.paymentMethod ?? "KHALTI"),
    transactionId: params.transactionId,
    orderId: params.orderId,
    durationDays: price.durationDays,
  });

  await markOrder(params.orderId, "ACTIVE", {
    subscriptionId: subscriptionRef.id,
    providerTransactionId: params.transactionId,
    providerReferenceId: params.referenceId,
    expiresAt: activated.expiresMillis,
  });

  return { subscriptionId: subscriptionRef.id, expiresAt: activated.expiresMillis };
}
