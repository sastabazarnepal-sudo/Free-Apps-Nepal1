import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import { auth } from "firebase-admin";
import { REGION, COLLECTIONS, DEFAULT_PLAN_ID } from "./config";
import { requireAdmin, db, FieldValue } from "./firebase";

interface GrantAdminPayload {
  /** The uid that should receive or lose the admin custom claim. */
  targetUid?: string;
  /** True to grant, false to revoke. */
  grant?: boolean;
}

/**
 * Grants or revokes the admin custom claim.
 *
 * Bootstrapping rule: if no administrator exists yet, the first caller becomes the owner and may
 * grant the claim to others. After that, only an existing administrator can change claims. This
 * avoids a hardcoded password and avoids trusting a client side email check, because the claim is
 * minted here and then enforced by security rules.
 */
export const setAdminClaim = onCall(
  { region: REGION },
  async (request: CallableRequest<GrantAdminPayload>) => {
    const uid = request.auth?.uid;
    if (!uid) {
      throw new HttpsError("unauthenticated", "Sign in is required to manage administrators.");
    }

    const existingAdmins = await countExistingAdmins();
    const isBootstrap = existingAdmins === 0;
    if (!isBootstrap) {
      requireAdmin(request);
    }

    const targetUid = (request.data?.targetUid ?? uid).toString();
    const grant = request.data?.grant !== false;

    if (isBootstrap && !grant) {
      throw new HttpsError("failed-precondition", "No administrator exists to revoke.");
    }

    const user = await auth().getUser(targetUid).catch(() => null);
    if (!user) {
      throw new HttpsError("not-found", "No user record exists for that account.");
    }

    const existingClaims = (user.customClaims ?? {}) as Record<string, unknown>;
    const nextClaims = { ...existingClaims };
    if (grant) {
      nextClaims.admin = true;
      nextClaims.role = "admin";
    } else {
      delete nextClaims.admin;
      if (nextClaims.role === "admin") delete nextClaims.role;
    }

    await auth().setCustomUserClaims(targetUid, nextClaims);
    await db.collection(COLLECTIONS.users).doc(targetUid).set(
      {
        admin: grant,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    return {
      targetUid,
      admin: grant,
      bootstrapped: isBootstrap,
    };
  }
);

async function countExistingAdmins(): Promise<number> {
  const snapshot = await db
    .collection(COLLECTIONS.users)
    .where("admin", "==", true)
    .limit(1)
    .get();
  return snapshot.size;
}

interface SeedPayload {
  /** Optional plan price in paisa supplied by the bootstrapping administrator. */
  pricePaisa?: number;
}

/** Creates the plan document and the counter document on a fresh project. Admin claim required. */
export const bootstrapProject = onCall(
  { region: REGION },
  async (request: CallableRequest<SeedPayload>) => {
    requireAdmin(request);
    const pricePaisa = Math.max(0, Math.round(Number(request.data?.pricePaisa ?? 9900)));

    const planRef = db.collection(COLLECTIONS.plans).doc(DEFAULT_PLAN_ID);
    const planSnapshot = await planRef.get();
    if (!planSnapshot.exists) {
      await planRef.set({
        planId: DEFAULT_PLAN_ID,
        name: "Free Apps Nepal Pro",
        description: "One monthly subscription unlocks every eligible Pro app and Pro game.",
        currency: "NPR",
        pricePaisa,
        durationDays: 30,
        enabled: true,
        benefits: [
          "All Pro Apps unlocked",
          "All Pro Games unlocked",
          "Direct Pro downloads, no extra ad",
          "No per app purchase",
        ],
        discountEnabled: false,
        discountPercentage: 0,
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });
    }

    await db.collection(COLLECTIONS.settings).doc("counters").set(
      { counterId: "counters", updatedAt: FieldValue.serverTimestamp() },
      { merge: true }
    );

    await db.collection(COLLECTIONS.settings).doc("app").set(
      {
        appName: "Free Apps Nepal",
        maintenanceMode: false,
        proPlanEnabled: true,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    return { planId: DEFAULT_PLAN_ID, pricePaisa };
  }
);
