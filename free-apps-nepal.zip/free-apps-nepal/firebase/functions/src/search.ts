/**
 * Search normalisation shared by the Firestore trigger and the admin side.
 *
 * Kept dependency free so it can be unit tested and reused in the emulator.
 */
export const SearchNormalizer = {
  keywords(name: string, developer: string, category: string): string[] {
    const tokens = new Set<string>();

    const add = (value: string): void => {
      const normalised = value.trim().toLowerCase();
      if (!normalised) return;
      tokens.add(normalised);
      for (const word of normalised.split(" ")) {
        if (word.length >= 2) tokens.add(word);
      }
      const limit = Math.min(normalised.length, 12);
      for (let index = 2; index <= limit; index += 1) {
        tokens.add(normalised.substring(0, index));
      }
    };

    add(name);
    add(developer);
    add(category);
    return Array.from(tokens).slice(0, 120);
  },

  nameLower(value: string): string {
    return value.trim().toLowerCase();
  },
};
