import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import { REGION, COLLECTIONS, itemCollection, nowMillis } from "./config";
import { requireAuth, db } from "./firebase";

interface GetProLinkPayload {
  itemId?: string;
  itemType?: string;
}

/**
 * Releases the admin configured Pro download URL for a listing.
 *
 * The Pro URL is never stored on the public listing document. It lives in `secureLinks/{itemId}`,
 * which security rules deny to every client. This function is the only way a client can obtain it,
 * and it re-checks the server side subscription snapshot against a trusted timestamp before
 * returning anything.
 *
 * What this guarantees: the application cannot be used to obtain a Pro link without an active
 * subscription, and the link is not discoverable by reading the catalogue. What it cannot
 * guarantee: secrecy of a plain external URL after it has been handed to a legitimate subscriber.
 * Once released, such a URL is known to that user and could be forwarded, which is a limitation of
 * any direct-download link and is why the free link remains the primary path.
 */
export const getProDownloadLink = onCall(
  { region: REGION },
  async (request: CallableRequest<GetProLinkPayload>) => {
    const uid = requireAuth(request);
    const itemId = (request.data?.itemId ?? "").toString();
    const itemType = (request.data?.itemType ?? "APP").toString().toUpperCase();
    if (!itemId) {
      throw new HttpsError("invalid-argument", "An item id is required.");
    }
    if (itemType !== "APP" && itemType !== "GAME") {
      throw new HttpsError("invalid-argument", "Unknown item type.");
    }

    const itemSnapshot = await db.collection(itemCollection(itemType)).doc(itemId).get();
    if (!itemSnapshot.exists) {
      throw new HttpsError("not-found", "This listing no longer exists.");
    }
    const item = itemSnapshot.data() ?? {};
    if (item.published !== true) {
      throw new HttpsError("not-found", "This listing is not available.");
    }
    if (item.proEnabled !== true) {
      throw new HttpsError("failed-precondition", "This listing has no Pro version.");
    }

    const subscriptionSnapshot = await db
      .collection(COLLECTIONS.userSubscriptions)
      .doc(uid)
      .get();
    if (!subscriptionSnapshot.exists) {
      throw new HttpsError(
        "permission-denied",
        "Subscribe to Pro to unlock direct download."
      );
    }

    const subscription = subscriptionSnapshot.data() ?? {};
    const expiresAt = subscription.expiresAt;
    const expiryMillis =
      expiresAt && typeof expiresAt.toDate === "function"
        ? (expiresAt.toDate() as Date).getTime()
        : null;

    if (
      subscription.active !== true ||
      subscription.status !== "ACTIVE" ||
      expiryMillis === null ||
      expiryMillis <= nowMillis()
    ) {
      throw new HttpsError(
        "failed-precondition",
        "Your Pro subscription is not active. Renew Pro to unlock direct download."
      );
    }

    const linkSnapshot = await db.collection(COLLECTIONS.secureLinks).doc(itemId).get();
    if (!linkSnapshot.exists) {
      throw new HttpsError("not-found", "The Pro download link is not configured.");
    }
    const url = String(linkSnapshot.get("proDownloadUrl") ?? "").trim();
    if (!/^https?:\/\//i.test(url)) {
      throw new HttpsError("failed-precondition", "The Pro download link is not valid.");
    }

    await db.collection(COLLECTIONS.downloadEvents).add({
      itemId,
      itemType,
      userId: uid,
      kind: "PRO",
      createdAt: nowMillis(),
    });

    await db
      .collection(itemCollection(itemType))
      .doc(itemId)
      .set({ proDownloadClickCount: (item.proDownloadClickCount ?? 0) + 1 }, { merge: true });

    return {
      itemId,
      itemType,
      url,
      expiresAtMillis: expiryMillis,
    };
  }
);
