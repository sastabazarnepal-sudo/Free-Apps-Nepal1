import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import {
  REGION,
  KHALTI_SECRET_KEY,
  KHALTI_BASE_URL,
  COLLECTIONS,
  nowMillis,
} from "./config";
import { requireAuth, db } from "./firebase";
import { finalisePaidOrder } from "./createOrder";

interface VerifyKhaltiPayload {
  orderId?: string;
  pidx?: string;
}

interface KhaltiLookupResponse {
  pidx?: string;
  total_amount?: number;
  status?: string;
  transaction_id?: string;
  purchase_order_id?: string;
}

/**
 * Verifies a Khalti ePayment.
 *
 * The client can only supply an order id, and the lookup key is the pidx that the backend stored
 * on the order when it initiated the payment. The caller never chooses the amount and never
 * declares success: the decision comes from the provider lookup below.
 */
export const verifyKhaltiPayment = onCall(
  { region: REGION, secrets: [KHALTI_SECRET_KEY, KHALTI_BASE_URL] },
  async (request: CallableRequest<VerifyKhaltiPayload>) => {
    const uid = requireAuth(request);
    const orderId = (request.data?.orderId ?? "").toString();
    if (!orderId) {
      throw new HttpsError("invalid-argument", "An order id is required.");
    }

    const orderRef = db.collection(COLLECTIONS.orders).doc(orderId);
    const orderSnapshot = await orderRef.get();
    if (!orderSnapshot.exists) {
      throw new HttpsError("not-found", "Unknown order.");
    }
    const order = orderSnapshot.data() ?? {};
    if (order.userId !== uid) {
      throw new HttpsError("permission-denied", "This order belongs to another account.");
    }

    // The pidx must come from the stored order, not from the request, so a caller cannot point the
    // verification at somebody else's successful payment.
    const pidx = String(order.providerToken ?? request.data?.pidx ?? "");
    if (!pidx) {
      throw new HttpsError("failed-precondition", "This order has no Khalti payment reference.");
    }

    const base = KHALTI_BASE_URL.value().replace(/\/$/, "");
    const response = await fetch(`${base}/epayment/lookup/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `key ${KHALTI_SECRET_KEY.value()}`,
      },
      body: JSON.stringify({ pidx }),
    });

    if (!response.ok) {
      throw new HttpsError(
        "unavailable",
        "Khalti is unavailable right now. The payment is still pending."
      );
    }

    const lookup = (await response.json()) as KhaltiLookupResponse;
    const status = String(lookup.status ?? "").toUpperCase();

    if (status === "COMPLETED") {
      const paidPaisa = Math.round(Number(lookup.total_amount ?? 0));
      const result = await finalisePaidOrder({
        uid,
        orderId,
        transactionId: String(lookup.transaction_id ?? pidx),
        paidPaisa,
        referenceId: pidx,
      });
      return {
        verified: true,
        status: "ACTIVE",
        orderId,
        subscriptionId: result.subscriptionId,
        expiresAt: result.expiresAt,
      };
    }

    if (status === "PENDING" || status === "INITIATED") {
      return { verified: false, status: "PENDING", orderId };
    }

    if (status === "REFUNDED") {
      await orderRef.set({ status: "REFUNDED", updatedAt: nowMillis() }, { merge: true });
      return { verified: false, status: "REFUNDED", orderId };
    }

    if (status === "USER CANCELED" || status === "CANCELED") {
      await orderRef.set({ status: "CANCELLED", updatedAt: nowMillis() }, { merge: true });
      return { verified: false, status: "CANCELLED", orderId };
    }

    await orderRef.set(
      { status: "FAILED", failureReason: `khalti_${status || "unknown"}`, updatedAt: nowMillis() },
      { merge: true }
    );
    return { verified: false, status: "FAILED", orderId };
  }
);
