import { defineSecret } from "firebase-functions/params";

/**
 * Cloud Functions runs in asia-south1, the closest region to Nepal, so payment verification and
 * link release stay low latency for the target audience.
 */
export const REGION = "asia-south1";

/**
 * Provider credentials are Cloud Functions secrets. They exist only in the trusted backend. They
 * are never bundled into either Android application, so there is no client configuration point
 * where a key could leak.
 */
export const KHALTI_SECRET_KEY = defineSecret("KHALTI_SECRET_KEY");
export const KHALTI_BASE_URL = defineSecret("KHALTI_BASE_URL");
export const ESEWA_SECRET_KEY = defineSecret("ESEWA_SECRET_KEY");
export const ESEWA_PRODUCT_CODE = defineSecret("ESEWA_PRODUCT_CODE");
export const ESEWA_BASE_URL = defineSecret("ESEWA_BASE_URL");
export const ESEWA_STATUS_URL = defineSecret("ESEWA_STATUS_URL");

export const SECRETS = [
  KHALTI_SECRET_KEY,
  KHALTI_BASE_URL,
  ESEWA_SECRET_KEY,
  ESEWA_PRODUCT_CODE,
  ESEWA_BASE_URL,
  ESEWA_STATUS_URL,
];

export const COLLECTIONS = {
  users: "users",
  apps: "apps",
  games: "games",
  categories: "categories",
  plans: "plans",
  subscriptions: "subscriptions",
  userSubscriptions: "userSubscriptions",
  orders: "orders",
  reviews: "reviews",
  promotions: "promotions",
  settings: "settings",
  statistics: "statistics",
  favorites: "favorites",
  downloadEvents: "downloadEvents",
  secureLinks: "secureLinks",
} as const;

export const SETTINGS_DOCS = {
  app: "app",
  counters: "counters",
  serverTime: "serverTime",
} as const;

export const DEFAULT_PLAN_ID = "pro_monthly";
export const DEFAULT_CURRENCY = "NPR";

/** A newly published listing keeps the NEW badge for this long unless an admin clears it. */
export const NEW_BADGE_DAYS = 14;

export function itemCollection(itemType: string): string {
  return itemType === "GAME" ? COLLECTIONS.games : COLLECTIONS.apps;
}

export function nowMillis(): number {
  return Date.now();
}

export function dayKey(millis: number = Date.now()): string {
  return new Date(millis).toISOString().slice(0, 10);
}
