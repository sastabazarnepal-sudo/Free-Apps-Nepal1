import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import crypto from "node:crypto";
import {
  REGION,
  ESEWA_SECRET_KEY,
  ESEWA_PRODUCT_CODE,
  ESEWA_STATUS_URL,
  COLLECTIONS,
  nowMillis,
} from "./config";
import { requireAuth, db, markOrder, bumpPendingPayments } from "./firebase";
import { finalisePaidOrder, esewaSignature } from "./createOrder";

interface VerifyEsewaPayload {
  orderId?: string;
  /** The base64 `data` parameter that eSewa appends to the success redirect. */
  encodedResponse?: string;
}

interface EsewaDecoded {
  transaction_code?: string;
  status?: string;
  total_amount?: string | number;
  transaction_uuid?: string;
  product_code?: string;
  signed_field_names?: string;
  signature?: string;
}

/**
 * Verifies an eSewa ePay v2 payment.
 *
 * Two independent checks are performed before Pro is activated:
 *  1. the redirect payload signature is recomputed with the merchant secret, proving the payload
 *     was produced by eSewa and was not altered by the client
 *  2. the transaction is confirmed against the eSewa status API
 * The reported amount is then compared with the amount computed on the server for the order.
 */
export const verifyEsewaPayment = onCall(
  { region: REGION, secrets: [ESEWA_SECRET_KEY, ESEWA_PRODUCT_CODE, ESEWA_STATUS_URL] },
  async (request: CallableRequest<VerifyEsewaPayload>) => {
    const uid = requireAuth(request);
    const orderId = (request.data?.orderId ?? "").toString();
    const encoded = (request.data?.encodedResponse ?? "").toString();
    if (!orderId) {
      throw new HttpsError("invalid-argument", "An order id is required.");
    }

    const orderRef = db.collection(COLLECTIONS.orders).doc(orderId);
    const orderSnapshot = await orderRef.get();
    if (!orderSnapshot.exists) {
      throw new HttpsError("not-found", "Unknown order.");
    }
    const order = orderSnapshot.data() ?? {};
    if (order.userId !== uid) {
      throw new HttpsError("permission-denied", "This order belongs to another account.");
    }

    const decoded = decodeRedirect(encoded);
    const secret = ESEWA_SECRET_KEY.value();
    const productCode = ESEWA_PRODUCT_CODE.value();

    if (decoded) {
      if (decoded.product_code && decoded.product_code !== productCode) {
        throw new HttpsError("invalid-argument", "The payment belongs to another merchant.");
      }
      if (!verifyRedirectSignature(decoded, secret)) {
        await markOrder(orderId, "FAILED", { failureReason: "esewa_signature_mismatch" });
        throw new HttpsError(
          "permission-denied",
          "The eSewa response signature could not be verified."
        );
      }
      if (decoded.transaction_uuid && decoded.transaction_uuid !== orderId) {
        await markOrder(orderId, "FAILED", { failureReason: "esewa_uuid_mismatch" });
        throw new HttpsError("invalid-argument", "The payment does not match this order.");
      }
      const reportedStatus = String(decoded.status ?? "").toUpperCase();
      if (reportedStatus && reportedStatus !== "COMPLETE" && reportedStatus !== "COMPLETED") {
        await markOrder(orderId, "FAILED", { failureReason: `esewa_${reportedStatus}` });
        return { verified: false, status: "FAILED", orderId };
      }
    }

    const confirmed = await confirmWithStatusApi(orderId, productCode);
    if (!confirmed.ok) {
      return { verified: false, status: "PENDING", orderId };
    }

    const result = await finalisePaidOrder({
      uid,
      orderId,
      transactionId: confirmed.transactionCode || orderId,
      paidPaisa: confirmed.paidPaisa,
      referenceId: confirmed.referenceId,
    });

    return {
      verified: true,
      status: "ACTIVE",
      orderId,
      subscriptionId: result.subscriptionId,
      expiresAt: result.expiresAt,
    };
  }
);

function decodeRedirect(encoded: string): EsewaDecoded | null {
  if (!encoded) return null;
  try {
    const json = Buffer.from(encoded, "base64").toString("utf8");
    return JSON.parse(json) as EsewaDecoded;
  } catch {
    return null;
  }
}

/**
 * Recomputes the HMAC over the signed field values exactly as eSewa does and compares it with the
 * supplied signature using a constant time comparison.
 */
export function verifyRedirectSignature(decoded: EsewaDecoded, secret: string): boolean {
  const names = String(decoded.signed_field_names ?? "").split(",").map((v) => v.trim()).filter(Boolean);
  if (names.length === 0) return false;
  const message = names
    .map((name) => {
      const value = (decoded as Record<string, unknown>)[name];
      return `${name}=${value ?? ""}`;
    })
    .join(",");
  const expected = esewaSignature(message, secret);
  const provided = String(decoded.signature ?? "");
  if (provided.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(expected));
}

async function confirmWithStatusApi(
  orderId: string,
  productCode: string
): Promise<{ ok: boolean; paidPaisa: number; transactionCode: string; referenceId: string }> {
  const base = ESEWA_STATUS_URL.value().replace(/\/$/, "");
  const url =
    `${base}/api/epay/transaction/status/` +
    `?product_code=${encodeURIComponent(productCode)}` +
    `&total_amount=0` +
    `&transaction_uuid=${encodeURIComponent(orderId)}`;

  const response = await fetch(url, {
    method: "GET",
    headers: { Accept: "application/json" },
  });
  if (!response.ok) {
    return { ok: false, paidPaisa: 0, transactionCode: "", referenceId: "" };
  }

  const payload = (await response.json()) as {
    status?: string;
    transaction_code?: string;
    total_amount?: string | number;
    ref_id?: string;
    product_code?: string;
  };

  const status = String(payload.status ?? "").toUpperCase();
  if (status !== "COMPLETE" && status !== "COMPLETED") {
    return { ok: false, paidPaisa: 0, transactionCode: "", referenceId: "" };
  }

  const paidPaisa = Math.round(Number(payload.total_amount ?? 0) * 100);
  return {
    ok: true,
    paidPaisa,
    transactionCode: String(payload.transaction_code ?? ""),
    referenceId: String(payload.ref_id ?? ""),
  };
}

/** Removes the pending counter when a user abandons an eSewa payment before verification. */
export async function cancelEsewaOrder(uid: string, orderId: string): Promise<void> {
  const ref = db.collection(COLLECTIONS.orders).doc(orderId);
  const snapshot = await ref.get();
  if (!snapshot.exists) return;
  if (snapshot.get("userId") !== uid) return;
  if (snapshot.get("status") !== "PENDING") return;
  await ref.set({ status: "CANCELLED", updatedAt: nowMillis() }, { merge: true });
  await bumpPendingPayments(-1);
}
