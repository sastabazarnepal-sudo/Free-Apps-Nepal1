import { onSchedule } from "firebase-functions/v2/scheduler";
import { onDocumentWritten, onDocumentCreated, onDocumentDeleted } from "firebase-functions/v2/firestore";
import { logger } from "firebase-functions";
import { REGION, COLLECTIONS, DEFAULT_PLAN_ID, itemCollection } from "./config";
import { db, FieldValue } from "./firebase";
import { SearchNormalizer } from "./search";

/**
 * Expires subscriptions whose end time has passed.
 *
 * Runs against the trusted server clock, so a user cannot extend Pro access by changing the device
 * date. Only the server side snapshot and the subscription records are touched.
 */
export const expireSubscriptions = onSchedule(
  { region: REGION, schedule: "every 30 minutes", timeZone: "Asia/Kathmandu" },
  async () => {
    const now = Date.now();
    const snapshot = await db
      .collection(COLLECTIONS.userSubscriptions)
      .where("active", "==", true)
      .limit(500)
      .get();

    let expired = 0;
    for (const doc of snapshot.docs) {
      const expiresAt = doc.get("expiresAt");
      const expiryMillis =
        expiresAt && typeof expiresAt.toDate === "function"
          ? (expiresAt.toDate() as Date).getTime()
          : null;
      if (expiryMillis === null || expiryMillis > now) continue;

      const batch = db.batch();
      batch.set(
        doc.ref,
        {
          active: false,
          status: "EXPIRED",
          serverTimeMillis: now,
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );

      const subscriptionId = doc.get("subscriptionId");
      if (typeof subscriptionId === "string" && subscriptionId) {
        batch.set(
          db.collection(COLLECTIONS.subscriptions).doc(subscriptionId),
          { status: "EXPIRED", updatedAt: FieldValue.serverTimestamp() },
          { merge: true }
        );
      }

      batch.set(
        db.collection(COLLECTIONS.settings).doc("counters"),
        {
          activeProSubscribers: FieldValue.increment(-1),
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
      await batch.commit();
      expired += 1;
    }

    if (expired > 0) {
      logger.info("Expired Pro subscriptions", { expired });
    }
  }
);

/**
 * Keeps the search index and the display name of every listing current.
 *
 * The admin app writes plain fields. This trigger derives the normalised name and the keyword
 * array, so search stays consistent even if an older admin build writes only the base fields.
 */
export const syncItemDerivedFields = onDocumentWritten(
  {
    region: REGION,
    document: "{collection}/{itemId}",
    retry: false,
  },
  async (event) => {
    const collection = event.params.collection;
    if (collection !== COLLECTIONS.apps && collection !== COLLECTIONS.games) return;

    const after = event.data?.after;
    if (!after || !after.exists) return;
    const data = after.data() ?? {};

    const name = String(data.name ?? "");
    const developer = String(data.developerName ?? "");
    const categoryName = String(data.categoryName ?? "");
    const expectedNameLower = name.trim().toLowerCase();
    const expectedKeywords = SearchNormalizer.keywords(name, developer, categoryName);
    const currentKeywords: string[] = Array.isArray(data.searchKeywords) ? data.searchKeywords : [];

    const keywordsDiffer =
      currentKeywords.length !== expectedKeywords.length ||
      expectedKeywords.some((value) => !currentKeywords.includes(value));

    const updates: Record<string, unknown> = {};
    if (expectedNameLower && data.nameLower !== expectedNameLower) {
      updates.nameLower = expectedNameLower;
    }
    if (keywordsDiffer) {
      updates.searchKeywords = expectedKeywords;
    }

    const type = collection === COLLECTIONS.games ? "GAME" : "APP";
    const itemId = event.params.itemId;
    nextSideEffects(type, itemId, data, updates);

    if (Object.keys(updates).length > 0) {
      await after.ref.set(updates, { merge: true });
    }
  }
);

function nextSideEffects(
  _type: string,
  _itemId: string,
  _data: Record<string, unknown>,
  _updates: Record<string, unknown>
): void {
  // Placeholder for future derived counters. Kept intentionally empty so the trigger does one
  // narrow job: keeping the searchable fields correct.
}

/** Tracks the visible catalogue size and whether a listing should carry the NEW badge. */
export const onItemCreated = onDocumentCreated(
  { region: REGION, document: "{collection}/{itemId}" },
  async (event) => {
    const collection = event.params.collection;
    if (collection !== COLLECTIONS.apps && collection !== COLLECTIONS.games) return;
    const counterField = collection === COLLECTIONS.games ? "totalGames" : "totalApps";

    await db.collection(COLLECTIONS.settings).doc("counters").set(
      {
        [counterField]: FieldValue.increment(1),
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  }
);

export const onItemDeleted = onDocumentDeleted(
  { region: REGION, document: "{collection}/{itemId}" },
  async (event) => {
    const collection = event.params.collection;
    if (collection !== COLLECTIONS.apps && collection !== COLLECTIONS.games) return;
    const counterField = collection === COLLECTIONS.games ? "totalGames" : "totalApps";

    await db.collection(COLLECTIONS.settings).doc("counters").set(
      {
        [counterField]: FieldValue.increment(-1),
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    // The secure link and review subtree must not outlive the listing.
    const secureLink = db.collection(COLLECTIONS.secureLinks).doc(event.params.itemId);
    await secureLink.delete().catch(() => undefined);

    const reviews = await db
      .collection(itemCollection(collection === COLLECTIONS.games ? "GAME" : "APP"))
      .doc(event.params.itemId)
      .collection(COLLECTIONS.reviews)
      .limit(100)
      .get();
    if (!reviews.empty) {
      const batch = db.batch();
      reviews.docs.forEach((doc) => batch.delete(doc.ref));
      await batch.commit();
    }
  }
);

/** Maintains rating aggregates on the listing when a review is written. */
export const onReviewWritten = onDocumentWritten(
  { region: REGION, document: `${COLLECTIONS.reviews}/{reviewId}` },
  async (event) => {
    const before = event.data?.before?.data();
    const after = event.data?.after?.data();

    const applyDelta = async (
      itemId: string,
      itemType: string,
      deltaSum: number,
      deltaCount: number,
      deltaHidden: number
    ) => {
      if (!itemId) return;
      const itemRef = db.collection(itemCollection(itemType)).doc(itemId);
      const updates: Record<string, unknown> = {
        ratingSum: FieldValue.increment(deltaSum),
        ratingCount: FieldValue.increment(deltaCount),
      };
      if (deltaHidden !== 0) {
        updates.reviewCount = FieldValue.increment(deltaHidden);
      }
      await itemRef.set(updates, { merge: true });
    };

    if (before && after) {
      const itemId = String(after.itemId ?? before.itemId ?? "");
      const itemType = String(after.itemType ?? before.itemType ?? "APP");
      const ratingDelta = Number(after.rating ?? 0) - Number(before.rating ?? 0);
      const hiddenDelta = (after.hidden === true ? 0 : 1) - (before.hidden === true ? 0 : 1);
      await applyDelta(itemId, itemType, ratingDelta, 0, hiddenDelta);
      return;
    }

    if (after) {
      await applyDelta(
        String(after.itemId ?? ""),
        String(after.itemType ?? "APP"),
        Number(after.rating ?? 0),
        1,
        after.hidden === true ? 0 : 1
      );
      return;
    }

    if (before) {
      await applyDelta(
        String(before.itemId ?? ""),
        String(before.itemType ?? "APP"),
        -Number(before.rating ?? 0),
        -1,
        before.hidden === true ? 0 : -1
      );
    }
  }
);

/** Recomputes the active subscriber count and pending payments once per day. */
export const reconcileCounters = onSchedule(
  { region: REGION, schedule: "every day 02:00", timeZone: "Asia/Kathmandu" },
  async () => {
    const [activeSnapshot, pendingSnapshot] = await Promise.all([
      db.collection(COLLECTIONS.userSubscriptions).where("active", "==", true).count().get(),
      db.collection(COLLECTIONS.orders).where("status", "==", "PENDING").count().get(),
    ]);

    await db.collection(COLLECTIONS.settings).doc("counters").set(
      {
        activeProSubscribers: activeSnapshot.data().count,
        pendingPayments: pendingSnapshot.data().count,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  }
);

export const DEFAULT_PLAN = DEFAULT_PLAN_ID;
