import { getFirestore, FieldValue, Timestamp } from "firebase-admin/firestore";
import { HttpsError, CallableRequest } from "firebase-functions/v2/https";
import {
  COLLECTIONS,
  DEFAULT_CURRENCY,
  DEFAULT_PLAN_ID,
  SETTINGS_DOCS,
  dayKey,
  nowMillis,
} from "./config";

export const db = getFirestore();
db.settings({ ignoreUndefinedProperties: true });

export interface PlanDocument {
  planId: string;
  name: string;
  currency: string;
  pricePaisa: number;
  durationDays: number;
  enabled: boolean;
  discountEnabled: boolean;
  discountPercentage: number;
  discountStartAt?: Timestamp;
  discountEndAt?: Timestamp;
}

export interface PriceBreakdown {
  planId: string;
  planName: string;
  currency: string;
  originalPricePaisa: number;
  discountPercentage: number;
  finalPricePaisa: number;
  durationDays: number;
}

export function requireAuth(request: CallableRequest): string {
  const uid = request.auth?.uid;
  if (!uid) {
    throw new HttpsError("unauthenticated", "Sign in is required for this action.");
  }
  return uid;
}

export function isAdminRequest(request: CallableRequest): boolean {
  const token = request.auth?.token as Record<string, unknown> | undefined;
  if (!token) return false;
  return token.admin === true || token.role === "admin";
}

export function requireAdmin(request: CallableRequest): string {
  const uid = requireAuth(request);
  if (!isAdminRequest(request)) {
    throw new HttpsError("permission-denied", "Administrator privileges are required.");
  }
  return uid;
}

/**
 * Reads the plan document and recomputes the price from scratch using the server clock.
 *
 * This is the authoritative price. Any amount supplied by a client is ignored, and the amount
 * finally reported by a payment provider is compared against this value before a subscription is
 * activated.
 */
export async function computePrice(planId: string, atMillis: number = nowMillis()): Promise<PriceBreakdown> {
  const snapshot = await db.collection(COLLECTIONS.plans).doc(planId).get();
  if (!snapshot.exists) {
    throw new HttpsError("not-found", "The Pro plan is not configured.");
  }
  const plan = snapshot.data() as Partial<PlanDocument>;
  if (plan.enabled === false) {
    throw new HttpsError("failed-precondition", "The Pro plan is currently disabled.");
  }

  const original = Math.max(0, Math.round(Number(plan.pricePaisa ?? 0)));
  const discountEnabled = plan.discountEnabled === true;
  const percent = discountEnabled ? clampPercent(Number(plan.discountPercentage ?? 0)) : 0;

  const startMillis = toMillis(plan.discountStartAt);
  const endMillis = toMillis(plan.discountEndAt);
  const withinWindow =
    (startMillis === null || atMillis >= startMillis) && (endMillis === null || atMillis <= endMillis);
  const appliedPercent = withinWindow ? percent : 0;

  const finalPrice = appliedPercent > 0
    ? Math.max(0, Math.round(original - (original * appliedPercent) / 100))
    : original;

  return {
    planId,
    planName: String(plan.name ?? "Free Apps Nepal Pro"),
    currency: String(plan.currency ?? DEFAULT_CURRENCY),
    originalPricePaisa: original,
    discountPercentage: appliedPercent,
    finalPricePaisa: finalPrice,
    durationDays: Math.max(1, Math.round(Number(plan.durationDays ?? 30))),
  };
}

export function clampPercent(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.min(100, Math.max(0, value));
}

export function toMillis(value: unknown): number | null {
  if (!value) return null;
  if (value instanceof Timestamp) return value.toDate().getTime();
  if (typeof value === "object" && value !== null && "toDate" in value) {
    const converted = (value as { toDate: () => Date }).toDate();
    return converted instanceof Date ? converted.getTime() : null;
  }
  if (typeof value === "number") return value;
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : parsed;
  }
  return null;
}

/**
 * Writes the single per user subscription snapshot after a verified payment. Called only from
 * provider verification code paths, never from a client reachable endpoint.
 */
export async function activateSubscription(params: {
  userId: string;
  subscriptionId: string;
  planId: string;
  planName: string;
  originalPricePaisa: number;
  discountPercentage: number;
  paidPaisa: number;
  currency: string;
  paymentMethod: string;
  transactionId: string;
  orderId: string;
  durationDays: number;
}): Promise<{ startMillis: number; expiresMillis: number }> {
  const startMillis = nowMillis();

  const userRef = db.collection(COLLECTIONS.userSubscriptions).doc(params.userId);
  const existing = await userRef.get();
  const existingExpiry = toMillis(existing.get("expiresAt"));
  const existingActive = existing.get("active") === true && existing.get("status") === "ACTIVE";

  // Renewal extends an unexpired subscription instead of discarding the remaining days.
  const effectiveStart = existingActive && existingExpiry !== null && existingExpiry > startMillis
    ? existingExpiry
    : startMillis;
  const effectiveExpires = effectiveStart + params.durationDays * 24 * 60 * 60 * 1000;

  const batch = db.batch();

  batch.set(
    db.collection(COLLECTIONS.subscriptions).doc(params.subscriptionId),
    {
      subscriptionId: params.subscriptionId,
      userId: params.userId,
      planId: params.planId,
      planName: params.planName,
      originalPricePaisa: params.originalPricePaisa,
      discountPercentage: params.discountPercentage,
      finalPricePaidPaisa: params.paidPaisa,
      currency: params.currency,
      paymentMethod: params.paymentMethod,
      transactionId: params.transactionId,
      orderId: params.orderId,
      status: "ACTIVE",
      startAt: Timestamp.fromMillis(effectiveStart),
      expiresAt: Timestamp.fromMillis(effectiveExpires),
      verifiedBy: "backend",
      updatedAt: FieldValue.serverTimestamp(),
      createdAt: FieldValue.serverTimestamp(),
    },
    { merge: true }
  );

  batch.set(
    userRef,
    {
      userId: params.userId,
      subscriptionId: params.subscriptionId,
      planId: params.planId,
      status: "ACTIVE",
      active: true,
      paymentMethod: params.paymentMethod,
      startAt: Timestamp.fromMillis(effectiveStart),
      expiresAt: Timestamp.fromMillis(effectiveExpires),
      serverTimeMillis: startMillis,
      updatedAt: FieldValue.serverTimestamp(),
    },
    { merge: true }
  );

  batch.set(
    db.collection(COLLECTIONS.settings).doc(SETTINGS_DOCS.counters),
    {
      activeProSubscribers: FieldValue.increment(1),
      subscriptionPurchases: FieldValue.increment(1),
      pendingPayments: FieldValue.increment(-1),
      revenuePaisa: FieldValue.increment(params.paidPaisa),
      updatedAt: FieldValue.serverTimestamp(),
    },
    { merge: true }
  );

  batch.set(
    db.collection(COLLECTIONS.statistics).doc(dayKey(startMillis)),
    {
      date: dayKey(startMillis),
      subscriptionPurchases: FieldValue.increment(1),
      revenuePaisa: FieldValue.increment(params.paidPaisa),
      updatedAt: FieldValue.serverTimestamp(),
    },
    { merge: true }
  );

  await batch.commit();
  return { startMillis: effectiveStart, expiresMillis: effectiveExpires };
}

export async function markOrder(
  orderId: string,
  status: string,
  extra: Record<string, unknown> = {}
): Promise<void> {
  await db.collection(COLLECTIONS.orders).doc(orderId).set(
    {
      orderId,
      status,
      updatedAt: FieldValue.serverTimestamp(),
      ...extra,
    },
    { merge: true }
  );
}

export async function bumpPendingPayments(delta: number): Promise<void> {
  await db.collection(COLLECTIONS.settings).doc(SETTINGS_DOCS.counters).set(
    {
      pendingPayments: FieldValue.increment(delta),
      updatedAt: FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

export { FieldValue, Timestamp, DEFAULT_PLAN_ID, DEFAULT_CURRENCY };
