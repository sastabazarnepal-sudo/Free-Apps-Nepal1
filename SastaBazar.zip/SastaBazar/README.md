# SastaBazar (User app + Admin app)

1. Firebase Console > Authentication > Sign-in method > **Email/Password = Enable**.
2. Firebase Console > Firestore > Rules: `firestore.rules` ka poora content paste karke **Publish**.
3. Is folder ko GitHub repo (**PRIVATE** rakhna, keystore andar hai) me upload karo.
4. Repo > Actions > "Build APKs" > Run workflow.
5. Khatam hone par run page ke neeche Artifacts se dono APK download karo.

## Pehla admin
1. Admin APK me **Create account** karo (email + password).
2. Screen par UID dikhega (Copy UID dabao).
3. Firebase Console > Firestore > **Start collection** `admins` > Document ID = wo UID, field `role` = `admin`.
4. Admin app me **Check again** dabao.

## Google login (user app)
1. Firebase > Authentication > Sign-in method > **Google = Enable**.
2. Firebase > Project settings > Android app `com.sastabazar.app` > **Add fingerprint** > SHA-1:
   `F2:88:B4:B1:79:5B:74:C0:36:81:05:B0:27:63:6C:36:F2:DD:8B:FC`
3. Naya `google-services.json` download karke `user/google-services.json` replace karo. Dobara build karo.
   (Google button khud dikh jayega; kuch aur paste nahi karna.)

## Product daalna
imgbb.com par image upload > **Direct link** (`https://i.ibb.co/...`) > Admin app > Products > Add > paste.
English naam zaroori; Nepali/Hindi khaali hoga to us bhasha me English naam dikhega.

## Notification
Order status badalte hi customer ko Alerts tab me entry + phone notification (app chal raha ho ya background me ho). Poori band app par push ke liye server chahiye (Blaze plan) — abhi nahi.
