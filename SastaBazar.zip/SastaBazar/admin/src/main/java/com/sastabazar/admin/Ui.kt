@file:OptIn(ExperimentalMaterial3Api::class)

package com.sastabazar.admin

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import android.content.Context
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay

// ---------- palette ----------
val ColBg = Color(0xFF140D0F)
val ColCard = Color(0xFF1F1417)
val ColCard2 = Color(0xFF2B1B1F)
val ColLine = Color(0xFF3A2429)
val ColBrand = Color(0xFFF0263C)
val ColAccent = Color(0xFFFF8A5B)
val ColGreen = Color(0xFF34D399)
val ColBlue = Color(0xFF60A5FA)
val ColGold = Color(0xFFFFB454)
val ColRed = Color(0xFFFF6B6B)
val ColDim = Color(0xFFB59CA2)
val ColText = Color(0xFFF6EDEF)

private val Scheme = darkColorScheme(
    primary = ColBrand, onPrimary = Color.White,
    secondary = ColAccent, tertiary = ColGold,
    background = ColBg, onBackground = ColText,
    surface = ColCard, onSurface = ColText,
    surfaceVariant = ColCard2, onSurfaceVariant = ColDim,
    outline = ColLine, outlineVariant = ColLine,
    error = ColRed,
    primaryContainer = Color(0xFF5C1620), onPrimaryContainer = Color(0xFFFFDADF),
    surfaceContainer = ColCard, surfaceContainerHigh = ColCard2
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}

// ---------- helpers ----------
fun tierLabel(t: String) = when (t) { "pro" -> "Pro"; "promax" -> "Pro Max"; else -> "Free" }
fun tierColor(t: String) = when (t) { "pro" -> ColBlue; "promax" -> ColGold; else -> ColGreen }

fun friendlyAuthError(e: Exception?): String {
    val m = e?.message ?: ""
    val l = m.lowercase()
    return when {
        "password is invalid" in l || "credential is incorrect" in l || "invalid_login_credentials" in l ||
            "malformed or has expired" in l || "invalid_credential" in l -> "Wrong email or password."
        "no user record" in l -> "No account with this email. Create one."
        "already in use" in l -> "This email is already registered. Sign in."
        "badly formatted" in l -> "Enter a valid email."
        "at least 6" in l || "password should" in l -> "Password must be at least 6 characters."
        "network" in l -> "Check your internet connection."
        "configuration_not_found" in l || "operation is not allowed" in l -> "Email/Password sign-in is not enabled in Firebase."
        else -> m.ifBlank { "Something went wrong. Try again." }
    }
}

/** Crash-safe auth: khali field ya koi bhi exception app band nahi karega. */
fun doAuth(register: Boolean, email: String, pass: String, onDone: (String?) -> Unit) {
    if (email.isBlank() || pass.isBlank()) { onDone("Enter both email and password."); return }
    try {
        val auth = FirebaseAuth.getInstance()
        val task = if (register) auth.createUserWithEmailAndPassword(email.trim(), pass)
        else auth.signInWithEmailAndPassword(email.trim(), pass)
        task.addOnSuccessListener { onDone(null) }.addOnFailureListener { onDone(friendlyAuthError(it)) }
    } catch (e: Exception) {
        onDone(friendlyAuthError(e))
    }
}

// ---------- modifiers & components ----------
@Composable
fun Modifier.pressScale(src: MutableInteractionSource): Modifier {
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.97f else 1f, spring(), label = "press")
    return this.graphicsLayer { scaleX = s; scaleY = s }
}

@Composable
fun SoftCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val src = remember { MutableInteractionSource() }
    val m = modifier.fillMaxWidth().pressScale(src)
    val shape = RoundedCornerShape(20.dp)
    val colors = CardDefaults.cardColors(containerColor = ColCard)
    val border = BorderStroke(1.dp, ColLine)
    if (onClick != null) {
        Card(onClick = onClick, modifier = m, shape = shape, colors = colors, border = border,
            interactionSource = src, content = content)
    } else {
        Card(modifier = m, shape = shape, colors = colors, border = border, content = content)
    }
}

@Composable
fun TierBadge(tier: String) {
    val c = tierColor(tier)
    Text(
        tierLabel(tier).uppercase(), color = c, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun StatusChip(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun AppIcon(url: String, name: String, size: Dp, radius: Dp = 16.dp) {
    val ctx = LocalContext.current
    val clean = normalizeImageUrl(url)
    Box(
        Modifier.size(size).clip(RoundedCornerShape(radius))
            .background(Brush.linearGradient(listOf(ColBrand, ColAccent))),
        contentAlignment = Alignment.Center
    ) {
        Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value / 2.4f).sp)
        if (clean.isNotBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(clean).crossfade(600)
                    .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                    .build(),
                contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun SkeletonCard() {
    val t = rememberInfiniteTransition(label = "sk")
    val a by t.animateFloat(0.25f, 0.65f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(ColCard).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(64.dp).alpha(a).clip(RoundedCornerShape(16.dp)).background(ColLine))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Box(Modifier.fillMaxWidth(0.5f).height(14.dp).alpha(a).clip(RoundedCornerShape(6.dp)).background(ColLine))
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(10.dp).alpha(a).clip(RoundedCornerShape(6.dp)).background(ColLine))
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth(0.7f).height(10.dp).alpha(a).clip(RoundedCornerShape(6.dp)).background(ColLine))
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, sub: String) {
    Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(ColCard), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = ColDim, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(4.dp))
        Text(sub, color = ColDim, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

/** Item ko thoda delay ke saath fade + slide karke dikhata hai. */
@Composable
fun Appear(index: Int, content: @Composable () -> Unit) {
    var vis by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(minOf(index, 8) * 45L); vis = true }
    AnimatedVisibility(vis, enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 5 }) { content() }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, loading: Boolean = false) {
    val src = remember { MutableInteractionSource() }
    Button(
        onClick = onClick, enabled = enabled && !loading, interactionSource = src,
        modifier = modifier.fillMaxWidth().height(54.dp).pressScale(src),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = ColBrand, contentColor = Color.White,
            disabledContainerColor = ColCard2, disabledContentColor = ColDim
        )
    ) {
        AnimatedContent(loading, label = "btn") { l ->
            if (l) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
            else Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        }
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = ColText) {
    OutlinedButton(
        onClick = onClick, modifier = modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, ColLine), colors = ButtonDefaults.outlinedButtonColors(contentColor = color)
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun AppField(
    value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier,
    password: Boolean = false, singleLine: Boolean = true, keyboardType: KeyboardType = KeyboardType.Text
) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = singleLine,
        modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        visualTransformation = if (password && !show) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboardType),
        trailingIcon = {
            if (password) IconButton(onClick = { show = !show }) {
                Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, tint = ColDim)
            }
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = ColBrand, unfocusedBorderColor = ColLine,
            focusedContainerColor = ColCard, unfocusedContainerColor = ColCard,
            focusedLabelColor = ColBrand, unfocusedLabelColor = ColDim, cursorColor = ColBrand
        )
    )
}


// ---------- image url fixer ----------
fun normalizeImageUrl(raw: String): String {
    var u = raw.trim()
    if (u.isEmpty()) return ""
    if (u.startsWith("//")) u = "https:" + u
    if (!u.startsWith("http", ignoreCase = true)) u = "https://" + u
    val drive = Regex("drive\\.google\\.com/file/d/([\\w-]+)").find(u)
    if (drive != null) return "https://drive.google.com/uc?export=view&id=" + drive.groupValues[1]
    val driveId = Regex("drive\\.google\\.com/(?:open|uc)\\?(?:.*&)?id=([\\w-]+)").find(u)
    if (driveId != null) return "https://drive.google.com/uc?export=view&id=" + driveId.groupValues[1]
    if (u.contains("dropbox.com")) {
        return u.replace("www.dropbox.com", "dl.dropboxusercontent.com").replace("?dl=0", "").replace("?dl=1", "")
    }
    val blob = Regex("github\\.com/([^/]+)/([^/]+)/blob/(.+)").find(u)
    if (blob != null) return "https://raw.githubusercontent.com/" + blob.groupValues[1] + "/" + blob.groupValues[2] + "/" + blob.groupValues[3]
    val imgur = Regex("^https?://(?:www\\.)?imgur\\.com/(\\w+)/?").find(u)
    if (imgur != null && !u.contains("/a/") && !u.contains("/gallery/")) return "https://i.imgur.com/" + imgur.groupValues[1] + ".png"
    return u
}

// ---------- crash reporter (phone pe bina PC ke error dekhne ke liye) ----------
object CrashLog {
    fun install(ctx: Context) {
        val prefs = ctx.applicationContext.getSharedPreferences("crashlog", Context.MODE_PRIVATE)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                prefs.edit().putString("log", android.util.Log.getStackTraceString(e).take(3500)).commit()
            } catch (_: Throwable) { }
            old?.uncaughtException(t, e)
        }
    }

    fun take(ctx: Context): String? {
        val prefs = ctx.applicationContext.getSharedPreferences("crashlog", Context.MODE_PRIVATE)
        val s = prefs.getString("log", null)
        if (s != null) prefs.edit().remove("log").apply()
        return s
    }
}

@Composable
fun CrashDialog() {
    val ctx = LocalContext.current
    var log by remember { mutableStateOf(CrashLog.take(ctx)) }
    val l = log
    if (l != null) {
        AlertDialog(
            onDismissRequest = { log = null }, containerColor = ColCard,
            title = { Text("App crashed last time", fontSize = 16.sp) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Send a screenshot of this text:", color = ColDim, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    SelectionContainer { Text(l, fontSize = 9.sp, color = ColText) }
                }
            },
            confirmButton = { TextButton(onClick = { log = null }) { Text("OK") } }
        )
    }
}

// ---------- heavy animation pieces ----------
@Composable
fun AuroraBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(1f, 0f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Box(
        modifier.background(ColBg).drawBehind {
            drawRect(
                Brush.radialGradient(
                    listOf(ColBrand.copy(alpha = 0.30f), Color.Transparent),
                    center = Offset(size.width * (0.1f + 0.8f * a), size.height * 0.10f), radius = size.width * 0.95f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(ColAccent.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(size.width * (0.2f + 0.7f * b), size.height * (0.72f + 0.2f * a)), radius = size.width * 0.85f
                )
            )
        },
        content = content
    )
}

@Composable
fun SpinRing(size: Dp, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "ring")
    val deg by t.animateFloat(0f, 360f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "deg")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize().rotate(deg).clip(CircleShape)
                .background(Brush.sweepGradient(listOf(ColBrand, ColAccent, ColGold, ColBrand)))
        )
        Box(Modifier.size(size - 6.dp).clip(CircleShape).background(ColBg), contentAlignment = Alignment.Center, content = content)
    }
}

@Composable
fun PulseIcon(icon: ImageVector, tint: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(0.9f, 1.15f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")
    Icon(icon, null, tint = tint, modifier = modifier.graphicsLayer { scaleX = s; scaleY = s })
}
