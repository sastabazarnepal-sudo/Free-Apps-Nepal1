@file:OptIn(ExperimentalMaterial3Api::class)

package com.sastabazar.admin

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val STEPS = listOf("CONFIRMED", "PROCESSING", "PACKED", "SHIPPED", "IN_TRANSIT", "OUT_FOR_DELIVERY", "DELIVERED")
val CATS = linkedMapOf("elec" to "Electronics", "fash" to "Fashion", "groc" to "Grocery", "home" to "Home & Living", "beau" to "Beauty", "mob" to "Mobiles")
val ST_LABEL = mapOf(
    "CONFIRMED" to "Confirmed", "PROCESSING" to "Processing", "PACKED" to "Packed", "SHIPPED" to "Shipped", "IN_TRANSIT" to "In transit",
    "OUT_FOR_DELIVERY" to "Out for delivery", "DELIVERED" to "Delivered", "CANCELLED" to "Cancelled"
)

data class Product(val id: String, val en: String, val ne: String, val hi: String, val price: Long, val orig: Long, val cat: String, val image: String, val flash: Boolean, val active: Boolean)
data class Order(val id: String, val uid: String, val userName: String, val phone: String, val address: String, val status: String, val total: Long, val created: Long, val lines: List<String>, val reason: String)

fun rs(x: Long) = "NPR " + NumberFormat.getInstance(Locale.US).format(x)
fun fmt(ms: Long) = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(ms))
fun sid(id: String) = id.take(6).uppercase()
fun stColor(s: String): Color = when (s) { "DELIVERED" -> ColGreen; "CANCELLED" -> ColRed; "CONFIRMED" -> ColBlue; else -> ColGold }

fun notifyLocal(ctx: Context, id: Int, title: String, body: String) {
    try {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("orders", "Orders", NotificationManager.IMPORTANCE_HIGH))
        val b = android.app.Notification.Builder(ctx)
        if (Build.VERSION.SDK_INT >= 26) b.setChannelId("orders")
        b.setSmallIcon(ctx.applicationInfo.icon).setContentTitle(title).setContentText(body).setAutoCancel(true)
        nm.notify(id, b.build())
    } catch (_: Throwable) { }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        setContent { AppTheme { AdminApp() } }
    }
}

@Suppress("UNCHECKED_CAST")
fun parseOrder(d: DocumentSnapshot): Order {
    val lines = (d.get("items") as? List<Map<String, Any?>>)?.map {
        val nm = (it["name"] as? Map<String, Any?>)?.get("en")?.toString() ?: ""
        "${(it["qty"] as? Number)?.toInt() ?: 1} × $nm — " + rs((it["price"] as? Number)?.toLong() ?: 0L)
    } ?: emptyList()
    return Order(
        d.id, d.getString("uid") ?: "", d.getString("userName") ?: "", d.getString("phone") ?: "", d.getString("address") ?: "",
        d.getString("status") ?: "CONFIRMED", d.getLong("total") ?: 0L, d.getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis(),
        lines, d.getString("cancelReason") ?: ""
    )
}

@Composable
fun rememberUser(): FirebaseUser? {
    var u by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { u = it.currentUser }
        FirebaseAuth.getInstance().addAuthStateListener(l)
        onDispose { FirebaseAuth.getInstance().removeAuthStateListener(l) }
    }
    return u
}

@Composable
fun AdminApp() {
    val user = rememberUser()
    var check by remember { mutableIntStateOf(0) }
    var isAdmin by remember(user?.uid, check) { mutableStateOf<Boolean?>(null) }
    LaunchedEffect(user?.uid, check) {
        val u = user
        if (u != null) {
            try {
                FirebaseFirestore.getInstance().collection("admins").document(u.uid).get()
                    .addOnSuccessListener { isAdmin = it.exists() }.addOnFailureListener { isAdmin = false }
            } catch (_: Exception) { isAdmin = false }
        }
    }
    AuroraBackground(Modifier.fillMaxSize()) {
        when {
            user == null -> LoginScreen()
            isAdmin == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = ColBrand) }
            isAdmin == false -> NotAdmin(user) { check++ }
            else -> AdminHome(user)
        }
        CrashDialog()
    }
}

@Composable
fun LoginScreen() {
    var register by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(48.dp))
        Image(painterResource(R.drawable.logo), null, Modifier.size(96.dp).clip(RoundedCornerShape(26.dp)))
        Spacer(Modifier.height(10.dp))
        Text("SastaBazar Admin", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(24.dp))
        SoftCard {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (register) "Create account" else "Sign in", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                AppField(email, { email = it }, "Email", keyboardType = KeyboardType.Email)
                AppField(pass, { pass = it }, "Password (min 6 characters)", password = true)
                if (msg.isNotEmpty()) Text(msg, color = ColRed, fontSize = 13.sp)
                PrimaryButton(if (register) "Create account" else "Sign in", onClick = {
                    busy = true; msg = ""
                    doAuth(register, email, pass) { err -> busy = false; if (err != null) msg = err }
                }, loading = busy)
            }
        }
        Text(
            if (register) "Have an account? Sign in" else "New admin? Create account", color = ColBrand, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clickable { register = !register; msg = "" }.padding(16.dp)
        )
    }
}

@Composable
fun NotAdmin(user: FirebaseUser, onRecheck: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Not an admin yet", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = ColBrand)
        Spacer(Modifier.height(10.dp))
        Text("In Firebase Console open Firestore → collection \"admins\" → add a document whose Document ID is this UID:")
        Spacer(Modifier.height(12.dp))
        SoftCard { SelectionContainer { Text(user.uid, modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold) } }
        Spacer(Modifier.height(12.dp))
        GhostButton("Copy UID", onClick = {
            try { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("uid", user.uid)) } catch (_: Exception) { }
        })
        Spacer(Modifier.height(10.dp))
        PrimaryButton("Check again", onClick = onRecheck)
        Spacer(Modifier.height(10.dp))
        GhostButton("Log out", onClick = { FirebaseAuth.getInstance().signOut() }, color = ColBrand)
    }
}

@Composable
fun AdminHome(user: FirebaseUser) {
    var tab by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) { try { permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } catch (_: Exception) { } } }
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)))
                Spacer(Modifier.width(8.dp))
                Text("SastaBazar Admin", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = ColBrand, modifier = Modifier.weight(1f))
                TextButton(onClick = { FirebaseAuth.getInstance().signOut() }) { Text("Log out", color = ColDim) }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = ColCard.copy(alpha = 0.94f), tonalElevation = 0.dp) {
                listOf(Triple("Orders", Icons.Default.ShoppingBag, 0), Triple("Products", Icons.Default.Inventory2, 1)).forEach { (l, ic, i) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, null) }, label = { Text(l) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = ColBrand, indicatorColor = ColBrand, unselectedIconColor = ColDim, unselectedTextColor = ColDim)
                    )
                }
            }
        }
    ) { pad -> Box(Modifier.padding(pad).fillMaxSize()) { if (tab == 0) OrdersScreen() else ProductsScreen() } }
}

fun setStatus(o: Order, status: String, onErr: () -> Unit) {
    try {
        val db = FirebaseFirestore.getInstance()
        val patch = hashMapOf<String, Any>("status" to status)
        if (status == "CANCELLED") { patch["cancelledAt"] = FieldValue.serverTimestamp(); patch["cancelReason"] = "" }
        db.collection("orders").document(o.id).update(patch).addOnSuccessListener {
            db.collection("notifications").add(mapOf("uid" to o.uid, "orderId" to o.id, "status" to status, "read" to false, "createdAt" to FieldValue.serverTimestamp()))
        }.addOnFailureListener { onErr() }
    } catch (_: Exception) { onErr() }
}

@Composable
fun OrdersScreen() {
    val ctx = LocalContext.current
    var orders by remember { mutableStateOf<List<Order>?>(null) }
    var all by remember { mutableStateOf(false) }
    var confirmCancel by remember { mutableStateOf<Order?>(null) }
    var err by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        var first = true
        val reg = FirebaseFirestore.getInstance().collection("orders").orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, e ->
                if (snap != null) {
                    if (!first && snap.documentChanges.any { it.type == com.google.firebase.firestore.DocumentChange.Type.ADDED && !it.document.metadata.hasPendingWrites() })
                        notifyLocal(ctx, 1, "New order", "A new order has arrived")
                    first = false
                    orders = snap.documents.map { parseOrder(it) }
                } else if (e != null && orders == null) orders = emptyList()
            }
        onDispose { reg.remove() }
    }
    val list = orders
    if (list == null) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { repeat(4) { SkeletonCard() } }; return }
    val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val today = list.filter { it.created >= cal.timeInMillis }
    val sales = today.filter { it.status != "CANCELLED" }.sumOf { it.total }
    val shown = if (all) list else list.filter { it.status != "DELIVERED" && it.status != "CANCELLED" }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Today orders" to today.size.toString(), "Today sales" to rs(sales)).forEach { (l, v) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(ColBrand, Color(0xFF9E0016)))).padding(14.dp)) {
                        Text(l, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp); Text(v, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(false to "Active", true to "All").forEach { (v, l) ->
                    Text(l, color = if (all == v) Color.White else ColText, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (all == v) ColBrand else ColCard2).clickable { all = v }.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
            if (err.isNotEmpty()) Text(err, color = ColRed, modifier = Modifier.padding(top = 8.dp))
        }
        if (shown.isEmpty()) item { EmptyState(Icons.Default.ShoppingBag, "No orders", "") }
        itemsIndexed(shown, key = { _, o -> o.id }) { i, o ->
            Appear(i) {
                val step = STEPS.indexOf(o.status)
                val next = if (step in 0 until STEPS.size - 1) STEPS[step + 1] else null
                SoftCard {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("#" + sid(o.id), fontWeight = FontWeight.ExtraBold); StatusChip(ST_LABEL[o.status] ?: o.status, stColor(o.status))
                        }
                        Text(fmt(o.created) + " · COD · " + rs(o.total), color = ColDim, fontSize = 12.sp)
                        Text(o.userName + " · " + o.phone, fontWeight = FontWeight.SemiBold)
                        Text(o.address, fontSize = 13.sp)
                        o.lines.forEach { Text(it, color = ColDim, fontSize = 12.sp) }
                        if (o.reason.isNotBlank()) Text("Customer reason: " + o.reason, color = ColDim, fontSize = 12.sp)
                        if (next != null) { Spacer(Modifier.height(6.dp)); PrimaryButton("Next: " + (ST_LABEL[next] ?: next), onClick = { err = ""; setStatus(o, next) { err = "Update failed. Check connection and rules." } }) }
                        if (o.status != "DELIVERED" && o.status != "CANCELLED") GhostButton("Cancel order", onClick = { confirmCancel = o }, color = ColBrand)
                    }
                }
            }
        }
    }
    confirmCancel?.let { o ->
        AlertDialog(
            onDismissRequest = { confirmCancel = null }, containerColor = ColCard, title = { Text("Cancel #" + sid(o.id) + "?") },
            confirmButton = { Button(colors = ButtonDefaults.buttonColors(containerColor = ColBrand), onClick = { setStatus(o, "CANCELLED") { err = "Update failed." }; confirmCancel = null }) { Text("Yes, cancel") } },
            dismissButton = { TextButton(onClick = { confirmCancel = null }) { Text("No") } }
        )
    }
}

@Composable
fun ProductsScreen() {
    var products by remember { mutableStateOf<List<Product>?>(null) }
    var edit by remember { mutableStateOf<Product?>(null) }
    var adding by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf<Product?>(null) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("products").addSnapshotListener { snap, e ->
            if (snap != null) products = snap.documents.map {
                @Suppress("UNCHECKED_CAST") val nm = (it.get("name") as? Map<String, Any?>) ?: emptyMap()
                Product(it.id, nm["en"]?.toString() ?: "", nm["ne"]?.toString() ?: "", nm["hi"]?.toString() ?: "", it.getLong("price") ?: 0L, it.getLong("orig") ?: 0L,
                    it.getString("category") ?: "elec", it.getString("image") ?: "", it.getBoolean("flash") == true, it.getBoolean("active") != false)
            } else if (e != null && products == null) products = emptyList()
        }
        onDispose { reg.remove() }
    }
    val list = products
    if (list == null) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { repeat(4) { SkeletonCard() } }; return }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { PrimaryButton("＋  Add product", onClick = { adding = true }) }
        if (list.isEmpty()) item { EmptyState(Icons.Default.Inventory2, "No products yet", "Tap Add product") }
        itemsIndexed(list, key = { _, p -> p.id }) { i, p ->
            Appear(i) {
                SoftCard {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(p.image, p.en.ifBlank { "P" }, 60.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.en, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(rs(p.price), color = ColBrand, fontWeight = FontWeight.Bold)
                            Text((CATS[p.cat] ?: p.cat) + (if (p.flash) " · ⚡ Flash" else "") + (if (!p.active) " · Hidden" else ""), color = ColDim, fontSize = 12.sp)
                        }
                        IconButton(onClick = { edit = p }) { Icon(Icons.Default.Edit, null, tint = ColBrand) }
                        IconButton(onClick = { del = p }) { Icon(Icons.Default.Delete, null, tint = ColDim) }
                    }
                }
            }
        }
    }
    if (adding) ProductForm(null) { adding = false }
    edit?.let { ProductForm(it) { edit = null } }
    del?.let { p ->
        AlertDialog(
            onDismissRequest = { del = null }, containerColor = ColCard, title = { Text("Delete \"" + p.en + "\"?") },
            confirmButton = { Button(colors = ButtonDefaults.buttonColors(containerColor = ColBrand), onClick = { try { FirebaseFirestore.getInstance().collection("products").document(p.id).delete() } catch (_: Exception) { }; del = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("No") } }
        )
    }
}

@Composable
fun ProductForm(p: Product?, onClose: () -> Unit) {
    var en by remember { mutableStateOf(p?.en ?: "") }
    var ne by remember { mutableStateOf(p?.ne ?: "") }
    var hi by remember { mutableStateOf(p?.hi ?: "") }
    var price by remember { mutableStateOf(p?.price?.toString() ?: "") }
    var orig by remember { mutableStateOf(p?.orig?.toString() ?: "") }
    var cat by remember { mutableStateOf(p?.cat ?: "elec") }
    var image by remember { mutableStateOf(p?.image ?: "") }
    var flash by remember { mutableStateOf(p?.flash ?: false) }
    var active by remember { mutableStateOf(p?.active ?: true) }
    var msg by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose, containerColor = ColCard,
        title = { Text(if (p == null) "Add product" else "Edit product") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (image.isNotBlank()) AppIcon(image, en.ifBlank { "P" }, 110.dp, 18.dp)
                AppField(image, { image = it }, "Image URL (imgbb Direct link)")
                AppField(en, { en = it }, "Name (English) *")
                AppField(ne, { ne = it }, "नाम (नेपाली)")
                AppField(hi, { hi = it }, "नाम (हिन्दी)")
                AppField(price, { price = it }, "Price (NPR) *", keyboardType = KeyboardType.Number)
                AppField(orig, { orig = it }, "Original price", keyboardType = KeyboardType.Number)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(CATS.entries.toList()) { (k, l) ->
                        Text(l, color = if (cat == k) Color.White else ColText, modifier = Modifier.clip(RoundedCornerShape(50)).background(if (cat == k) ColBrand else ColCard2).clickable { cat = k }.padding(horizontal = 14.dp, vertical = 8.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("⚡ Flash sale", Modifier.weight(1f)); Switch(flash, { flash = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Visible to customers", Modifier.weight(1f)); Switch(active, { active = it }) }
                if (msg.isNotEmpty()) Text(msg, color = ColRed, fontSize = 13.sp)
            }
        },
        confirmButton = {
            Button(colors = ButtonDefaults.buttonColors(containerColor = ColBrand), onClick = {
                val pr = price.trim().toLongOrNull() ?: 0L
                if (en.isBlank() || pr <= 0L) { msg = "Enter English name and a valid price"; return@Button }
                val data = hashMapOf<String, Any>(
                    "name" to mapOf("en" to en.trim(), "ne" to ne.trim(), "hi" to hi.trim()), "price" to pr, "orig" to (orig.trim().toLongOrNull() ?: pr),
                    "category" to cat, "image" to image.trim(), "flash" to flash, "active" to active
                )
                try {
                    val col = FirebaseFirestore.getInstance().collection("products")
                    if (p == null) { data["createdAt"] = FieldValue.serverTimestamp(); col.add(data) } else col.document(p.id).update(data)
                    onClose()
                } catch (e: Exception) { msg = "Save failed" }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
