@file:OptIn(ExperimentalMaterial3Api::class)

package com.sastabazar.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- constants & models ----------
const val WIN = 30 * 60 * 1000L
val STEPS = listOf("CONFIRMED", "PROCESSING", "PACKED", "SHIPPED", "IN_TRANSIT", "OUT_FOR_DELIVERY", "DELIVERED")
val CATS = listOf("elec", "fash", "groc", "home", "beau", "mob")
val LANG_CODES = listOf("en", "ne", "hi")
val LANG_NAMES = listOf("English", "नेपाली", "हिन्दी")
val LOCALES = listOf("en-US", "ne-NP", "hi-IN")

data class Product(val id: String, val names: Map<String, String>, val price: Long, val orig: Long, val cat: String, val image: String, val flash: Boolean, val active: Boolean)
data class OrderItem(val names: Map<String, String>, val price: Long, val qty: Int)
data class OrderDoc(val id: String, val status: String, val total: Long, val created: Long, val items: List<OrderItem>, val reason: String)
data class Note(val id: String, val orderId: String, val status: String, val created: Long, val read: Boolean)

fun catIcon(c: String) = when (c) { "elec" -> "🎧"; "fash" -> "👗"; "groc" -> "🌾"; "home" -> "🏠"; "beau" -> "💄"; "mob" -> "📱"; "wl" -> "♥"; "all" -> "✨"; else -> "🛍️" }
fun fee(s: Long): Long = if (s >= 2000L || s == 0L) 0L else 100L
fun num(x: Long): String = NumberFormat.getInstance(Locale.forLanguageTag(LOCALES[Lang.idx])).format(x)
fun money(x: Long): String = (if (Lang.idx == 0) "NPR " else "रू ") + num(x)
fun pn(names: Map<String, String>): String = names[LANG_CODES[Lang.idx]]?.takeIf { it.isNotBlank() } ?: names["en"] ?: ""
fun mmss(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format(Locale.forLanguageTag(LOCALES[Lang.idx]), "%02d:%02d", s / 60, s % 60)
}
fun fmtDate(ms: Long): String = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.forLanguageTag(LOCALES[Lang.idx])).format(Date(ms))
fun shortId(id: String) = id.take(6).uppercase()
fun statusColor(s: String): Color = when (s) { "DELIVERED" -> ColGreen; "CANCELLED" -> ColRed; "CONFIRMED" -> ColBlue; else -> ColGold }

// ---------- local storage ----------
fun prefs(ctx: Context) = ctx.getSharedPreferences("sastabazar", Context.MODE_PRIVATE)
fun saveCart(ctx: Context, cart: Map<String, Int>) = prefs(ctx).edit().putString("cart", cart.entries.joinToString(",") { it.key + ":" + it.value }).apply()
fun loadCart(ctx: Context): Map<String, Int> = (prefs(ctx).getString("cart", "") ?: "").split(",").mapNotNull {
    val p = it.split(":"); if (p.size == 2) p[1].toIntOrNull()?.let { q -> p[0] to q } else null
}.toMap()
fun saveWl(ctx: Context, wl: List<String>) = prefs(ctx).edit().putString("wl", wl.joinToString(",")).apply()
fun loadWl(ctx: Context): List<String> = (prefs(ctx).getString("wl", "") ?: "").split(",").filter { it.isNotBlank() }

fun notifyLocal(ctx: Context, id: Int, title: String, body: String) {
    try {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("orders", "Orders", NotificationManager.IMPORTANCE_HIGH))
        val b = android.app.Notification.Builder(ctx)
        if (Build.VERSION.SDK_INT >= 26) b.setChannelId("orders")
        b.setSmallIcon(ctx.applicationInfo.icon).setContentTitle(title).setContentText(body).setAutoCancel(true)
        nm.notify(id, b.build())
    } catch (_: Throwable) { }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        Lang.idx = prefs(this).getInt("lang", 0).coerceIn(0, 2)
        try { FirebaseMessaging.getInstance().subscribeToTopic("all") } catch (_: Throwable) { }
        setContent { AppTheme { SastaApp() } }
    }
}

// ---------- parsing ----------
@Suppress("UNCHECKED_CAST")
fun nameMap(v: Any?): Map<String, String> = (v as? Map<String, Any?>)?.mapValues { it.value?.toString() ?: "" } ?: emptyMap()

@Suppress("UNCHECKED_CAST")
fun parseOrder(d: DocumentSnapshot): OrderDoc {
    val items = (d.get("items") as? List<Map<String, Any?>>)?.map {
        OrderItem(nameMap(it["name"]), (it["price"] as? Number)?.toLong() ?: 0L, (it["qty"] as? Number)?.toInt() ?: 1)
    } ?: emptyList()
    return OrderDoc(
        d.id, d.getString("status") ?: "CONFIRMED", d.getLong("total") ?: 0L,
        d.getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis(), items, d.getString("cancelReason") ?: ""
    )
}

// ---------- live data ----------
@Composable
fun rememberUser(): FirebaseUser? {
    var u by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { u = it.currentUser }
        FirebaseAuth.getInstance().addAuthStateListener(l)
        onDispose { FirebaseAuth.getInstance().removeAuthStateListener(l) }
    }
    return u
}

/** null = loading */
@Composable
fun rememberProducts(): List<Product>? {
    var list by remember { mutableStateOf<List<Product>?>(null) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("products").addSnapshotListener { snap, err ->
            if (snap != null) {
                list = snap.documents.map {
                    Product(it.id, nameMap(it.get("name")), it.getLong("price") ?: 0L, it.getLong("orig") ?: 0L, it.getString("category") ?: "",
                        it.getString("image") ?: "", it.getBoolean("flash") == true, it.getBoolean("active") != false)
                }.filter { it.active }
            } else if (err != null && list == null) list = emptyList()
        }
        onDispose { reg.remove() }
    }
    return list
}

@Composable
fun rememberOrders(uid: String?): List<OrderDoc> {
    val ctx = LocalContext.current
    var list by remember(uid) { mutableStateOf<List<OrderDoc>>(emptyList()) }
    DisposableEffect(uid) {
        if (uid == null) {
            list = emptyList()
            onDispose { }
        } else {
            var seen: Map<String, String>? = null
            val reg = FirebaseFirestore.getInstance().collection("orders").whereEqualTo("uid", uid).addSnapshotListener { snap, _ ->
                if (snap != null) {
                    val l = snap.documents.map { parseOrder(it) }.sortedByDescending { it.created }
                    val prev = seen
                    if (prev != null) l.forEach { o ->
                        val old = prev[o.id]
                        if (old != null && old != o.status) notifyLocal(ctx, o.id.hashCode(), t("ptitle"), t("order") + " #" + shortId(o.id) + ": " + t(o.status))
                    }
                    seen = l.associate { it.id to it.status }
                    list = l
                }
            }
            onDispose { reg.remove() }
        }
    }
    return list
}

@Composable
fun rememberNotes(uid: String?): List<Note> {
    var list by remember(uid) { mutableStateOf<List<Note>>(emptyList()) }
    DisposableEffect(uid) {
        if (uid == null) {
            list = emptyList()
            onDispose { }
        } else {
            val reg = FirebaseFirestore.getInstance().collection("notifications").whereEqualTo("uid", uid).addSnapshotListener { snap, _ ->
                if (snap != null) list = snap.documents.map {
                    Note(it.id, it.getString("orderId") ?: "", it.getString("status") ?: "", it.getTimestamp("createdAt")?.toDate()?.time ?: 0L, it.getBoolean("read") == true)
                }.sortedByDescending { it.created }
            }
            onDispose { reg.remove() }
        }
    }
    return list
}

fun setLanguage(ctx: Context, i: Int) {
    Lang.idx = i
    prefs(ctx).edit().putInt("lang", i).apply()
    try {
        val u = FirebaseAuth.getInstance().currentUser
        if (u != null) FirebaseFirestore.getInstance().collection("users").document(u.uid).set(mapOf("lang" to LANG_CODES[i]), com.google.firebase.firestore.SetOptions.merge())
    } catch (_: Throwable) { }
}

// ---------- root ----------
@Composable
fun SastaApp() {
    val ctx = LocalContext.current
    val user = rememberUser()
    val products = rememberProducts()
    val orders = rememberOrders(user?.uid)
    val notes = rememberNotes(user?.uid)
    val cart = remember { mutableStateMapOf<String, Int>().apply { putAll(loadCart(ctx)) } }
    val wl = remember { mutableStateListOf<String>().apply { addAll(loadWl(ctx)) } }
    var tab by remember { mutableIntStateOf(0) }
    var splash by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<Product?>(null) }
    var showCart by remember { mutableStateOf(false) }
    var showCheckout by remember { mutableStateOf(false) }
    var placed by remember { mutableStateOf(false) }
    var cancelId by remember { mutableStateOf<String?>(null) }
    var toast by remember { mutableStateOf("") }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        delay(1300); splash = false
        if (Build.VERSION.SDK_INT >= 33) { try { permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } catch (_: Exception) { } }
    }
    LaunchedEffect(toast) { if (toast.isNotEmpty()) { delay(1800); toast = "" } }

    fun addToCart(p: Product) { cart[p.id] = (cart[p.id] ?: 0) + 1; saveCart(ctx, cart); toast = t("added") }
    fun toggleWl(id: String) { if (wl.contains(id)) wl.remove(id) else wl.add(id); saveWl(ctx, wl) }
    val cartCount = cart.entries.filter { e -> products?.any { it.id == e.key } == true }.sumOf { it.value }
    val unread = notes.count { !it.read }

    AuroraBackground(Modifier.fillMaxSize()) {
        if (user == null) {
            AuthScreen()
        } else {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = { TopBar(cartCount) { showCart = true } },
                bottomBar = { NavBar(tab, unread) { tab = it } }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> HomeScreen(products, wl, onOpen = { selected = it }, onAdd = { addToCart(it) }, onWl = { toggleWl(it) })
                        1 -> OrdersScreen(orders) { cancelId = it }
                        2 -> NotesScreen(notes)
                        else -> ProfileScreen(user)
                    }
                    if (toast.isNotEmpty()) Box(Modifier.align(Alignment.TopCenter).padding(top = 8.dp).clip(RoundedCornerShape(50)).background(ColBrand).padding(horizontal = 18.dp, vertical = 10.dp)) {
                        Text(toast, color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            selected?.let { p -> ProductDialog(p, wl.contains(p.id), onClose = { selected = null }, onAdd = { addToCart(p); selected = null }, onWl = { toggleWl(p.id) }) }
            if (showCart) CartDialog(products ?: emptyList(), cart, onClose = { showCart = false }, onCheckout = { showCart = false; showCheckout = true }, ctx = ctx)
            if (showCheckout) CheckoutDialog(user, products ?: emptyList(), cart, onClose = { showCheckout = false }, onDone = { cart.clear(); saveCart(ctx, cart); showCheckout = false; placed = true })
            if (placed) AlertDialog(
                onDismissRequest = { placed = false }, containerColor = ColCard,
                title = { Text("✅  " + t("placed")) },
                confirmButton = { TextButton(onClick = { placed = false; tab = 1 }) { Text(t("orders")) } },
                dismissButton = { TextButton(onClick = { placed = false }) { Text(t("close")) } }
            )
            cancelId?.let { id -> CancelDialog(id, onClose = { cancelId = null }, onResult = { toast = it }) }
        }
        AnimatedVisibility(splash, exit = fadeOut(tween(500)) + scaleOut(tween(500), targetScale = 1.15f)) { Splash() }
        CrashDialog()
    }
}

@Composable
fun Splash() {
    Box(Modifier.fillMaxSize().background(ColBg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            SpinRing(120.dp) { Image(painterResource(R.drawable.logo), null, Modifier.size(78.dp).clip(RoundedCornerShape(20.dp))) }
            Spacer(Modifier.height(20.dp))
            Text("SastaBazar", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text(t("tag"), color = ColDim)
        }
    }
}

@Composable
fun LangChips() {
    val ctx = LocalContext.current
    Row(Modifier.clip(RoundedCornerShape(50)).background(ColCard2).padding(2.dp)) {
        LANG_NAMES.forEachIndexed { i, n ->
            val sel = Lang.idx == i
            Text(
                n, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (sel) Color.White else ColText,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) ColBrand else Color.Transparent)
                    .clickable { setLanguage(ctx, i) }.padding(horizontal = 9.dp, vertical = 5.dp)
            )
        }
    }
}

@Composable
fun TopBar(cartCount: Int, onCart: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(8.dp))
        Text("SastaBazar", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = ColBrand, modifier = Modifier.weight(1f))
        LangChips()
        Spacer(Modifier.width(4.dp))
        BadgedBox(badge = { if (cartCount > 0) Badge(containerColor = ColBrand) { Text(num(cartCount.toLong())) } }) {
            IconButton(onClick = onCart) { Icon(Icons.Default.ShoppingCart, null) }
        }
    }
}

@Composable
fun NavBar(tab: Int, unread: Int, onTab: (Int) -> Unit) {
    NavigationBar(containerColor = ColCard.copy(alpha = 0.94f), tonalElevation = 0.dp) {
        listOf(Triple(t("home"), Icons.Default.Home, 0), Triple(t("orders"), Icons.Default.ShoppingBag, 1), Triple(t("notif"), Icons.Default.Notifications, 2), Triple(t("profile"), Icons.Default.Person, 3)).forEach { (label, icon, i) ->
            NavigationBarItem(
                selected = tab == i, onClick = { onTab(i) },
                icon = { BadgedBox(badge = { if (i == 2 && unread > 0) Badge(containerColor = ColBrand) { Text(num(unread.toLong())) } }) { Icon(icon, null) } },
                label = { Text(label, fontSize = 11.sp, maxLines = 1, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = ColBrand, indicatorColor = ColBrand, unselectedIconColor = ColDim, unselectedTextColor = ColDim)
            )
        }
    }
}

// ---------- auth ----------
fun saveUserDoc(u: FirebaseUser, name: String) {
    try {
        FirebaseFirestore.getInstance().collection("users").document(u.uid).set(
            mapOf("name" to name, "email" to (u.email ?: ""), "lang" to LANG_CODES[Lang.idx]), com.google.firebase.firestore.SetOptions.merge()
        )
    } catch (_: Throwable) { }
}

@Composable
fun AuthScreen() {
    val ctx = LocalContext.current
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val webId = remember { ctx.resources.getIdentifier("default_web_client_id", "string", ctx.packageName) }
    val gLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        try {
            val acc = GoogleSignIn.getSignedInAccountFromIntent(r.data).getResult(ApiException::class.java)
            FirebaseAuth.getInstance().signInWithCredential(GoogleAuthProvider.getCredential(acc.idToken, null))
                .addOnSuccessListener { res -> res.user?.let { saveUserDoc(it, it.displayName ?: "") }; busy = false }
                .addOnFailureListener { busy = false; msg = t("err") }
        } catch (e: Exception) { busy = false; msg = t("err") }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(36.dp))
        Image(painterResource(R.drawable.logo), null, Modifier.size(96.dp).clip(RoundedCornerShape(26.dp)))
        Spacer(Modifier.height(10.dp))
        Text("SastaBazar", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text(t("tag"), color = ColDim)
        Spacer(Modifier.height(14.dp))
        LangChips()
        Spacer(Modifier.height(22.dp))
        SoftCard {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (register) t("signup") else t("login"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (register) AppField(name, { name = it }, t("name"))
                AppField(email, { email = it }, t("email"), keyboardType = KeyboardType.Email)
                AppField(pass, { pass = it }, t("pass"), password = true)
                if (msg.isNotEmpty()) Text(msg, color = ColRed, fontSize = 13.sp)
                PrimaryButton(if (register) t("signup") else t("login"), onClick = {
                    msg = ""
                    if (email.isBlank() || pass.isBlank()) { msg = t("err"); return@PrimaryButton }
                    busy = true
                    try {
                        val a = FirebaseAuth.getInstance()
                        if (register) a.createUserWithEmailAndPassword(email.trim(), pass)
                            .addOnSuccessListener { res ->
                                res.user?.let { u ->
                                    u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build())
                                    saveUserDoc(u, name.trim())
                                }
                                busy = false
                            }.addOnFailureListener { busy = false; msg = t("err") }
                        else a.signInWithEmailAndPassword(email.trim(), pass)
                            .addOnSuccessListener { busy = false }.addOnFailureListener { busy = false; msg = t("err") }
                    } catch (e: Exception) { busy = false; msg = t("err") }
                }, loading = busy)
                if (!register) Text(
                    t("forgot"), color = ColBrand, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable {
                        if (email.isBlank()) { msg = t("email"); return@clickable }
                        try {
                            FirebaseAuth.getInstance().sendPasswordResetEmail(email.trim())
                                .addOnSuccessListener { msg = t("sent") }.addOnFailureListener { msg = t("err") }
                        } catch (_: Exception) { }
                    }
                )
                if (webId != 0) GhostButton("G   " + t("google"), onClick = {
                    try {
                        busy = true
                        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(ctx.getString(webId)).requestEmail().build()
                        val client = GoogleSignIn.getClient(ctx, gso)
                        client.signOut().addOnCompleteListener { gLauncher.launch(client.signInIntent) }
                    } catch (e: Exception) { busy = false; msg = t("err") }
                })
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            if (register) t("hasacc") else t("noacc"), color = ColBrand, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
            modifier = Modifier.clickable { register = !register; msg = "" }.padding(8.dp)
        )
    }
}

// ---------- home ----------
@Composable
fun ProductImage(p: Product, h: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val url = normalizeImageUrl(p.image)
    Box(modifier.fillMaxWidth().height(h).background(Brush.linearGradient(listOf(ColCard2, ColLine))), contentAlignment = Alignment.Center) {
        Text(catIcon(p.cat), fontSize = (h.value / 2.2f).sp)
        if (p.image.isNotBlank()) AsyncImage(
            model = coil.request.ImageRequest.Builder(ctx).data(url).crossfade(500)
                .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36").build(),
            contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun ProductCard(p: Product, inWl: Boolean, onOpen: () -> Unit, onAdd: () -> Unit, onWl: () -> Unit, modifier: Modifier = Modifier) {
    val off = if (p.orig > p.price) (100 - p.price * 100 / p.orig).toInt() else 0
    SoftCard(modifier, onClick = onOpen) {
        Box {
            ProductImage(p, 122.dp)
            if (off > 0) Text("-" + num(off.toLong()) + "%", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(8.dp).clip(RoundedCornerShape(50)).background(ColBrand).padding(horizontal = 8.dp, vertical = 2.dp))
            IconButton(onClick = onWl, modifier = Modifier.align(Alignment.TopEnd).size(40.dp)) {
                Icon(if (inWl) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (inWl) ColBrand else Color.White)
            }
        }
        Column(Modifier.padding(10.dp)) {
            Text(pn(p.names), maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, modifier = Modifier.height(40.dp))
            Text(money(p.price), color = ColBrand, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            if (off > 0) Text(money(p.orig), color = ColDim, fontSize = 12.sp, textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
            Spacer(Modifier.height(6.dp))
            Button(onClick = onAdd, modifier = Modifier.fillMaxWidth().height(38.dp), shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(0.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ColBrand, contentColor = Color.White)) { Text(t("add"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun HomeScreen(products: List<Product>?, wl: List<String>, onOpen: (Product) -> Unit, onAdd: (Product) -> Unit, onWl: (String) -> Unit) {
    var cat by remember { mutableStateOf("all") }
    var query by remember { mutableStateOf("") }
    if (products == null) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { repeat(5) { SkeletonCard() } }
        return
    }
    val shown = products.filter { (cat == "all" || (cat == "wl" && wl.contains(it.id)) || it.cat == cat) && (query.isBlank() || pn(it.names).contains(query, true)) }
    val flash = products.filter { it.flash }
    val bob = rememberInfiniteTransition(label = "bob").animateFloat(-6f, 6f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "b")
    LazyVerticalGrid(
        columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(28.dp),
                    placeholder = { Text(t("search"), color = ColDim) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = ColDim) },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ColBrand, unfocusedBorderColor = ColLine, focusedContainerColor = ColCard, unfocusedContainerColor = ColCard, cursorColor = ColBrand)
                )
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(ColBrand, Color(0xFF9E0016)))).padding(22.dp)) {
                    Column(Modifier.fillMaxWidth(0.65f)) {
                        Text(t("h1"), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text(t("h1s"), color = Color.White.copy(alpha = 0.85f))
                    }
                    Text("🛍️", fontSize = 64.sp, modifier = Modifier.align(Alignment.CenterEnd).graphicsLayer { translationY = bob.value })
                }
                Text("🚚  " + t("strip"), color = ColBrand, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ColBrand.copy(alpha = 0.12f)).padding(12.dp))
                if (query.isBlank() && cat == "all" && flash.isNotEmpty()) {
                    Text("⚡ " + t("flash"), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(flash, key = { it.id }) { p -> ProductCard(p, wl.contains(p.id), { onOpen(p) }, { onAdd(p) }, { onWl(p.id) }, Modifier.width(165.dp)) }
                    }
                }
                Text(t("cats"), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(listOf("all") + CATS + listOf("wl")) { c ->
                        val sel = cat == c
                        Column(Modifier.width(66.dp).clickable { cat = c }, horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(if (sel) Brush.linearGradient(listOf(ColBrand, Color(0xFFB30019))) else Brush.linearGradient(listOf(ColCard2, ColCard2))), contentAlignment = Alignment.Center) {
                                Text(catIcon(c), fontSize = 26.sp)
                            }
                            Text(if (c == "all") t("all") else if (c == "wl") t("wish") else t("c_" + c), fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1, color = if (sel) ColBrand else ColText)
                        }
                    }
                }
                Text(t("pop"), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                if (shown.isEmpty()) Text(t("none"), color = ColDim, modifier = Modifier.padding(20.dp))
            }
        }
        items(shown, key = { it.id }) { p -> ProductCard(p, wl.contains(p.id), { onOpen(p) }, { onAdd(p) }, { onWl(p.id) }) }
    }
}

// ---------- dialogs ----------
@Composable
fun ProductDialog(p: Product, inWl: Boolean, onClose: () -> Unit, onAdd: () -> Unit, onWl: () -> Unit) {
    val off = if (p.orig > p.price) (100 - p.price * 100 / p.orig).toInt() else 0
    AlertDialog(
        onDismissRequest = onClose, containerColor = ColCard,
        title = { Text(pn(p.names)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                ProductImage(p, 190.dp, Modifier.clip(RoundedCornerShape(18.dp)))
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(money(p.price), color = ColBrand, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    if (off > 0) { Spacer(Modifier.width(8.dp)); Text(money(p.orig), color = ColDim, textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough); Spacer(Modifier.width(8.dp)); StatusChip("-" + num(off.toLong()) + "%", ColBrand) }
                }
                Spacer(Modifier.height(8.dp))
                Text(t("desc"), color = ColDim)
                Text("✓ " + t("cod"), color = ColDim)
            }
        },
        confirmButton = { Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = ColBrand)) { Text(t("add")) } },
        dismissButton = { TextButton(onClick = onWl) { Icon(if (inWl) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = ColBrand) } }
    )
}

@Composable
fun CartDialog(products: List<Product>, cart: MutableMap<String, Int>, onClose: () -> Unit, onCheckout: () -> Unit, ctx: Context) {
    val lines = cart.entries.mapNotNull { e -> products.find { it.id == e.key }?.let { it to e.value } }
    val sub = lines.sumOf { it.first.price * it.second }
    AlertDialog(
        onDismissRequest = onClose, containerColor = ColCard,
        title = { Text(t("cart")) },
        text = {
            if (lines.isEmpty()) Text(t("empty"), color = ColDim) else Column(Modifier.verticalScroll(rememberScrollState())) {
                lines.forEach { (p, q) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(pn(p.names), maxLines = 2, fontSize = 14.sp); Text(money(p.price), color = ColBrand, fontWeight = FontWeight.Bold) }
                        IconButton(onClick = { if (q <= 1) cart.remove(p.id) else cart[p.id] = q - 1; saveCart(ctx, cart) }) { Icon(Icons.Default.Remove, null) }
                        Text(num(q.toLong()), fontWeight = FontWeight.Bold)
                        IconButton(onClick = { cart[p.id] = q + 1; saveCart(ctx, cart) }) { Icon(Icons.Default.Add, null) }
                    }
                }
                HorizontalDivider(color = ColLine, modifier = Modifier.padding(vertical = 8.dp))
                TotalRows(sub)
            }
        },
        confirmButton = { if (lines.isNotEmpty()) Button(onClick = onCheckout, colors = ButtonDefaults.buttonColors(containerColor = ColBrand)) { Text(t("co")) } },
        dismissButton = { TextButton(onClick = onClose) { Text(t("close")) } }
    )
}

@Composable
fun TotalRows(sub: Long) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(t("sub")); Text(money(sub), fontWeight = FontWeight.Bold) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(t("del")); Text(if (fee(sub) == 0L) t("free") else money(fee(sub)), fontWeight = FontWeight.Bold) }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(t("total"), fontWeight = FontWeight.ExtraBold); Text(money(sub + fee(sub)), color = ColBrand, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
    }
}

@Composable
fun CheckoutDialog(user: FirebaseUser, products: List<Product>, cart: Map<String, Int>, onClose: () -> Unit, onDone: () -> Unit) {
    var addr by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(user.uid) {
        try {
            FirebaseFirestore.getInstance().collection("users").document(user.uid).get().addOnSuccessListener {
                if (addr.isEmpty()) addr = it.getString("address") ?: ""; if (phone.isEmpty()) phone = it.getString("phone") ?: ""
            }
        } catch (_: Exception) { }
    }
    val lines = cart.entries.mapNotNull { e -> products.find { it.id == e.key }?.let { it to e.value } }
    val sub = lines.sumOf { it.first.price * it.second }
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() }, containerColor = ColCard,
        title = { Text(t("co")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AppField(addr, { addr = it }, t("addr"), singleLine = false)
                AppField(phone, { phone = it }, t("ph"), keyboardType = KeyboardType.Phone)
                Text(t("pay"), fontWeight = FontWeight.Bold)
                Text("◉  " + t("cod"), modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(ColBrand.copy(alpha = 0.14f)).padding(12.dp))
                TotalRows(sub)
                if (msg.isNotEmpty()) Text(msg, color = ColRed, fontSize = 13.sp)
            }
        },
        confirmButton = {
            Button(enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = ColBrand), onClick = {
                if (addr.isBlank() || phone.isBlank()) { msg = t("fill"); return@Button }
                busy = true
                try {
                    val items = lines.map { (p, q) -> mapOf("id" to p.id, "name" to p.names, "price" to p.price, "qty" to q) }
                    val data = hashMapOf<String, Any>(
                        "uid" to user.uid, "userName" to (user.displayName ?: user.email ?: ""), "items" to items,
                        "subtotal" to sub, "fee" to fee(sub), "total" to sub + fee(sub), "method" to "cod",
                        "address" to addr.trim(), "phone" to phone.trim(), "status" to "CONFIRMED", "createdAt" to FieldValue.serverTimestamp()
                    )
                    val db = FirebaseFirestore.getInstance()
                    db.collection("orders").add(data).addOnSuccessListener {
                        db.collection("users").document(user.uid).set(mapOf("address" to addr.trim(), "phone" to phone.trim()), com.google.firebase.firestore.SetOptions.merge())
                        busy = false; onDone()
                    }.addOnFailureListener { busy = false; msg = t("err") }
                } catch (e: Exception) { busy = false; msg = t("err") }
            }) { Text(if (busy) "…" else t("place")) }
        },
        dismissButton = { TextButton(onClick = onClose, enabled = !busy) { Text(t("bk")) } }
    )
}

@Composable
fun CancelDialog(id: String, onClose: () -> Unit, onResult: (String) -> Unit) {
    var reason by remember { mutableStateOf("r1") }
    AlertDialog(
        onDismissRequest = onClose, containerColor = ColCard,
        title = { Text(t("cancel") + " #" + shortId(id)) },
        text = {
            Column {
                Text(t("rs"), fontWeight = FontWeight.Bold)
                listOf("r1", "r2", "r3").forEach { k ->
                    Row(Modifier.fillMaxWidth().clickable { reason = k }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = reason == k, onClick = { reason = k }, colors = RadioButtonDefaults.colors(selectedColor = ColBrand))
                        Text(t(k))
                    }
                }
            }
        },
        confirmButton = {
            Button(colors = ButtonDefaults.buttonColors(containerColor = ColBrand), onClick = {
                try {
                    FirebaseFirestore.getInstance().collection("orders").document(id)
                        .update(mapOf("status" to "CANCELLED", "cancelReason" to reason, "cancelledAt" to FieldValue.serverTimestamp()))
                        .addOnSuccessListener { onResult(t("cd")) }
                        .addOnFailureListener { onResult(t("cc")) }   // server rules reject after 30 minutes
                } catch (e: Exception) { onResult(t("err")) }
                onClose()
            }) { Text(t("ok")) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text(t("bk")) } }
    )
}

// ---------- orders / alerts / profile ----------
@Composable
fun OrdersScreen(orders: List<OrderDoc>, onCancel: (String) -> Unit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    if (orders.isEmpty()) { EmptyState(Icons.Default.ShoppingBag, t("noo"), ""); return }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        itemsIndexed(orders, key = { _, o -> o.id }) { i, o ->
            Appear(i) {
                val left = o.created + WIN - now
                val canCancel = left > 0 && o.status in listOf("CONFIRMED", "PROCESSING", "PACKED")
                val step = STEPS.indexOf(o.status)
                SoftCard {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(t("order") + " #" + shortId(o.id), fontWeight = FontWeight.ExtraBold)
                            StatusChip(t(o.status), statusColor(o.status))
                        }
                        Text(fmtDate(o.created) + " · " + t("cod") + " · " + money(o.total), color = ColDim, fontSize = 12.sp)
                        o.items.forEach { Text(num(it.qty.toLong()) + " × " + pn(it.names), fontSize = 13.sp) }
                        if (o.status != "CANCELLED") LinearProgressIndicator(progress = { ((step + 1).coerceAtLeast(1)) / STEPS.size.toFloat() }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = ColBrand, trackColor = ColLine)
                        if (canCancel) {
                            Text(t("cw") + ": " + mmss(left), color = ColGold, fontWeight = FontWeight.Bold)
                            GhostButton(t("cancel"), onClick = { onCancel(o.id) }, color = ColBrand)
                        } else if (o.status != "CANCELLED" && o.status != "DELIVERED") Text(t("cc"), color = ColDim, fontSize = 12.sp)
                        if (o.status == "CANCELLED" && o.reason.isNotBlank()) Text(t("cd") + " · " + t(o.reason), color = ColDim, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun NotesScreen(notes: List<Note>) {
    val db = FirebaseFirestore.getInstance()
    if (notes.isEmpty()) { EmptyState(Icons.Default.NotificationsNone, t("nonotif"), ""); return }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            if (notes.any { !it.read }) Text(t("mark"), color = ColBrand, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().clickable {
                notes.filter { !it.read }.forEach { db.collection("notifications").document(it.id).update("read", true) }
            })
        }
        itemsIndexed(notes, key = { _, n -> n.id }) { i, n ->
            Appear(i) {
                SoftCard(onClick = { if (!n.read) db.collection("notifications").document(n.id).update("read", true) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(t("ptitle"), fontWeight = FontWeight.Bold, color = if (n.read) ColText else ColBrand)
                        Text(t("order") + " #" + shortId(n.orderId) + ": " + t(n.status))
                        if (n.created > 0) Text(fmtDate(n.created), color = ColDim, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(user: FirebaseUser) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SoftCard {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                AppIcon("", user.displayName ?: user.email ?: "S", 56.dp, 28.dp)
                Spacer(Modifier.width(14.dp))
                Column { Text(user.displayName ?: "", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp); Text(user.email ?: "", color = ColDim) }
            }
        }
        Text(t("lang"), fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LANG_NAMES.forEachIndexed { i, n ->
                val sel = Lang.idx == i
                Text(n, color = if (sel) Color.White else ColText, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) ColBrand else ColCard2).clickable { setLanguage(ctx, i) }.padding(horizontal = 16.dp, vertical = 9.dp))
            }
        }
        Spacer(Modifier.weight(1f))
        GhostButton(t("out"), onClick = { FirebaseAuth.getInstance().signOut() }, color = ColBrand)
    }
}
